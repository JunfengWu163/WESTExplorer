﻿using System;
using System.Collections;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Tools;
using JunfengWu.FastText;
using System.Diagnostics;

namespace JunfengWu.FastText
{
    public class FastTextModel
    {
        public DataLocation dataLocation { get; private set; }
        public FastText fastText { get; private set; } = new FastText();
        public int numDims { get => fastText.GetDimension(); }
        
        public FastTextModel(DataLocation dataLocation, IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            Debug.Assert(HasWikiEn(dataLocation));

            this.dataLocation = dataLocation;
            LoadWikiEn(totalProgress, stepProgress);
        }
        
        static bool HasWikiEn(DataLocation dataLocation)
        {
            string pretrainedPath = dataLocation.Get("fastTextPath");
            string wikiEnFileName2 = Path.Combine(pretrainedPath, "en.100.bin");
            string wikiEnFileName1 = Path.Combine(pretrainedPath, "wiki.en.bin");
            return File.Exists(wikiEnFileName1) || File.Exists(wikiEnFileName2);
        }

        void LoadWikiEn(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            string pretrainedPath = dataLocation.Get("fastTextPath");
            string modelFileName2 = Path.Combine(pretrainedPath, "en.100.bin");
            string modelFileName1 = Path.Combine(pretrainedPath, "wiki.en.bin");
            if (File.Exists(modelFileName1))
                this.fastText.LoadModel(modelFileName1, totalProgress, stepProgress);
            else
                this.fastText.LoadModel(modelFileName2, totalProgress, stepProgress);
        }

        public float[] GetFormVector(string form)
        {
            string formStr;
            if (form.StartsWith('['))
            {
                int pos = form.IndexOf(']');
                if (pos < 0)
                {
                    pos = 0;
                }
                formStr = form.Substring(pos + 1);
            }
            else
            {
                formStr = form;
            }

            int numDims = this.fastText.GetDimension();
            string[] words = formStr.Split(' ');
            Vector vForm = new Vector(numDims);
            vForm.Zero();
            foreach (string word in words)
            {
                if (word.Length > 0)
                {
                    Vector vWord = new Vector(numDims);
                    this.fastText.GetWordVector(vWord, word);
                    vForm.AddVector(vWord);
                }
            }
            float[] v = new float[numDims];
            for (int i = 0; i < numDims; i++)
            {
                v[i] = vForm[i];
            }
            return v;
        }
    }
}

