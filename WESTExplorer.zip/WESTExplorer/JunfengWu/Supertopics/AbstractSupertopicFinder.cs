﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JunfengWu.Supertopics
{
    public abstract class AbstractSupertopicFinder
    {
        public bool done { get; protected set; }
        public string myFileName { get; protected set; }
        public string myFileName2 { get; protected set; }

        public abstract void Find(IProgress<int> totalProgress, IProgress<int> stepProgress);
        public (List<string>, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>>) LoadSupertopics(IProgress<int> progress, bool future = false)
        {
            List<string> supertopics = new List<string>();
            Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> supertopicFreqsByWorkByYear = new Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>>();
            if (done)
            {
                // first, create list of supertopics and mapping from name to id
                Dictionary<string, int> supertopicIds = new Dictionary<string, int>();
                using (FileStream file = File.OpenRead(future ? myFileName2 : myFileName))
                {
                    using (StreamReader reader = new StreamReader(file))
                    {
                        progress?.Report(0);
                        int progressValue = 0;
                        string? line = reader.ReadLine();
                        while (line != null)
                        {
                            string[] parts = line.Split(',');
                            if (parts.Length > 1)
                            {
                                UInt64 workId = Convert.ToUInt64(parts[0]);
                                UInt16 year = Convert.ToUInt16(parts[1]);
                                Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWork;
                                if (!supertopicFreqsByWorkByYear.TryGetValue(year, out supertopicFreqsByWork))
                                {
                                    supertopicFreqsByWork = new Dictionary<UInt64, Dictionary<int, int>>();
                                    supertopicFreqsByWorkByYear[year] = supertopicFreqsByWork;
                                }

                                Dictionary<int, int> supertopicFreqsOfWork = new Dictionary<int, int>();
                                for (int i = 2; i < parts.Length; i++)
                                {
                                    string[] properties = parts[i].Split(':');
                                    if (properties.Length == 2)
                                    {
                                        string supertopic = properties[0];
                                        int freq = Convert.ToInt32(properties[1]);
                                        int id;
                                        if (!supertopicIds.TryGetValue(supertopic, out id))
                                        {
                                            id = supertopicIds.Count;
                                            supertopicIds.Add(supertopic, id);
                                            supertopics.Add(supertopic);
                                        }
                                        supertopicFreqsOfWork[id] = freq;
                                    }
                                }
                                supertopicFreqsByWork[workId] = supertopicFreqsOfWork;
                            }
                            int newProgressValue = Convert.ToInt32(file.Position / file.Length);
                            if (newProgressValue > progressValue)
                            {
                                progressValue = newProgressValue;
                                progress?.Report(progressValue);
                            }
                            line = reader.ReadLine();
                        }
                    }
                }
            }
            return (supertopics, supertopicFreqsByWorkByYear);
        }
    }
}
