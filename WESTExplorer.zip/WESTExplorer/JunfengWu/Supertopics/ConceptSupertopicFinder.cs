﻿using System;
using System.Diagnostics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Synonyms;
using JunfengWu.Tools;
using Microsoft.Maui.Controls.PlatformConfiguration;

namespace JunfengWu.Supertopics
{
    public class ConceptSupertopicFinder: AbstractSupertopicFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public Dictionary<UInt64, string> conceptNames { get; private set; } = new Dictionary<ulong, string>();

        public ConceptSupertopicFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            string supertopicPath = dataLocation.GetSubfieldDirectory(concept.id, "Supertopics");
            myFileName = Path.Combine(supertopicPath, $"Concept-{fromYear}-{toYear}.txt");
            myFileName2 = Path.Combine(supertopicPath, $"Concept-future-{fromYear}-{toYear}.txt");
            done = MD5Check.Check(myFileName) && MD5Check.Check(myFileName2);

            if (!done)
            {
                List<ConceptEntity> concepts = ConceptEntity.Load(dataLocation);
                foreach (ConceptEntity concept1 in concepts)
                {
                    conceptNames[concept1.id] = concept1.name;
                }
            }
        }

        Dictionary<string, int> GetDocumentSupertopics(WorkEntity work)
        {
            Dictionary<string, int> supertopics = new Dictionary<string, int>();
            if (work.concepts != null)
            {
                int numRefs;
                if (work.references != null)
                {
                    numRefs = Math.Max(work.references.Count, 10);
                }
                else
                {
                    numRefs = 10;
                }
                foreach ((UInt64 id, double score) in work.concepts)
                {
                    string supertopic;
                    if (conceptNames.TryGetValue(id, out supertopic))
                    {
                        int pseudoRelatedRefCount = Convert.ToInt32(Math.Ceiling(numRefs * score));
                        supertopics.TryAdd(supertopic, pseudoRelatedRefCount);
                    }
                }
            }
            return supertopics;
        }

        void Find(bool future, IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            UInt16 y1, y2;
            int totalProgress0, totalProgress1;
            string fileName;
            if (future)
            {
                y1 = Convert.ToUInt16(toYear + 1);
                y2 = Convert.ToUInt16(toYear + 10);
                totalProgress0 = 50;
                totalProgress1 = 100;
                fileName = myFileName2;
            }
            else
            {
                y1 = Convert.ToUInt16(fromYear - 10);
                y2 = toYear;
                totalProgress0 = 0;
                totalProgress1 = 50;
                fileName = myFileName;
            }

            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    totalProgress?.Report(totalProgress0);
                    for (UInt16 year = y1; year <= y2; year++)
                    {
                        stepProgress?.Report(0);
                        for (int idxBucket = 0; idxBucket < 64; idxBucket++)
                        {
                            List<WorkEntity> worksOfYear = WorkEntity.LoadSubfieldBucket(idxBucket, dataLocation, concept.id, year);
                            foreach (WorkEntity work in worksOfYear)
                            {
                                Dictionary<string, int> supertopics = GetDocumentSupertopics(work);
                                writer.Write($"{work.id},{year}");
                                foreach (var kv in supertopics)
                                {
                                    string supertopic = kv.Key;
                                    if (supertopic.Contains(':'))
                                    {
                                        supertopic = supertopic.Replace(':', '_');
                                    }
                                    int freq = kv.Value;
                                    writer.Write($",{supertopic}:{freq}");
                                }
                                writer.WriteLine();
                            }
                            stepProgress?.Report(100 * (idxBucket + 1) / 64);
                        }
                        totalProgress?.Report(totalProgress0 + (totalProgress1 - totalProgress0) * (year - y1 + 1) / (y2 - y1 + 1));
                    }
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            Find(false, totalProgress, stepProgress);
            Find(true, totalProgress, stepProgress);
        }
    }
}

