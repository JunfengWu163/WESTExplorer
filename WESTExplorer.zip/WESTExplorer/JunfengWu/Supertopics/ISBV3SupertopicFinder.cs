﻿using JunfengWu.Configuration;
using JunfengWu.FastText;
using JunfengWu.OpenAlex;
using JunfengWu.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JunfengWu.Supertopics
{
    public class ISBV3SupertopicFinder: AbstractSupertopicFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        FastTextModel fastTextModel;

        public ISBV3SupertopicFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.fastTextModel = fastTextModel;
            string supertopicPath = dataLocation.GetSubfieldDirectory(concept.id, "Supertopics");
            myFileName = Path.Combine(supertopicPath, $"ISBV3-{fromYear}-{toYear}.txt");
            myFileName2 = Path.Combine(supertopicPath, $"ISBV3-future-{fromYear}-{toYear}.txt");
            done = MD5Check.Check(myFileName) && MD5Check.Check(myFileName2);
        }

        void OutputSupertopics(bool future,
            List<string> isbSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> isbSupertopicFreqsByWorkByYear,
            List<string> csoSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> csoSupertopicFreqsByWorkByYear,
            List<string> conceptSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> conceptSupertopicFreqsByWorkByYear
            )
        {
            Dictionary<UInt64, UInt16> workYears = new Dictionary<UInt64, UInt16>();
            foreach (var kv1 in isbSupertopicFreqsByWorkByYear)
            {
                UInt16 year = kv1.Key;
                foreach (var kv2 in kv1.Value)
                {
                    UInt64 id = kv2.Key;
                    workYears[id] = year;
                }
            }
            foreach (var kv1 in csoSupertopicFreqsByWorkByYear)
            {
                UInt16 year = kv1.Key;
                foreach (var kv2 in kv1.Value)
                {
                    UInt64 id = kv2.Key;
                    workYears[id] = year;
                }
            }
            foreach (var kv1 in conceptSupertopicFreqsByWorkByYear)
            {
                UInt16 year = kv1.Key;
                foreach (var kv2 in kv1.Value)
                {
                    UInt64 id = kv2.Key;
                    workYears[id] = year;
                }
            }

            string fileName = future ? myFileName2 : myFileName;
            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    foreach (var kv1 in workYears)
                    {
                        UInt64 workId = kv1.Key;
                        UInt16 year = kv1.Value;
                        Dictionary<string, int> supertopicFreqsOfWork = new Dictionary<string, int>();
                        {
                            Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWorkOfYear;
                            if (isbSupertopicFreqsByWorkByYear.TryGetValue(year, out supertopicFreqsByWorkOfYear))
                            {
                                Dictionary<int, int> mySupertopicFreqsOfWork;
                                if (supertopicFreqsByWorkOfYear.TryGetValue(workId, out mySupertopicFreqsOfWork))
                                {
                                    foreach (var kv in mySupertopicFreqsOfWork)
                                    {
                                        supertopicFreqsOfWork.Add(isbSupertopics[kv.Key], kv.Value);
                                    }
                                }
                            }
                        }
                        {
                            Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWorkOfYear;
                            if (csoSupertopicFreqsByWorkByYear.TryGetValue(year, out supertopicFreqsByWorkOfYear))
                            {
                                Dictionary<int, int> mySupertopicFreqsOfWork;
                                if (supertopicFreqsByWorkOfYear.TryGetValue(workId, out mySupertopicFreqsOfWork))
                                {
                                    foreach (var kv in mySupertopicFreqsOfWork)
                                    {
                                        supertopicFreqsOfWork.Add("[cso]" + csoSupertopics[kv.Key], kv.Value);
                                    }
                                }
                            }
                        }
                        {
                            Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWorkOfYear;
                            if (conceptSupertopicFreqsByWorkByYear.TryGetValue(year, out supertopicFreqsByWorkOfYear))
                            {
                                Dictionary<int, int> mySupertopicFreqsOfWork;
                                if (supertopicFreqsByWorkOfYear.TryGetValue(workId, out mySupertopicFreqsOfWork))
                                {
                                    foreach (var kv in mySupertopicFreqsOfWork)
                                    {
                                        supertopicFreqsOfWork.Add("[concept]" + conceptSupertopics[kv.Key], kv.Value);
                                    }
                                }
                            }
                        }

                        if (supertopicFreqsOfWork.Count > 0)
                        {
                            writer.Write($"{workId},{year}");
                            foreach (var kv2 in supertopicFreqsOfWork)
                            {
                                string supertopic = kv2.Key;
                                int freq = kv2.Value;
                                writer.Write($",{supertopic}:{freq}");
                            }
                            writer.WriteLine();
                        }
                    }
                    
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            totalProgress?.Report(0);
            if (!MD5Check.Check(myFileName))
            {
                ISBSupertopicFinder isbSupertopicFinder = new ISBSupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                (List<string> isbSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> isbSupertopicFreqsByWorkByYear)
                    = isbSupertopicFinder.LoadSupertopics(stepProgress, false);
                CSOSupertopicFinder csoSupertopicFinder = new CSOSupertopicFinder(dataLocation, concept, fromYear, toYear, new Progress<int>(), new Progress<int>());
                (List<string> csoSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> csoSupertopicFreqsByWorkByYear)
                    = csoSupertopicFinder.LoadSupertopics(stepProgress, false);
                ConceptSupertopicFinder conceptSupertopicFinder = new ConceptSupertopicFinder(dataLocation, concept, fromYear, toYear);
                (List<string> conceptSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> conceptSupertopicFreqsByWorkByYear)
                    = conceptSupertopicFinder.LoadSupertopics(stepProgress, false);
                OutputSupertopics(false, isbSupertopics, isbSupertopicFreqsByWorkByYear, csoSupertopics, csoSupertopicFreqsByWorkByYear, conceptSupertopics, conceptSupertopicFreqsByWorkByYear);
            }
            GC.Collect();
            totalProgress?.Report(50);
            if (!MD5Check.Check(myFileName2))
            {
                ISBSupertopicFinder isbSupertopicFinder = new ISBSupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                (List<string> isbSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> isbSupertopicFreqsByWorkByYear)
                    = isbSupertopicFinder.LoadSupertopics(stepProgress, true);
                CSOSupertopicFinder csoSupertopicFinder = new CSOSupertopicFinder(dataLocation, concept, fromYear, toYear, new Progress<int>(), new Progress<int>());
                (List<string> csoSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> csoSupertopicFreqsByWorkByYear)
                    = csoSupertopicFinder.LoadSupertopics(stepProgress, true);
                ConceptSupertopicFinder conceptSupertopicFinder = new ConceptSupertopicFinder(dataLocation, concept, fromYear, toYear);
                (List<string> conceptSupertopics, Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> conceptSupertopicFreqsByWorkByYear)
                    = conceptSupertopicFinder.LoadSupertopics(stepProgress, true);
                OutputSupertopics(true, isbSupertopics, isbSupertopicFreqsByWorkByYear, csoSupertopics, csoSupertopicFreqsByWorkByYear, conceptSupertopics, conceptSupertopicFreqsByWorkByYear);
            }
            GC.Collect();
            totalProgress?.Report(100);
        }
    }
}
