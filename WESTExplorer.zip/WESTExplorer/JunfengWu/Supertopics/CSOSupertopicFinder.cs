﻿using System;
using System.Diagnostics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Synonyms;
using JunfengWu.Tools;

namespace JunfengWu.Supertopics
{
    public class CSOSupertopicFinder: AbstractSupertopicFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public WordEmbeddingVectors wvs { get; private set; }
        public MyCSO myCSO { get; private set; }
        public WordEmbeddingVectors.Matcher matcher { get; private set; }

        public CSOSupertopicFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            string supertopicPath = dataLocation.GetSubfieldDirectory(concept.id, "Supertopics");
            myFileName = Path.Combine(supertopicPath, $"CSO-{fromYear}-{toYear}.txt");
            myFileName2 = Path.Combine(supertopicPath, $"CSO-future-{fromYear}-{toYear}.txt");
            done = MD5Check.Check(myFileName) && MD5Check.Check(myFileName2);
            totalProgress?.Report(0);
            if (!done)
            {
                string csoPath = dataLocation.Get("csoDataPath");
                wvs = new WordEmbeddingVectors(csoPath, stepProgress);
                totalProgress?.Report(33);
                myCSO = new MyCSO(csoPath, wvs, 10, 0.8, stepProgress);
                totalProgress?.Report(66);
                matcher = new WordEmbeddingVectors.Matcher(wvs, stepProgress);
            }
            totalProgress?.Report(100);
        }

        Dictionary<int, int> GetTitleSupertopics(string title)
        {
            Dictionary<int, int> topicFreqs = new Dictionary<int, int>();
            List<string> parts;
            var matches = matcher.Match(title, out parts);
            foreach (var match in matches)
            {
                int topicID = myCSO.GetTopicID(match.termID);
                if (topicID >= 0)
                {
                    int oldFreq;
                    if (topicFreqs.TryGetValue(topicID, out oldFreq))
                    {
                        topicFreqs[topicID] = oldFreq + 1;
                    }
                    else
                    {
                        topicFreqs[topicID] = 1;
                    }
                }
            }
            return topicFreqs;
        }

        Dictionary<int, int> GetDocumentSupertopics(WorkEntity work)
        {
            Debug.Assert(work != null);

            Dictionary<int, int> topicFreqs = GetTitleSupertopics(work.title);

            if (work.references != null)
            {
                foreach (UInt64 referenceId in work.references)
                {
                    WorkEntity refWork = new WorkEntity(referenceId, dataLocation);
                    if (refWork != null && refWork.id == referenceId)
                    {
                        Dictionary<int, int> refTopicFreqs = GetTitleSupertopics(refWork.title);
                        foreach (var kv in refTopicFreqs)
                        {
                            int oldFreq;
                            if (topicFreqs.TryGetValue(kv.Key, out oldFreq))
                            {
                                topicFreqs[kv.Key] = oldFreq + kv.Value;
                            }
                            else
                            {
                                topicFreqs[kv.Key] = kv.Value;
                            }
                        }
                    }
                }
            }

            Dictionary<int, int> frequentTopicFreqs = new Dictionary<int, int>();
            if (topicFreqs.Count > 0)
            {
                float sumFreqs = 0f;
                foreach (var kv in topicFreqs)
                {
                    sumFreqs += kv.Value;
                }
                float meanFreqs = sumFreqs / Convert.ToSingle(topicFreqs.Count);
                foreach (var kv in topicFreqs)
                {
                    if (kv.Value >= meanFreqs)
                    {
                        frequentTopicFreqs.Add(kv.Key, kv.Value);
                    }
                }
            }
            
            return frequentTopicFreqs;
        }

        void Find(bool future, IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            UInt16 y1, y2;
            int totalProgress0, totalProgress1;
            string fileName;
            if (future)
            {
                y1 = Convert.ToUInt16(toYear + 1);
                y2 = Convert.ToUInt16(toYear + 10);
                totalProgress0 = 50;
                totalProgress1 = 100;
                fileName = myFileName2;
            }
            else
            {
                y1 = Convert.ToUInt16(fromYear - 10);
                y2 = toYear;
                totalProgress0 = 0;
                totalProgress1 = 50;
                fileName = myFileName;
            }

            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    totalProgress?.Report(totalProgress0);
                    for (UInt16 year = y1; year <= y2; year++)
                    {
                        stepProgress?.Report(0);
                        for (int idxBucket = 0; idxBucket < 64; idxBucket++)
                        {
                            List<WorkEntity> worksOfYear = WorkEntity.LoadSubfieldBucket(idxBucket, dataLocation, concept.id, year);
                            foreach (WorkEntity work in worksOfYear)
                            {
                                Dictionary<int, int> supertopicFreqs = GetDocumentSupertopics(work);
                                writer.Write($"{work.id},{year}");
                                foreach (var kv in supertopicFreqs)
                                {
                                    int topicId = kv.Key;
                                    int freq = kv.Value;
                                    string supertopic = myCSO.GetTopicName(topicId);
                                    if (supertopic.Contains(':'))
                                    {
                                        supertopic = supertopic.Replace(':', '_');
                                    }
                                    writer.Write($",{supertopic}:{freq}");
                                }
                                writer.WriteLine();
                            }
                            stepProgress?.Report(100 * (idxBucket + 1) / 64);
                        }
                        totalProgress?.Report(totalProgress0 + (totalProgress1 - totalProgress0) * (year - y1 + 1) / (y2 - y1 + 1));
                    }
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            Find(false, totalProgress, stepProgress);
            Find(true, totalProgress, stepProgress);
        }
    }
}

