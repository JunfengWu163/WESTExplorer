﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Synonyms;
using JunfengWu.Tools;
using JunfengWu.FastText;

namespace JunfengWu.Supertopics
{
    public class ISBSupertopicFinder: AbstractSupertopicFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public string myFileName3 { get; private set; }
        FastTextModel fastTextModel;

        public ISBSupertopicFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.fastTextModel = fastTextModel;
            string supertopicPath = dataLocation.GetSubfieldDirectory(concept.id, "Supertopics");
            myFileName = Path.Combine(supertopicPath, $"ISB-{fromYear}-{toYear}.txt");
            myFileName2 = Path.Combine(supertopicPath, $"ISB-future-{fromYear}-{toYear}.txt");
            myFileName3 = Path.Combine(supertopicPath, $"ISB-mapping-{fromYear}-{toYear}.txt");
            done = MD5Check.Check(myFileName) && MD5Check.Check(myFileName2) && MD5Check.Check(myFileName3);
        }

        // since a synonym can appear in multiple works, the following method is key to unify the size of each synonym.
        // final size of synonym = item2 / item1 of value
        Dictionary<string, (int, float)> GetSynonymSizes(Dictionary<UInt64, Dictionary<string, (int, float)>> synonymsByDoc)
        {
            Dictionary<string, (int, float)> synonymSizes = new Dictionary<string, (int, float)>();
            UInt64[] workIds = new UInt64[synonymsByDoc.Count];
            synonymsByDoc.Keys.CopyTo(workIds, 0);
            Parallel.ForEach(workIds,
                () => { return new Dictionary<string, (int, float)>(); },
                (workId, loopState, localSizes) =>
                {
                    Dictionary<string, (int, float)> synonymsOfWork = synonymsByDoc[workId];
                    foreach (var kv in synonymsOfWork)
                    {
                        (int, float) size;
                        if (!localSizes.TryGetValue(kv.Key, out size))
                        {
                            localSizes.Add(kv.Key, kv.Value);
                        }
                        else
                        {
                            localSizes[kv.Key] = (size.Item1 + kv.Value.Item1, size.Item2 + kv.Value.Item2);
                        }
                    }
                    return localSizes;
                },
                localSizes =>
                {
                    lock (synonymSizes)
                    {
                        foreach (var kv1 in localSizes)
                        {
                            (int, float) size;
                            if (!synonymSizes.TryGetValue(kv1.Key, out size))
                            {
                                synonymSizes.Add(kv1.Key, kv1.Value);
                            }
                            else
                            {
                                synonymSizes[kv1.Key] = (size.Item1 + kv1.Value.Item1, size.Item2 + kv1.Value.Item2);
                            }
                        }
                    }
                }
                );
            return synonymSizes;
        }

        Dictionary<string, string> CreateSynonymToSupertopicMapping(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            totalProgress?.Report(0);

            // 30% total progress
            SynonymFinder synonymFinder = new SynonymFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
            Dictionary<UInt64, Dictionary<string, (int, float)>> synonymsByDoc = new Dictionary<ulong, Dictionary<string, (int, float)>>();
            int stepProgressValue;
            for (UInt16 year = fromYear; year <= toYear; year++)
            {
                stepProgress?.Report(0);
                stepProgressValue = 0;
                Dictionary<UInt64, Dictionary<string, (int, float)>> synonymsByDocOfYear = synonymFinder.LoadSynonymsByDoc(year);
                int numDocsOfYear = synonymsByDocOfYear.Count;
                int numDocsAdded = 0;
                foreach (var kv in synonymsByDocOfYear)
                {
                    synonymsByDoc[kv.Key] = kv.Value;
                    numDocsAdded++;
                    int newStepProgressValue = 100 * numDocsAdded / numDocsOfYear;
                    if (newStepProgressValue > stepProgressValue)
                    {
                        stepProgressValue = newStepProgressValue;
                        stepProgress?.Report(newStepProgressValue);
                    }
                }
                stepProgress?.Report(100);
                totalProgress?.Report(30 * (year - fromYear + 1) / (toYear - fromYear + 1));
            }

            // 10% total progress
            stepProgress?.Report(0);
            Dictionary<string, (int, float)> synonymSizes = GetSynonymSizes(synonymsByDoc);
            string[] synonyms = new string[synonymSizes.Count];
            synonymSizes.Keys.CopyTo(synonyms, 0);
            stepProgress?.Report(100);
            totalProgress?.Report(40);

            // 10% total progress
            // superterm identification
            // superterm identification by breath-first connectivity search
            stepProgress?.Report(0);
            stepProgressValue = 0;
            Dictionary<int, HashSet<int>> neighborsInTermGraph = new Dictionary<int, HashSet<int>>();
            float[][] vectors = new float[synonyms.Length][];
            for (int termID = 0; termID < synonyms.Length; termID++)
            {
                neighborsInTermGraph[termID] = new HashSet<int>();
                vectors[termID] = fastTextModel.GetFormVector(synonyms[termID]);
                int newStepProgressValue = 100 * (termID + 1) / synonyms.Length;
                if (newStepProgressValue > stepProgressValue)
                {
                    stepProgressValue = newStepProgressValue;
                    stepProgress?.Report(newStepProgressValue);
                }
            }
            stepProgress?.Report(100);
            totalProgress?.Report(50);
            GC.Collect();

            // 20% total progress
            Console.WriteLine("Computing KNN");
            int knnK = 5;
            CosineKNN knn = new CosineKNN(vectors, new Progress<(int, string)>(v => { stepProgress?.Report(v.Item1); }), knnK);
            vectors = null;
            totalProgress?.Report(70);
            GC.Collect();

            // 10% total progress
            Console.WriteLine("Creating neighbor graph");
            stepProgress?.Report(0);
            int numBatches = 10;
            for (int idxBatch = 0; idxBatch < numBatches; idxBatch++)
            {
                int i0Term = synonyms.Length * idxBatch / numBatches;
                int i1Term = synonyms.Length * (idxBatch + 1) / numBatches;
                for (int termID = i0Term; termID < i1Term; termID++)
                {
                    (int freq, float sumDist) = synonymSizes[synonyms[termID]];
                    float meanDist = freq > 0 ? sumDist / freq : 0;
                    for (int idxNeighbor = 0; idxNeighbor < knnK; idxNeighbor++)
                    {
                        (uint neighborID, float distance) = knn.knns[termID, idxNeighbor];
                        if (neighborID == uint.MaxValue)
                        {
                            break;
                        }

                        (int neighborFreq, float neighborSumDist) = synonymSizes[synonyms[neighborID]];
                        float neighborMeanDist = neighborFreq > 0 ? neighborSumDist / neighborFreq : 0;
                        if (meanDist > distance && neighborMeanDist > distance)
                        {
                            neighborsInTermGraph[termID].Add((int)neighborID);
                            neighborsInTermGraph[(int)neighborID].Add(termID);
                        }
                    }
                }
                Console.WriteLine($"neighbor graph batch {idxBatch} of {numBatches} has completed");
                stepProgress?.Report(100 * (idxBatch + 1) / numBatches);
            }
            totalProgress?.Report(80);
            GC.Collect();

            // 20% total progress
            Console.WriteLine("Merging terms");
            HashSet<int> mergedTermIDs = new HashSet<int>();
            List<HashSet<int>> superTerms = new List<HashSet<int>>();
            List<int> superTermReprs = new List<int>();
            stepProgress?.Report(0);
            for (int idxBatch = 0; idxBatch < numBatches; idxBatch++)
            {
                int i0Term = synonyms.Length * idxBatch / numBatches;
                int i1Term = synonyms.Length * (idxBatch + 1) / numBatches;
                for (int termID = i0Term; termID < i1Term; termID++)
                {
                    if (mergedTermIDs.Contains(termID))
                        continue;
                    int bestRepr = termID;
                    int bestReprFreq = synonymSizes[synonyms[termID]].Item1;
                    HashSet<int> superTerm = new HashSet<int>();
                    superTerm.Add(termID);
                    mergedTermIDs.Add(termID);
                    HashSet<int> borderTermIDs = new HashSet<int>();
                    borderTermIDs.Add(termID);
                    while (borderTermIDs.Count > 0)
                    {
                        HashSet<int> newBorderTermIDs = new HashSet<int>();
                        foreach (int borderTermID in borderTermIDs)
                        {
                            HashSet<int> neighborIDs = neighborsInTermGraph[borderTermID];
                            foreach (int neighborID in neighborIDs)
                            {
                                if (superTerm.Contains(neighborID))
                                    continue;
                                superTerm.Add(neighborID);
                                mergedTermIDs.Add(neighborID);
                                newBorderTermIDs.Add(neighborID);
                                int neighborFreq = synonymSizes[synonyms[neighborID]].Item1;
                                if (neighborFreq > bestReprFreq)
                                {
                                    bestRepr = neighborID;
                                    bestReprFreq = neighborFreq;
                                }
                            }
                        }
                        borderTermIDs = newBorderTermIDs;
                    }
                    superTerms.Add(superTerm);
                    superTermReprs.Add(bestRepr);
                }
                Console.WriteLine($"merge term batch {idxBatch} of {numBatches} has completed");
                stepProgress?.Report(100 * (idxBatch + 1) / numBatches);
            }
            totalProgress?.Report(100);
            GC.Collect();

            // create the mapping from each synonym to its supertopic
            Dictionary<string, string> supertopics = new Dictionary<string, string>();
            for (int i = 0; i < superTerms.Count; i++)
            {
                string supertopic = synonyms[superTermReprs[i]];
                foreach (int synonymId in superTerms[i])
                {
                    supertopics[synonyms[synonymId]] = supertopic;
                }
            }
            return supertopics;
        }

        void OutputSupertopicMappings(Dictionary<string, string> synonymToSupertopic)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Supertopics");
            string supertopicPath = dataLocation.GetSubfieldDirectory(concept.id, "Supertopics");
            using (FileStream file = File.Create(myFileName3))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    foreach (var kv in synonymToSupertopic)
                    {
                        writer.WriteLine($"{kv.Key}->{kv.Value}");
                    }
                }
            }
            MD5Check.SaveMD5Hash(myFileName3);
        }

        void FindSupertopicMappings(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (MD5Check.Check(myFileName3))
            {
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Supertopics");
            Dictionary<string, string> synonymToSupertopic = CreateSynonymToSupertopicMapping(totalProgress, stepProgress);
            OutputSupertopicMappings(synonymToSupertopic);
        }

        void OutputSupertopics(bool future, List<string> supertopics, Dictionary<UInt64, (UInt16, Dictionary<int, int>)> supertopicInfosByWork)
        {
            string fileName = future ? myFileName2 : myFileName;
            for (int i = 0; i < supertopics.Count; i++)
            {
                if (supertopics[i].Contains(':'))
                {
                    supertopics[i] = supertopics[i].Replace(':', '_');
                }
            }
            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    foreach (var kv1 in supertopicInfosByWork)
                    {
                        UInt64 workId = kv1.Key;
                        UInt16 year = kv1.Value.Item1;
                        Dictionary<int, int> supertopicFreqsOfWork = kv1.Value.Item2;
                        if (supertopicFreqsOfWork.Count > 0)
                        {
                            writer.Write($"{workId},{year}");
                            foreach (var kv2 in supertopicFreqsOfWork)
                            {
                                string supertopic = supertopics[kv2.Key];
                                int freq = kv2.Value;
                                writer.Write($",{supertopic}:{freq}");
                            }
                            writer.WriteLine();
                        }
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
            }
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            Progress<int> mappingProgress = new Progress<int>(value => totalProgress.Report(value / 3));
            FindSupertopicMappings(mappingProgress, stepProgress);
            if (!MD5Check.Check(myFileName))
            {
                (List<string> supertopics, Dictionary<UInt64, (UInt16, Dictionary<int, int>)> supertopicInfosByWork)
                    = LoadSupertopicsInternal(stepProgress, false);
                OutputSupertopics(false, supertopics, supertopicInfosByWork);
            }
            totalProgress?.Report(66);
            if (!MD5Check.Check(myFileName2))
            {
                (List<string> supertopics, Dictionary<UInt64, (UInt16, Dictionary<int, int>)> supertopicInfosByWork)
                    = LoadSupertopicsInternal(stepProgress, true);
                OutputSupertopics(true, supertopics, supertopicInfosByWork);
            }
            totalProgress?.Report(100);
        }

        public Dictionary<string, string> LoadSynonymToSupertopicMapping()
        {
            Dictionary<string, string> synonymToSupertopic = new Dictionary<string, string>();
            using (FileStream file = File.OpenRead(myFileName3))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split("->");
                        if (parts.Length == 2)
                        {
                            synonymToSupertopic[parts[0]] = parts[1];
                        }
                        line = reader.ReadLine();
                    }
                }
            }
            return synonymToSupertopic;
        }

        (List<string>, Dictionary<UInt64, (UInt16, Dictionary<int, int>)>) LoadSupertopicsInternal(IProgress<int> progress, bool future = false)
        {
            List<string> supertopics = new List<string>();
            Dictionary<string, int> supertopicIds = new Dictionary<string, int>();
            Dictionary<UInt64, (UInt16, Dictionary<int, int>)> supertopicInfosByWork = new Dictionary<UInt64, (UInt16, Dictionary<int, int>)>();
            if (MD5Check.Check(myFileName3))
            {
                SynonymFinder synonymFinder = new SynonymFinder(dataLocation, concept, fromYear, toYear, fastTextModel);

                UInt16 y1, y2;
                if (future)
                {
                    y1 = Convert.ToUInt16(toYear + 1);
                    y2 = Convert.ToUInt16(toYear + 10);
                }
                else
                {
                    y1 = Convert.ToUInt16(fromYear - 10);
                    y2 = toYear;
                }

                Dictionary<string, string> synonymToSupertopic = LoadSynonymToSupertopicMapping();
                foreach (var kv in synonymToSupertopic)
                {
                    string supertopic = kv.Value;
                    if (!supertopicIds.ContainsKey(supertopic))
                    {
                        int id = supertopicIds.Count;
                        supertopicIds.Add(supertopic, id);
                        supertopics.Add(supertopic);
                    }
                }

                progress?.Report(0);
                for (UInt16 year = y1; year <= y2; year++)
                {
                    Dictionary<UInt64, Dictionary<string, (int, float)>> synonymsByDoc = synonymFinder.LoadSynonymsByDoc(year);
                    foreach (var kv1 in synonymsByDoc)
                    {
                        UInt64 workId = kv1.Key;
                        Dictionary<string, (int, float)> synonymsOfWork = kv1.Value;
                        Dictionary<int, int> supertopicFreqsOfWork = new Dictionary<int, int>();
                        foreach (var kv2 in synonymsOfWork)
                        {
                            string synonym = kv2.Key;
                            int freq = kv2.Value.Item1;
                            string supertopic;
                            if (synonymToSupertopic.TryGetValue(synonym, out supertopic))
                            {
                                int superTopicId = supertopicIds[supertopic];
                                int oldFreq;
                                if (supertopicFreqsOfWork.TryGetValue(superTopicId, out oldFreq))
                                {
                                    supertopicFreqsOfWork[superTopicId] = oldFreq + freq;
                                }
                                else
                                {
                                    supertopicFreqsOfWork[superTopicId] = freq;
                                }
                            }

                        }
                        supertopicInfosByWork[workId] = (year, supertopicFreqsOfWork);
                    }
                    progress?.Report(100 * (year - y1 + 1) / (y2 - y1 + 1));
                }
            }
            return (supertopics, supertopicInfosByWork);
        }
    }
}
