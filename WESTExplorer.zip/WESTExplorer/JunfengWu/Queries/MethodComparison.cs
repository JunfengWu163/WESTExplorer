﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Synonyms;
using JunfengWu.Topics;
using JunfengWu.Predictions;
using JunfengWu.Verifications;
using JunfengWu.Tools;
using JunfengWu.FastText;
using static JunfengWu.Queries.MethodComparison;

namespace JunfengWu.Queries
{
    public class MethodComparison
    {
        public enum Metric
        {
            KAccuracy,
            MAccuracy,
            KTopicGrowthRatio,
            MTopicGrowthRatio,
            KTopicRiseDuration,
            MTopicRiseDuration,
            KEffectiveness,
            MEffectiveness
        }

        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public int m { get; private set; }
        public List<EmergingnessPredictor.TopicType> methods { get; private set; }
        List<EmergingnessPredictor.TopicType> ISBV2Methods = new List<EmergingnessPredictor.TopicType>();
        FastTextModel fastTextModel;


        public MethodComparison(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, int m, List<EmergingnessPredictor.TopicType> methods, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.m = m;
            this.methods = methods;
            this.ISBV2Methods = new List<EmergingnessPredictor.TopicType>();
            foreach (var method in methods)
            {
                if (EmergingnessPredictor.IsISBV2Variant(method))
                {
                    this.ISBV2Methods.Add(method);
                }
            }
            this.fastTextModel = fastTextModel;
        }

        public void Compare(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            totalProgress?.Report(0);
            CompareByMetric(Metric.KAccuracy, stepProgress);
            totalProgress?.Report(5);
            RankByMetric(Metric.KAccuracy, stepProgress, true);
            totalProgress?.Report(10);
            RankByMetric(Metric.KAccuracy, stepProgress, false);
            totalProgress?.Report(15);
            CompareByMetric(Metric.MAccuracy, stepProgress);
            totalProgress?.Report(20);
            RankByMetric(Metric.MAccuracy, stepProgress, true);
            totalProgress?.Report(25);
            RankByMetric(Metric.MAccuracy, stepProgress, false);
            totalProgress?.Report(30);
            CompareByMetric(Metric.KTopicGrowthRatio, stepProgress);
            totalProgress?.Report(35);
            CompareByMetric(Metric.MTopicGrowthRatio, stepProgress);
            totalProgress?.Report(40);
            CompareByMetric(Metric.KTopicRiseDuration, stepProgress);
            totalProgress?.Report(45);
            CompareByMetric(Metric.MTopicRiseDuration, stepProgress);
            totalProgress?.Report(50);
            CompareByMetric(Metric.KEffectiveness, stepProgress);
            totalProgress?.Report(55);
            CompareByMetric(Metric.MEffectiveness, stepProgress);
            totalProgress?.Report(60);
            CompareByMetrics(Metric.KAccuracy, Metric.KTopicGrowthRatio, stepProgress);
            totalProgress?.Report(65);
            CompareByMetrics(Metric.KAccuracy, Metric.KTopicRiseDuration, stepProgress);
            totalProgress?.Report(70);
            CompareByMetrics(Metric.KTopicGrowthRatio, Metric.KTopicRiseDuration, stepProgress);
            totalProgress?.Report(100);
        }

        public static string GetMetricString(Metric metric)
        {
            string prefix;
            switch (metric)
            {
                case Metric.KAccuracy:
                    {
                        prefix = "KAccuracy";
                    }
                    break;
                case Metric.MAccuracy:
                    {
                        prefix = "MAccuracy";
                    }
                    break;
                case Metric.KTopicGrowthRatio:
                    {
                        prefix = "KTopicGrowthRatio";
                    }
                    break;
                case Metric.MTopicGrowthRatio:
                    {
                        prefix = "MTopicGrowthRatio";
                    }
                    break;
                case Metric.KTopicRiseDuration:
                    {
                        prefix = "KTopicRiseDuration";
                    }
                    break;
                case Metric.MTopicRiseDuration:
                    {
                        prefix = "MTopicRiseDuration";
                    }
                    break;
                case Metric.KEffectiveness:
                    {
                        prefix = "KEffectiveness";
                    }
                    break;
                case Metric.MEffectiveness:
                    {
                        prefix = "MEffectiveness";
                    }
                    break;
                default:
                    {
                        prefix = "Unknown";
                    }
                    break;
            }
            return prefix;
        }

        bool ISKMetric(Metric metric)
        {
            switch (metric)
            {
                case Metric.KAccuracy:
                case Metric.KTopicGrowthRatio:
                case Metric.KTopicRiseDuration:
                case Metric.KEffectiveness:
                    return true;
                default:
                    return false;
            }
        }

        string GetFileName(int l, int n, Metric metric)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Queries");
            string queryPath = dataLocation.GetSubfieldDirectory(concept.id, "Queries");
            return Path.Combine(queryPath, $"{GetMetricString(metric)}-{fromYear}-{toYear}-{methods.Count}-{l}-{n}.csv");
        }

        string GetFileName(int l, int n, Metric metric1, Metric metric2)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Queries");
            string queryPath = dataLocation.GetSubfieldDirectory(concept.id, "Queries");
            return Path.Combine(queryPath, $"{GetMetricString(metric1)}-{GetMetricString(metric2)}-{fromYear}-{toYear}-{methods.Count}-{l}-{n}.csv");
        }

        string GetFileNameForRanking(int l, int n, Metric metric, bool useMax)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Queries");
            string queryPath = dataLocation.GetSubfieldDirectory(concept.id, "Queries");
            string prefix = useMax ? "MaxRanking" : "SumRanking";
            return Path.Combine(queryPath, $"{prefix}-{GetMetricString(metric)}-{fromYear}-{toYear}-{methods.Count}-{l}-{n}.csv");
        }

        struct MetricStatistics
        {
            public int n;
            public double sum;
            public double avg;
            public double max;
            public double med;
        }

        struct BiMetricStatistics
        {
            public int n;
            public (double, double)[] points;
        }

        MetricStatistics GetStatistics(double[] predictions, double[] verifications, int m)
        {
            Debug.Assert(predictions.Length == verifications.Length);
            int[] predRank = new int[predictions.Length];
            for (int i = 0; i < predictions.Length; i++)
            {
                predRank[i] = i;
            }
            Array.Sort(predRank, (x, y) => Math.Sign(predictions[y] - predictions[x]));

            MetricStatistics statistics = new MetricStatistics();
            statistics.n = Math.Min(m, predictions.Length);
            statistics.sum = 0;
            statistics.max = 0;
            for (int i = 0; i < statistics.n; i++)
            {
                if (predictions[predRank[i]] <= 0)
                {
                    statistics.n = i;
                    break;
                }
                statistics.sum += verifications[predRank[i]];
                if (verifications[predRank[i]] > statistics.max)
                {
                    statistics.max = verifications[predRank[i]];
                }
            }
            if (statistics.n > 0)
            {
                statistics.avg = statistics.sum / statistics.n;
                double[] temp = new double[statistics.n];
                for (int i = 0; i < statistics.n && i < predRank.Length; i++)
                {
                    temp[i] = verifications[predRank[i]];
                }
                Array.Sort(temp);
                statistics.med = temp[statistics.n / 2];
            }
            else
            {
                statistics.avg = 0;
                statistics.med = 0;
            }
            return statistics;
        }

        BiMetricStatistics GetStatistics(double[] predictions, double[] verifications1, double[] verifications2, int m)
        {
            Debug.Assert(predictions.Length == verifications1.Length && predictions.Length == verifications2.Length);
            int[] predRank = new int[predictions.Length];
            for (int i = 0; i < predictions.Length; i++)
            {
                predRank[i] = i;
            }
            Array.Sort(predRank, (x, y) => Math.Sign(predictions[y] - predictions[x]));

            BiMetricStatistics statistics = new BiMetricStatistics();
            statistics.n = Math.Min(m, predictions.Length);
            for (int i = 0; i < statistics.n; i++)
            {
                if (predictions[predRank[i]] <= 0)
                {
                    statistics.n = i;
                    break;
                }
            }
            statistics.points = new (double, double)[statistics.n];
            for (int i = 0; i < statistics.n; i++)
            {
                int j = predRank[i];
                statistics.points[i] = (verifications1[j], verifications2[j]);
            }
            return statistics;
        }

        (List<MetricStatistics[]>, List<string[]>, List<int[][]>) CollectComparisonInfo(Metric metric, IProgress<int> progress, bool isbV2Only)
        {
            List<MetricStatistics[]> statisticsByMethod = new List<MetricStatistics[]>();
            List<string[]> descriptionsByMethod = new List<string[]>();
            List<int[][]> hitsByMethod = new List<int[][]>();
            progress?.Report(0);
            List<EmergingnessPredictor.TopicType> myMethods = isbV2Only ? ISBV2Methods : methods;
            for (int idxMethod = 0; idxMethod < myMethods.Count; idxMethod++)
            {
                EmergingnessPredictor.TopicType method = myMethods[idxMethod];
                if (ISKMetric(metric))
                {
                    MetricStatistics[] statisticsOfMethod = new MetricStatistics[k];
                    string[] descriptionsOfMethod = new string[k];
                    int[][] hitsOfMethod = new int[k][];
                    for (int l = 1; l <= k; l++)
                    {
                        if (metric == Metric.KEffectiveness)
                        {
                            EffectivenessVerifier verifier = new EffectivenessVerifier(dataLocation, concept, fromYear, toYear, l, m, method, fastTextModel);
                            (string description, int[] hits) = verifier.LoadVerifications(l, m);
                            descriptionsOfMethod[l - 1] = description;
                            hitsOfMethod[l - 1] = hits;
                        }
                        else
                        {
                            EmergingnessPredictor predictor = new EmergingnessPredictor(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                            double[] predictions = predictor.LoadPredictions();
                            double[] verifications;
                            switch (metric)
                            {
                                case Metric.KAccuracy:
                                    {
                                        EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                        verifications = verifier.LoadVerifications();
                                    }
                                    break;
                                case Metric.KTopicGrowthRatio:
                                    {
                                        TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                        verifications = evaluator.LoadVerifications();
                                    }
                                    break;
                                case Metric.KTopicRiseDuration:
                                default:
                                    {
                                        TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                        verifications = evaluator.LoadVerifications();
                                    }
                                    break;
                            }
                            statisticsOfMethod[l - 1] = GetStatistics(predictions, verifications, m);
                        }
                    }

                    statisticsByMethod.Add(statisticsOfMethod);
                    descriptionsByMethod.Add(descriptionsOfMethod);
                    hitsByMethod.Add(hitsOfMethod);
                }
                else
                {
                    MetricStatistics[] statisticsOfMethod = new MetricStatistics[m];
                    string[] descriptionsOfMethod = new string[m];
                    int[][] hitsOfMethod = new int[m][];
                    if (metric == Metric.MEffectiveness)
                    {
                        EffectivenessVerifier verifier = new EffectivenessVerifier(dataLocation, concept, fromYear, toYear, k, m, method, fastTextModel);
                        for (int n = 1; n <= m; n++)
                        {
                            (string description, int[] hits) = verifier.LoadVerifications(k, n);
                            descriptionsOfMethod[n - 1] = description;
                            hitsOfMethod[n - 1] = hits;
                        }
                    }
                    else
                    {
                        EmergingnessPredictor predictor = new EmergingnessPredictor(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                        double[] predictions = predictor.LoadPredictions();
                        double[] verifications;
                        switch (metric)
                        {
                            case Metric.MAccuracy:
                                {
                                    EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                    verifications = verifier.LoadVerifications();
                                }
                                break;
                            case Metric.MTopicGrowthRatio:
                                {
                                    TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                    verifications = evaluator.LoadVerifications();
                                }
                                break;
                            case Metric.MTopicRiseDuration:
                            default:
                                {
                                    TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                    verifications = evaluator.LoadVerifications();
                                }
                                break;
                        }
                        for (int n = 1; n <= m; n++)
                        {
                            statisticsOfMethod[n - 1] = GetStatistics(predictions, verifications, n);
                        }
                    }

                    statisticsByMethod.Add(statisticsOfMethod);
                    descriptionsByMethod.Add(descriptionsOfMethod);
                    hitsByMethod.Add(hitsOfMethod);
                }
                progress?.Report(100 * (idxMethod + 1) / methods.Count);
            }

            return (statisticsByMethod, descriptionsByMethod, hitsByMethod);
        }

        List<BiMetricStatistics[]> CollectComparisonInfo(Metric metric1, Metric metric2, IProgress<int> progress, bool isbV2Only)
        {
            Debug.Assert(metric1 != Metric.KEffectiveness && metric2 != Metric.KEffectiveness);
            Debug.Assert(ISKMetric(metric1) && ISKMetric(metric2));
            
            List<BiMetricStatistics[]> statisticsByMethod = new List<BiMetricStatistics[]>();
            progress?.Report(0);
            List<EmergingnessPredictor.TopicType> myMethods = isbV2Only ? ISBV2Methods : methods;
            for (int idxMethod = 0; idxMethod < myMethods.Count; idxMethod++)
            {
                EmergingnessPredictor.TopicType method = myMethods[idxMethod];
                if (ISKMetric(metric1))
                {
                    BiMetricStatistics[] statisticsOfMethod = new BiMetricStatistics[k];
                    for (int l = 1; l <= k; l++)
                    {
                        EmergingnessPredictor predictor = new EmergingnessPredictor(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                        double[] predictions = predictor.LoadPredictions();
                        
                        double[] verifications1;
                        switch (metric1)
                        {
                            case Metric.KAccuracy:
                                {
                                    EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications1 = verifier.LoadVerifications();
                                }
                                break;
                            case Metric.KTopicGrowthRatio:
                                {
                                    TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications1 = evaluator.LoadVerifications();
                                }
                                break;
                            case Metric.KTopicRiseDuration:
                            default:
                                {
                                    TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications1 = evaluator.LoadVerifications();
                                }
                                break;
                        }

                        double[] verifications2;
                        switch (metric2)
                        {
                            case Metric.KAccuracy:
                                {
                                    EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications2 = verifier.LoadVerifications();
                                }
                                break;
                            case Metric.KTopicGrowthRatio:
                                {
                                    TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications2 = evaluator.LoadVerifications();
                                }
                                break;
                            case Metric.KTopicRiseDuration:
                            default:
                                {
                                    TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, l, method, fastTextModel);
                                    verifications2 = evaluator.LoadVerifications();
                                }
                                break;
                        }

                        statisticsOfMethod[l - 1] = GetStatistics(predictions, verifications1, verifications2, m);
                    }

                    statisticsByMethod.Add(statisticsOfMethod);
                }
                else
                {
                    BiMetricStatistics[] statisticsOfMethod = new BiMetricStatistics[m];
                    EmergingnessPredictor predictor = new EmergingnessPredictor(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                    double[] predictions = predictor.LoadPredictions();
                    
                    double[] verifications1;
                    switch (metric1)
                    {
                        case Metric.MAccuracy:
                            {
                                EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications1 = verifier.LoadVerifications();
                            }
                            break;
                        case Metric.MTopicGrowthRatio:
                            {
                                TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications1 = evaluator.LoadVerifications();
                            }
                            break;
                        case Metric.MTopicRiseDuration:
                        default:
                            {
                                TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications1 = evaluator.LoadVerifications();
                            }
                            break;
                    }

                    double[] verifications2;
                    switch (metric2)
                    {
                        case Metric.MAccuracy:
                            {
                                EmergingnessVerifier verifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications2 = verifier.LoadVerifications();
                            }
                            break;
                        case Metric.MTopicGrowthRatio:
                            {
                                TopicGrowthRatioEvaluator evaluator = new TopicGrowthRatioEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications2 = evaluator.LoadVerifications();
                            }
                            break;
                        case Metric.MTopicRiseDuration:
                        default:
                            {
                                TopicRiseDurationEvaluator evaluator = new TopicRiseDurationEvaluator(dataLocation, concept, fromYear, toYear, k, method, fastTextModel);
                                verifications2 = evaluator.LoadVerifications();
                            }
                            break;
                    }

                    for (int n = 1; n <= m; n++)
                    {
                        statisticsOfMethod[n - 1] = GetStatistics(predictions, verifications1, verifications2, n);
                    }

                    statisticsByMethod.Add(statisticsOfMethod);
                }
                progress?.Report(100 * (idxMethod + 1) / methods.Count);
            }

            return statisticsByMethod;
        }

        void CompareByMetric(Metric metric, IProgress<int> progress)
        {
            string fileName = GetFileName(k, m, metric);
            if (MD5Check.Check(fileName))
            {
                return;
            }

            (List<MetricStatistics[]> statisticsByMethod, List<string[]> descriptionsByMethod, List<int[][]> hitsByMethod)
                = CollectComparisonInfo(metric, progress, false);

            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    if (metric == Metric.KEffectiveness)
                    {
                        writer.Write("method,l,topic");
                        for (UInt16 year = fromYear; year <= toYear + 10; year++)
                        {
                            writer.Write($",{year}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            string methodString = EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]);
                            for (int l = 1; l <= k; l++)
                            {
                                string description = descriptionsByMethod[idxMethod][l - 1];
                                int[] hits = hitsByMethod[idxMethod][l - 1];
                                writer.Write($"{methodString},{l},{description}");
                                for (int j = 0; j < hits.Length; j++)
                                {
                                    writer.Write($",{hits[j]}");
                                }
                                writer.WriteLine();
                            }
                        }
                    }
                    else if (metric == Metric.MEffectiveness)
                    {
                        writer.Write("method,n,topic");
                        for (UInt16 year = fromYear; year <= toYear + 10; year++)
                        {
                            writer.Write($",{year}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            string methodString = EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]);
                            for (int n = 1; n <= m; n++)
                            {
                                string description = descriptionsByMethod[idxMethod][n - 1];
                                int[] hits = hitsByMethod[idxMethod][n - 1];
                                writer.Write($"{methodString},{n},{description}");
                                for (int j = 0; j < hits.Length; j++)
                                {
                                    writer.Write($",{hits[j]}");
                                }
                                writer.WriteLine();
                            }
                        }
                    }
                    else if (ISKMetric(metric))
                    {
                        writer.Write("n of method \\ l");
                        for (int l = 1; l <= k; l++)
                        {
                            writer.Write($",{l}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int l = 1; l <= k; l++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][l - 1].n}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("sum of method \\ l");
                        for (int l = 1; l <= k; l++)
                        {
                            writer.Write($",{l}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int l = 1; l <= k; l++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][l - 1].sum}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("avg of method \\ l");
                        for (int l = 1; l <= k; l++)
                        {
                            writer.Write($",{l}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int l = 1; l <= k; l++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][l - 1].avg}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("max of method \\ l");
                        for (int l = 1; l <= k; l++)
                        {
                            writer.Write($",{l}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int l = 1; l <= k; l++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][l - 1].max}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("med of method \\ l");
                        for (int l = 1; l <= k; l++)
                        {
                            writer.Write($",{l}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int l = 1; l <= k; l++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][l - 1].med}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();
                    }
                    else
                    {
                        writer.Write("n of method \\ n");
                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($",{n}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int n = 1; n <= m; n++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][n - 1].n}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("sum of method \\ n");
                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($",{n}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int n = 1; n <= m; n++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][n - 1].sum}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("avg of method \\ n");
                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($",{n}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int n = 1; n <= m; n++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][n - 1].avg}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("max of method \\ n");
                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($",{n}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int n = 1; n <= m; n++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][n - 1].max}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();

                        writer.Write("med of method \\ n");
                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($",{n}");
                        }
                        writer.WriteLine();

                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            writer.Write(EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]));
                            for (int n = 1; n <= m; n++)
                            {
                                writer.Write($",{statisticsByMethod[idxMethod][n - 1].med}");
                            }
                            writer.WriteLine();
                        }
                        writer.WriteLine();
                    }
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }

        void CompareByMetrics(Metric metric1, Metric metric2, IProgress<int> progress)
        {
            string fileName = GetFileName(k, m, metric1, metric2);
            if (MD5Check.Check(fileName))
            {
                return;
            }

            List<BiMetricStatistics[]> statisticsByMethod = CollectComparisonInfo(metric1, metric2, progress, false);
            
            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    progress?.Report(0);
                    for (int l = 1; l <= k; l++)
                    {
                        writer.WriteLine($"points of methods for k = {l}");
                        writer.Write("method.dim");
                        for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                        {
                            string methodName = EmergingnessPredictor.GetTopicTypeString(methods[idxMethod]);
                            writer.Write($",{methodName}.x,{methodName}.y");
                        }
                        writer.WriteLine();

                        for (int n = 1; n <= m; n++)
                        {
                            writer.Write($"{n}");
                            for (int idxMethod = 0; idxMethod < methods.Count; idxMethod++)
                            {
                                BiMetricStatistics s = statisticsByMethod[idxMethod][l - 1];
                                (double x, double y) = n <= s.n ? s.points[n - 1] : (0, 0);
                                writer.Write($",{x},{y}");
                            }
                            writer.WriteLine();
                        }

                        writer.WriteLine();
                        progress?.Report(100 * l / k);
                    }
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }

        int GetRank(int i, int[] revRank, int j, List<MetricStatistics[]> statisticsByMethod, bool useMax)
        {
            int rank = i;
            if (useMax)
            {
                while (rank > 0 && statisticsByMethod[revRank[rank - 1]][j].max == statisticsByMethod[revRank[rank]][j].max)
                    rank--;
            }
            else
            {
                while (rank > 0 && statisticsByMethod[revRank[rank - 1]][j].sum == statisticsByMethod[revRank[rank]][j].sum)
                    rank--;
            }
            return rank;
        }

        int GetRank(int i, int[] revRank, double[] value, double[] value2)
        {
            int rank = i;
            while (rank > 0 && value[revRank[rank - 1]] == value[revRank[rank]] && value2[revRank[rank - 1]] == value2[revRank[rank]])
                rank--;
            return rank;
        }

        int DoubleCompare(int x, int y, double[] value, double[] value2)
        {
            if (value[x] > value[y])
                return -1;
            if (value[x] < value[y])
                return 1;
            if (value2[x] < value2[y])
                return -1;
            if (value2[x] > value2[y])
                return 1;
            return 0;
        }
        (double[], int[], int[], int[], double[]) GetRankStatistics(Metric metric, List<MetricStatistics[]> statisticsByMethod, bool useMax)
        {
            double[] avgRanks = new double[ISBV2Methods.Count];
            int[] bestRanks = new int[ISBV2Methods.Count];
            int[] medRanks = new int[ISBV2Methods.Count];
            int[] revRankByMaxMax = new int[ISBV2Methods.Count];
            List<int[]> ranksHistory = new List<int[]>();
            double[] maxByMethod = new double[ISBV2Methods.Count];
            for (int i = 0; i < ISBV2Methods.Count; i++)
            {
                maxByMethod[i] = double.NegativeInfinity;
            }

            int uboundIdx = ISKMetric(metric) ? k : m;
            for (int idx = 0; idx < uboundIdx; idx++)
            {
                int[] revRanks = new int[ISBV2Methods.Count];
                for (int i = 0; i < ISBV2Methods.Count; i++)
                {
                    revRanks[i] = i;
                    if (useMax)
                    {
                        if (maxByMethod[i] < statisticsByMethod[i][idx].max)
                        {
                            maxByMethod[i] = statisticsByMethod[i][idx].max;
                        }
                    }
                    else
                    {
                        if (maxByMethod[i] < statisticsByMethod[i][idx].sum)
                        {
                            maxByMethod[i] = statisticsByMethod[i][idx].sum;
                        }
                    }
                }
                if (useMax)
                    Array.Sort(revRanks, (x, y) => Math.Sign(statisticsByMethod[y][idx].max - statisticsByMethod[x][idx].max));
                else
                    Array.Sort(revRanks, (x, y) => Math.Sign(statisticsByMethod[y][idx].sum - statisticsByMethod[x][idx].sum));
                int[] ranksByMethod = new int[ISBV2Methods.Count];
                for (int i = 0; i < ISBV2Methods.Count; i++)
                {
                    ranksByMethod[revRanks[i]] = GetRank(i, revRanks, idx, statisticsByMethod, useMax);
                }
                ranksHistory.Add(ranksByMethod);
            }

            for (int i = 0; i < ISBV2Methods.Count; i++)
            {
                double sumRank = 0;
                int bestRank = ISBV2Methods.Count;
                int[] myRankHistory = new int[ranksHistory.Count];
                for (int j = 0; j < ranksHistory.Count; j++)
                {
                    int rank = ranksHistory[j][i];
                    sumRank += rank;
                    if (rank < bestRank)
                    {
                        bestRank = rank;
                    }
                    myRankHistory[j] = rank;
                }
                Array.Sort(myRankHistory);
                avgRanks[i] = sumRank / ranksHistory.Count;
                bestRanks[i] = bestRank;
                medRanks[i] = myRankHistory[myRankHistory.Length / 2];
            }
            for (int i = 0; i < ISBV2Methods.Count; i++)
            {
                revRankByMaxMax[i] = i;
            }
            Array.Sort(revRankByMaxMax, (x, y) => DoubleCompare(x, y, maxByMethod, avgRanks));
            int[] ranksByMaxMax = new int[ISBV2Methods.Count];
            for (int i = 0; i < ISBV2Methods.Count; i++)
            {
                ranksByMaxMax[revRankByMaxMax[i]] = GetRank(i, revRankByMaxMax, maxByMethod, avgRanks);
            }
            return (avgRanks, bestRanks, medRanks, ranksByMaxMax, maxByMethod);
        }

        void RankByMetric(Metric metric, IProgress<int> progress, bool useMax)
        {
            string fileName = GetFileNameForRanking(k, m, metric, useMax);
            
            (List<MetricStatistics[]> statisticsByMethod, List<string[]> descriptionsByMethod, List<int[][]> hitsByMethod)
                = CollectComparisonInfo(metric, progress, true);

            using (FileStream file = File.Create(fileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    if (metric != Metric.KEffectiveness && metric != Metric.MEffectiveness)
                    {
                        (double[] avgRanks, int[] bestRanks, int[] medRanks, int[] ranksByMax, double[] maxByMethod) = GetRankStatistics(metric, statisticsByMethod, useMax);
                        string rankType = useMax ? "max" : "sum";
                        writer.WriteLine($"method,avg rank,best rank,med rank,rank by max {rankType},max {rankType}");
                        
                        for (int idxMethod = 0; idxMethod < ISBV2Methods.Count; idxMethod++)
                        {
                            writer.WriteLine($"{EmergingnessPredictor.GetTopicTypeString(ISBV2Methods[idxMethod])},{avgRanks[idxMethod]},{bestRanks[idxMethod]},{medRanks[idxMethod]},{ranksByMax[idxMethod]},{maxByMethod[idxMethod]}");
                        }
                    }
                }
            }
            MD5Check.SaveMD5Hash(fileName);
        }
    }
}

