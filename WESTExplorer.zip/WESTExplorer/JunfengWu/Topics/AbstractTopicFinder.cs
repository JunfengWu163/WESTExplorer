﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Tools;

namespace JunfengWu.Topics
{
    public abstract class AbstractTopicFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }

        public string myFileName { get; private set; }
        public bool done { get; protected set; }
        protected Dictionary<UInt16, Dictionary<int, int>> nodeWeightsByYear = new Dictionary<UInt16, Dictionary<int, int>>();
        protected Dictionary<UInt16, Dictionary<long, int>> edgeWeightsByYear = new Dictionary<UInt16, Dictionary<long, int>>();

        public void Init(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, string prefix)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            string topicPath = dataLocation.GetSubfieldDirectory(concept.id, "Topics");
            myFileName = Path.Combine(topicPath, $"{prefix}-{fromYear}-{toYear}-{k}.txt");
            done = MD5Check.Check(myFileName);
        }

        public abstract void Find(IProgress<int> totalProgress, IProgress<int> stepProgress);

        protected void InitWeights(UInt16[] years)
        {
            foreach (UInt16 year in years)
            {
                nodeWeightsByYear[year] = new Dictionary<int, int>();
                edgeWeightsByYear[year] = new Dictionary<long, int>();
            }
        }

        protected void ReleaseWeights()
        {
            nodeWeightsByYear.Clear();
            edgeWeightsByYear.Clear();
        }

        protected void UpdateWeights(Dictionary<int, int> localNodeFreqs, UInt16 year)
        {
            int[] localNodeIds = new int[localNodeFreqs.Count];
            localNodeFreqs.Keys.CopyTo(localNodeIds, 0);
            for (int i1 = 0; i1 < localNodeIds.Length; i1++)
            {
                UpdateNodeWeights(localNodeIds[i1], year);
                for (int i2 = i1 + 1; i2 < localNodeIds.Length; i2++)
                {
                    long edgeId = ComposeEdge(localNodeIds[i1], localNodeIds[i2]);
                    UpdateEdgeWeights(edgeId, year);
                }
            }
        }

        void UpdateNodeWeights(int id, UInt16 year)
        {
            Dictionary<int, int> nodeWeightsOfYear;
            if (!nodeWeightsByYear.TryGetValue(year, out nodeWeightsOfYear))
            {
                nodeWeightsOfYear = new Dictionary<int, int>();
                lock(nodeWeightsByYear)
                {
                    nodeWeightsByYear[year] = nodeWeightsOfYear;
                }
            }
            int oldFreq;
            if (nodeWeightsOfYear.TryGetValue(id, out oldFreq))
            {
                nodeWeightsOfYear[id] = oldFreq + 1;
            }
            else
            {
                nodeWeightsOfYear[id] = 1;
            }
        }

        protected long ComposeEdge(int id1, int id2)
        {
            if (id1 < id2)
            {
                return (Convert.ToInt64(id1) << 32) | Convert.ToInt64(id2);
            }
            else
            {
                return (Convert.ToInt64(id2) << 32) | Convert.ToInt64(id1);
            }
        }

        protected (int, int) DecomposeEdge(long edgeId)
        {
            int id1 = Convert.ToInt32(edgeId >> 32);
            int id2 = Convert.ToInt32(edgeId & 0xffffffff);
            return (id1, id2);
        }

        void UpdateEdgeWeights(long edgeId, UInt16 year)
        {
            Dictionary<long, int> edgeWeightsOfYear;
            if (!edgeWeightsByYear.TryGetValue(year, out edgeWeightsOfYear))
            {
                edgeWeightsOfYear = new Dictionary<long, int>();
                lock (edgeWeightsByYear)
                {
                    edgeWeightsByYear[year] = edgeWeightsOfYear;
                }
            }
            int oldFreq;
            if (edgeWeightsOfYear.TryGetValue(edgeId, out oldFreq))
            {
                edgeWeightsOfYear[edgeId] = oldFreq + 1;
            }
            else
            {
                edgeWeightsOfYear[edgeId] = 1;
            }
        }

        protected float GetNodeWeight(int id, UInt16 year)
        {
            Dictionary<int, int> nodeWeightsOfYear;
            if (!nodeWeightsByYear.TryGetValue(year, out nodeWeightsOfYear))
            {
                return 0;
            }
            int w;
            if (!nodeWeightsOfYear.TryGetValue(id, out w))
            {
                return 0;
            }
            return w;
        }

        protected float GetEdgeAccumulatedWeight(long edgeId, UInt16 year)
        {
            float sumW = 0;
            foreach (var kv1 in edgeWeightsByYear)
            {
                UInt16 weightYear = kv1.Key;
                if (weightYear <= year)
                {
                    Dictionary<long, int> edgeWeightsOfYear = kv1.Value;
                    int w;
                    if (edgeWeightsOfYear.TryGetValue(edgeId, out w))
                    {
                        sumW += w;
                    }
                }
            }
            return sumW;
        }

        protected float GetNodeAccumulatedWeight(int id, UInt16 year)
        {
            float sumW = 0;
            foreach (var kv1 in nodeWeightsByYear)
            {
                UInt16 weightYear = kv1.Key;
                if (weightYear <= year)
                {
                    Dictionary<int, int> nodeWeightsOfYear = kv1.Value;
                    int w;
                    if (nodeWeightsOfYear.TryGetValue(id, out w))
                    {
                        sumW += w;
                    }
                }
            }
            return sumW;
        }

        protected float GetEdgeNormalizedWeight(long edgeId, UInt16 year)
        {
            (int id1, int id2) = DecomposeEdge(edgeId);
            float w1 = GetNodeAccumulatedWeight(id1, year);
            float w2 = GetNodeAccumulatedWeight(id2, year);
            if (w1 == 0 || w2 == 0)
                return 0;
            float w12 = GetEdgeAccumulatedWeight(edgeId, year);
            if (w12 == 0)
                return 0;
            return 2.0f / (w1 / w12 + w2 / w12);
        }

        protected int[] GetNodeIds()
        {
            HashSet<int> nodeIdSet = new HashSet<int>();
            foreach (var kv1 in nodeWeightsByYear)
            {
                nodeIdSet.UnionWith(kv1.Value.Keys);
            }
            int[] nodeIds = new int[nodeIdSet.Count];
            nodeIdSet.CopyTo(nodeIds, 0);
            Array.Sort(nodeIds);
            return nodeIds;
        }

        protected long[] GetEdgeIds()
        {
            HashSet<long> edgeIdSet = new HashSet<long>();
            foreach (var kv1 in edgeWeightsByYear)
            {
                edgeIdSet.UnionWith(kv1.Value.Keys);
            }
            long[] edgeIds = new long[edgeIdSet.Count];
            edgeIdSet.CopyTo(edgeIds, 0);
            Array.Sort(edgeIds);
            return edgeIds;
        }

        protected int GetNodeIndex(int[] nodeIds, int id)
        {
            int iStart = 0, iEnd = nodeIds.Length - 1;
            while (iStart <= iEnd)
            {
                int iMiddle = (iStart + iEnd) >> 1;
                if (id == nodeIds[iMiddle])
                {
                    return iMiddle;
                }
                else if (id < nodeIds[iMiddle])
                {
                    iEnd = iMiddle - 1;
                }
                else
                {
                    iStart = iMiddle + 1;
                }
            }
            return -1;
        }

        protected int GetEdgeIndex(long[] edgeIds, long edgeId)
        {
            int iStart = 0, iEnd = edgeIds.Length - 1;
            while (iStart <= iEnd)
            {
                int iMiddle = (iStart + iEnd) >> 1;
                if (edgeId == edgeIds[iMiddle])
                {
                    return iMiddle;
                }
                else if (edgeId < edgeIds[iMiddle])
                {
                    iEnd = iMiddle - 1;
                }
                else
                {
                    iStart = iMiddle + 1;
                }
            }
            return -1;
        }

        float GetNodePaceOfGrowth(int id, UInt16 fromYear, UInt16 toYear)
        {
            double[] accWeights = new double[toYear - fromYear + 1];
            for (UInt16 year = fromYear; year <= toYear; year++)
            {
                accWeights[year - fromYear] = GetNodeWeight(id, year);
            }
            return Convert.ToSingle(WeightedLeastSquares.FitLine(accWeights).Item2);
        }

        protected float[] GetNodePacesOfGrowth(int[] nodeIds, UInt16 fromYear, UInt16 toYear, IProgress<int> progress)
        {
            float[] pog = new float[nodeIds.Length];
            progress?.Report(0);
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int i0 = pog.Length * idxBatch / 100;
                int i1 = pog.Length * (idxBatch + 1) / 100;
                Parallel.For(i0, i1, i => {
                    int id = nodeIds[i];
                    pog[i] = GetNodePaceOfGrowth(id, fromYear, toYear);
                });
                progress?.Report(idxBatch + 1);
            }
            return pog;
        }

        protected float GetEdgePaceOfCollaboration(long edgeId, UInt16 fromYear, UInt16 toYear)
        {
            double[] accWeights = new double[toYear - fromYear + 1];
            for (UInt16 year = fromYear; year <= toYear; year++)
            {
                accWeights[year - fromYear] = GetEdgeNormalizedWeight(edgeId, year);
            }
            return Convert.ToSingle(WeightedLeastSquares.FitLine(accWeights).Item2);
        }

        protected float[] GetEdgePacesOfCollaboration(long[] edgeIds, UInt16 fromYear, UInt16 toYear, IProgress<int> progress)
        {
            float[] poc = new float[edgeIds.Length];
            progress?.Report(0);
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int i0 = poc.Length * idxBatch / 100;
                int i1 = poc.Length * (idxBatch + 1) / 100;
                Parallel.For(i0, i1, i => {
                    long edgeId = edgeIds[i];
                    poc[i] = GetEdgePaceOfCollaboration(edgeId, fromYear, toYear);
                });
                progress?.Report(idxBatch + 1);
            }
            return poc;
        }
        
        protected Dictionary<long, float> GetGrowingEdges(long[] edgeIds, float[] poc, int[] nodeIds, float[] pog, float thres, IProgress<int> progress)
        {
            Dictionary<long, float> growingEdges = new Dictionary<long, float>();
            progress?.Report(0);
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int i0 = edgeIds.Length * idxBatch / 100;
                int i1 = edgeIds.Length * (idxBatch + 1) / 100;
                for (int i = i0; i < i1; i++)
                {
                    if (poc[i] < thres)
                        continue;
                    (int id1, int id2) = DecomposeEdge(edgeIds[i]);
                    int j1 = GetNodeIndex(nodeIds, id1);
                    int j2 = GetNodeIndex(nodeIds, id2);
                    if (j1 < 0 || j2 < 0)
                        continue;
                    if (pog[j1] <= 0 || pog[j2] <= 0)
                        continue;
                    growingEdges.Add(edgeIds[i], poc[i]);
                }
                progress?.Report(idxBatch + 1);
            }
            
            return growingEdges;
        }

        List<Dictionary<long, float>> ConvertToEdgeForm(List<List<(int, int, float)>> topics)
        {
            List<Dictionary<long, float>> edgeFormTopics = new List<Dictionary<long, float>>();
            foreach (List<(int, int, float)> topic in topics)
            {
                Dictionary<long, float> edgeFormTopic = new Dictionary<long, float>();
                foreach ((int id1, int id2, float score) in topic)
                {
                    long edgeId = ComposeEdge(id1, id2);
                    float oldScore;
                    if (edgeFormTopic.TryGetValue(edgeId, out oldScore))
                    {
                        edgeFormTopic[edgeId] = oldScore + score;
                    }
                    else
                    {
                        edgeFormTopic[edgeId] = score;
                    }
                }
                edgeFormTopics.Add(edgeFormTopic);
            }
            return edgeFormTopics;
        }

        List<List<(int, int, float)>> ConvertFromEdgeForm(List<Dictionary<long, float>> edgeFormTopics)
        {
            List<List<(int, int, float)>> topics = new List<List<(int, int, float)>>();
            foreach (Dictionary<long, float> edgeFormTopic in edgeFormTopics)
            {
                List<KeyValuePair<long, float>> edgeForms = edgeFormTopic.ToList();
                edgeForms.Sort((x, y) => Math.Sign(y.Value - x.Value));
                List<(int, int, float)> topic = new List<(int, int, float)>();
                for (int i = 0; i < edgeForms.Count; i++)
                {
                    (int id1, int id2) = DecomposeEdge(edgeForms[i].Key);
                    topic.Add((id1, id2, edgeForms[i].Value));
                }
                topics.Add(topic);
            }
            return topics;
        }

        bool ContainsEdgeForms(Dictionary<long, float> edgeForms1, Dictionary<long, float>edgeForms2)
        {
            foreach (var kv in edgeForms1)
            {
                if (!edgeForms2.ContainsKey(kv.Key))
                    return false;
            }
            return true;
        }

        void MergeEdgeForms(Dictionary<long, float> edgeForms1, Dictionary<long, float> edgeForms2)
        {
            foreach (var kv in edgeForms2)
            {
                float oldScore;
                if (edgeForms1.TryGetValue(kv.Key, out oldScore))
                {
                    edgeForms1[kv.Key] = oldScore + kv.Value;
                }
                else
                {
                    edgeForms1.Add(kv.Key, kv.Value);
                }
            }
        }

        List<Dictionary<long, float>> Simplify(List<Dictionary<long, float>> edgeFormTopics)
        {
            List<Dictionary<long, float>> simplifiedEdgeFormTopics = new List<Dictionary<long, float>>();
            foreach (Dictionary<long, float> edgeFormTopic in edgeFormTopics)
            {
                bool merged = false;
                for (int i = 0; i < simplifiedEdgeFormTopics.Count; i++)
                {
                    if (ContainsEdgeForms(edgeFormTopic, simplifiedEdgeFormTopics[i]) || ContainsEdgeForms(simplifiedEdgeFormTopics[i], edgeFormTopic))
                    {
                        MergeEdgeForms(simplifiedEdgeFormTopics[i], edgeFormTopic);
                        merged = true;
                        break;
                    }
                }
                if (!merged)
                {
                    simplifiedEdgeFormTopics.Add(edgeFormTopic);
                }
            }
            return simplifiedEdgeFormTopics;
        }

        List<List<(int, int, float)>> Simplify(List<List<(int, int, float)>> topics)
        {
            return ConvertFromEdgeForm(Simplify(ConvertToEdgeForm(topics)));
        }

        protected void SaveTopics(List<List<(int, int, float)>> topics, List<string> supertopics)
        {
            List<List<(int, int, float)>> simplifiedTopics = Simplify(topics);
            dataLocation.CreateSubfieldDirectory(concept.id, "Topics");
            using (FileStream file = File.Create(myFileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    for (int topicId = 0; topicId < simplifiedTopics.Count; topicId++)
                    {
                        List<(int, int, float)> topic = simplifiedTopics[topicId];
                        for (int i = 0; i < topic.Count && i < k; i++)
                        {
                            if (i > 0)
                                writer.Write(',');
                            string supertopic1 = supertopics[topic[i].Item1];
                            string supertopic2 = supertopics[topic[i].Item2];
                            float score = topic[i].Item3;
                            writer.Write($"{supertopic1}&&{supertopic2}:{score}");
                        }
                        writer.WriteLine();
                    }
                }
            }
            MD5Check.SaveMD5Hash(myFileName);
        }

        public List<List<(int, int, float)>> LoadTopics(List<string> supertopics, IProgress<int> progress)
        {
            Dictionary<string, int> supertopicIds = new Dictionary<string, int>();
            for (int i = 0; i < supertopics.Count; i++)
            {
                supertopicIds.Add(supertopics[i], i);
            }
            List<List<(int, int, float)>> topics = new List<List<(int, int, float)>>();
            using (FileStream file = File.OpenRead(myFileName))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    progress?.Report(0);
                    int progressValue = 0;
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length > 0)
                        {
                            List<(int, int, float)> topic = new List<(int, int, float)>();
                            for (int i = 0; i < parts.Length; i++)
                            {
                                string[] properties = parts[i].Split(':');
                                if (properties.Length == 2)
                                {
                                    string[] supertopicPair = properties[0].Split("&&");
                                    int stid1, stid2;
                                    if (supertopicPair.Length == 2
                                        && supertopicIds.TryGetValue(supertopicPair[0], out stid1)
                                        && supertopicIds.TryGetValue(supertopicPair[1], out stid2))
                                    {
                                        float weight = Convert.ToSingle(properties[1]);
                                        topic.Add((stid1, stid2, weight));
                                    }
                                }
                            }
                            topics.Add(topic);
                        }
                        int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                        if (newProgressValue > progressValue)
                        {
                            progressValue = newProgressValue;
                            progress?.Report(newProgressValue);
                        }
                        line = reader.ReadLine();
                    }
                }
            }
            return topics;
        }

        public List<List<(string, string, float)>> LoadTopics(IProgress<int> progress)
        {
            List<List<(string, string, float)>> topics = new List<List<(string, string, float)>>();
            using (FileStream file = File.OpenRead(myFileName))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    progress?.Report(0);
                    int progressValue = 0;
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length > 0)
                        {
                            List<(string, string, float)> topic = new List<(string, string, float)>();
                            for (int i = 0; i < parts.Length; i++)
                            {
                                string[] properties = parts[i].Split(':');
                                if (properties.Length == 2)
                                {
                                    string[] supertopicPair = properties[0].Split("&&");
                                    if (supertopicPair.Length == 2)
                                    {
                                        float weight = Convert.ToSingle(properties[1]);
                                        topic.Add((supertopicPair[0], supertopicPair[1], weight));
                                    }
                                }
                            }
                            topics.Add(topic);
                        }
                        int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                        if (newProgressValue > progressValue)
                        {
                            progressValue = newProgressValue;
                            progress?.Report(newProgressValue);
                        }
                        line = reader.ReadLine();
                    }
                }
            }
            return topics;
        }
    }
}

