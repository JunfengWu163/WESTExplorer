﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Synonyms;
using JunfengWu.Supertopics;
using JunfengWu.Tools;
using JunfengWu.FastText;
using Python.Runtime;

namespace JunfengWu.Topics
{
    public class ISBTopicFinder: AbstractTopicFinder
    {
        public enum Version
        {
            OlderVersion,
            V2P,
            V3
        };

        public Version version { get; private set; }
        FastTextModel fastTextModel;
        int knnK;
        float eps;

        public ISBTopicFinder(DataLocation dataLocation, ConceptEntity concept,
            UInt16 fromYear, UInt16 toYear, int k, FastTextModel fastTextModel, Version version,
            int knnK = 10, float eps = 0.001f)
        {
            string prefix = version == Version.V3 ? "ISBV3" : version == Version.V2P ? "ISBV2P" : "ISB";
            Init(dataLocation, concept, fromYear, toYear, k, prefix);
            this.knnK = knnK;
            this.version = version;
            this.eps = eps;
            this.fastTextModel = fastTextModel;
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                Console.WriteLine($"{myFileName} is good.");
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Topics");
            SparseWeightKNN knn;
            UInt64[] workIds;
            List<string> supertopics;
            {
                // step 1, load supertopics
                totalProgress?.Report(0);
                Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> supertopicFreqsByWorkByYear;
                if (version == Version.V3)
                {
                    ISBV3SupertopicFinder supertopicFinder = new ISBV3SupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                    (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress);
                }
                else
                {
                    ISBSupertopicFinder supertopicFinder = new ISBSupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                    (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress);
                }
                int numDocs = 0;
                foreach (var kv1 in supertopicFreqsByWorkByYear)
                {
                    numDocs += kv1.Value.Count;
                }
                workIds = new UInt64[numDocs];
                UInt16[] workYears = new UInt16[numDocs];
                if (numDocs > 0) {
                    stepProgress?.Report(0);
                    int currentIdx = 0;
                    foreach (var kv1 in supertopicFreqsByWorkByYear)
                    {
                        UInt16 year = kv1.Key;
                        kv1.Value.Keys.CopyTo(workIds, currentIdx);
                        for (int j = 0; j < kv1.Value.Count; j++)
                        {
                            workYears[currentIdx + j] = year;
                        }
                        currentIdx += kv1.Value.Count;
                        stepProgress?.Report(100 * currentIdx / numDocs);
                    }
                }
                totalProgress?.Report(10);

                // step 2, update weights
                UInt16[] years = new UInt16[supertopicFreqsByWorkByYear.Count];
                supertopicFreqsByWorkByYear.Keys.CopyTo(years, 0);
                InitWeights(years);
                List<UInt16> updatedYears = new List<ushort>();
                stepProgress?.Report(0);
                Parallel.For(0, years.Length, i =>
                {
                    UInt16 year = years[i];
                    Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWorkOfYear = supertopicFreqsByWorkByYear[years[i]];
                    foreach (var kv1 in supertopicFreqsByWorkOfYear)
                    {
                        UpdateWeights(kv1.Value, year);
                    }
                    lock(updatedYears)
                    {
                        updatedYears.Add(year);
                        stepProgress?.Report(100 * updatedYears.Count / years.Length);
                    }
                });
                totalProgress?.Report(20);

                // step 3, get growing edges
                Dictionary<long, float> growingEdges;
                if (version == Version.OlderVersion)
                {
                    long[] edgeIds = GetEdgeIds();
                    float[] poc = GetEdgePacesOfCollaboration(edgeIds, fromYear, toYear, stepProgress);
                    totalProgress?.Report(25);

                    growingEdges = new Dictionary<long, float>();
                    stepProgress?.Report(0);
                    for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                    {
                        int i0 = edgeIds.Length * idxBatch / 100;
                        int i1 = edgeIds.Length * (idxBatch + 1) / 100;
                        for (int i = i0; i < i1; i++)
                        {
                            growingEdges[edgeIds[i]] = poc[i];
                        }
                        stepProgress?.Report(idxBatch + 1);
                    }
                    totalProgress?.Report(35);
                }
                else
                {
                    int[] nodeIds = GetNodeIds();
                    float[] pog = GetNodePacesOfGrowth(nodeIds, fromYear, toYear, stepProgress);
                    totalProgress?.Report(25);

                    long[] edgeIds = GetEdgeIds();
                    float[] poc = GetEdgePacesOfCollaboration(edgeIds, fromYear, toYear, stepProgress);
                    totalProgress?.Report(30);

                    growingEdges = GetGrowingEdges(edgeIds, poc, nodeIds, pog, 0.01f, stepProgress);
                    totalProgress?.Report(35);
                }
                GC.Collect();

                // step 4, count supertopic document frequencies
                float[] STDFs = new float[supertopics.Count];
                Parallel.For(0, STDFs.Length, i =>
                {
                    STDFs[i] = GetNodeAccumulatedWeight(i, toYear);
                });
                totalProgress?.Report(40);

                // step 5, count supertopic pair document frequencies 
                long[] growingEdgeIds = new long[growingEdges.Count];
                growingEdges.Keys.CopyTo(growingEdgeIds, 0);
                float[] BTFs = new float[growingEdges.Count];
                Parallel.For(0, growingEdgeIds.Length, i =>
                {
                    BTFs[i] = GetEdgeAccumulatedWeight(growingEdgeIds[i], Convert.ToUInt16(fromYear - 1));
                });
                totalProgress?.Report(45);

                // step 6, get supertopic vecs
                ReleaseWeights();
                float[][] supertopicVecs = new float[supertopics.Count][];
                stepProgress?.Report(0);
                for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                {
                    int i0 = supertopics.Count * idxBatch / 100;
                    int i1 = supertopics.Count * (idxBatch + 1) / 100;
                    Parallel.For(i0, i1, i => {
                        supertopicVecs[i] = fastTextModel.GetFormVector(supertopics[i]);
                    });
                    stepProgress?.Report(idxBatch + 1);
                }
                totalProgress?.Report(50);

                // prepare knn
                knn = new SparseWeightKNN(growingEdgeIds);

                stepProgress?.Report(0);
                for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                {
                    int iStart = numDocs * idxBatch / 100;
                    int iStop = numDocs * (idxBatch + 1) / 100;
                    Parallel.For(iStart, iStop, i => {
                        KeyValuePair<int, int>[] freqs = supertopicFreqsByWorkByYear[workYears[i]][workIds[i]].ToArray();
                        Dictionary<long, float> isbVector = new Dictionary<long, float>();
                        for (int i1 = 0; i1 < freqs.Length; i1++)
                        {
                            int id1 = freqs[i1].Key;
                            int freq1 = freqs[i1].Value;
                            float[] vec1 = supertopicVecs[id1];
                            for (int i2 = i1 + 1; i2 < freqs.Length; i2++)
                            {
                                int id2 = freqs[i2].Key;
                                int freq2 = freqs[i2].Value;
                                long edgeId = ComposeEdge(id1, id2);
                                int j = GetEdgeIndex(growingEdgeIds, edgeId);
                                if (j < 0)
                                    continue;
                                float myBtf = BTFs[j];
                                float tfidf1 = freq1 * MathF.Log(numDocs / STDFs[id1]);
                                float tfidf2 = freq2 * MathF.Log(numDocs / STDFs[id2]);
                                float[] vec2 = supertopicVecs[id2];
                                float r11 = 0f, r22 = 0f, r12 = 0f;
                                for (int k = 0; k < vec1.Length; k++)
                                {
                                    r11 += vec1[k] * vec1[k];
                                    r22 += vec2[k] * vec2[k];
                                    r12 += vec1[k] * vec2[k];
                                }
                                float btsim = (r11 == 0 || r22 == 0) ? 0f : r12 / MathF.Sqrt(r11 * r22);
                                float value = tfidf1 * tfidf2 / (2f - (0.5f - 0.5f * btsim) * (5f / (5f + myBtf)));
                                isbVector.Add(edgeId, value);
                            }
                        }
                        knn.Add(Convert.ToUInt32(i), isbVector);
                    });
                    stepProgress?.Report(idxBatch + 1);
                }
                totalProgress?.Report(60);
            }
            GC.Collect();

            // cluster to seek topics
            stepProgress?.Report(0);
            List<uint> paperIDs = new List<uint>();
            ConcurrentDictionary<uint, int> paperIndices = new ConcurrentDictionary<uint, int>();
            for (uint i = 0; i < workIds.Length; i++)
            {
                paperIDs.Add(i);
                paperIndices[i] = (int)i;
            }
            Progress<int> progressDensity = new Progress<int>((value) => { totalProgress?.Report(60 + value / 10); stepProgress?.Report(value); });
            Progress<int> progressHDNeighbor = new Progress<int>((value) => { totalProgress?.Report(70 + value / 10); stepProgress?.Report(value);  });
            Progress<int> progressTree = new Progress<int>((value) => { totalProgress?.Report(80 + value / 10); stepProgress?.Report(value); });
            DensityPeakClustering dpc = new DensityPeakClustering(knn, paperIDs, paperIndices, knnK, eps, progressDensity, progressHDNeighbor, progressTree);
            totalProgress?.Report(90);

            // get topic descriptors
            List<List<uint>> clusters = new List<List<uint>>();
            List<List<Tuple<long, Tuple<int, float>>>> topicDescriptors = new List<List<Tuple<long, Tuple<int, float>>>>();
            int numClusters = dpc.GetNumClusters();
            stepProgress?.Report(0);
            for (int clusterID = 0; clusterID < numClusters; clusterID++)
            {
                clusters.Add(new List<uint>());
            }
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int i0 = paperIDs.Count * idxBatch / 100;
                int i1 = paperIDs.Count * (idxBatch + 1) / 100;
                Parallel.For<List<List<uint>>>(i0, i1,
                    () =>
                    {
                        List<List<uint>> localClusters = new List<List<uint>>();
                        for (int clusterID = 0; clusterID < numClusters; clusterID++)
                        {
                            localClusters.Add(new List<uint>());
                        }
                        return localClusters;
                    },
                    (i, loopState, localClusters) =>
                    {
                        uint paperID = paperIDs[i];
                        int clusterID = dpc.GetClusterID(i);
                        localClusters[clusterID].Add(paperID);
                        return localClusters;
                    },
                    localClusters =>
                    {
                        lock (clusters)
                        {
                            for (int clusterID = 0; clusterID < numClusters; clusterID++)
                            {
                                clusters[clusterID].AddRange(localClusters[clusterID]);
                            }
                        }
                    }
                    );
                stepProgress?.Report(idxBatch + 1);
            }
            totalProgress?.Report(92);
            
            stepProgress?.Report(0);
            for (int clusterID = 0; clusterID < numClusters; clusterID++)
            {
                topicDescriptors.Add(knn.Summarize(clusters[clusterID]));
                stepProgress?.Report(100 * (clusterID + 1) / numClusters);
            }
            totalProgress.Report(95);

            // save topic descriptors
            List<List<(int, int, float)>> topics = new List<List<(int, int, float)>>();
            stepProgress?.Report(0);
            for (int clusterId = 0; clusterId < numClusters; clusterId++)
            {
                List<Tuple<long, Tuple<int, float>>> summary = topicDescriptors[clusterId];
                if (summary.Count == 0) continue;
                List<(int, int, float)> topic = new List<(int, int, float)>();
                for (int idxSummary = 0; idxSummary < summary.Count && idxSummary < k; idxSummary++)
                {
                    long bitermId = summary[idxSummary].Item1;
                    (int supertopicId1, int supertopicId2) = DecomposeEdge(bitermId);
                    float score = summary[idxSummary].Item2.Item2;
                    topic.Add((supertopicId1, supertopicId2, score));
                }
                topics.Add(topic);
                stepProgress?.Report(100 * (clusterId + 1) / numClusters);
            }
            SaveTopics(topics, supertopics);
            totalProgress?.Report(100);
        }

    }
}
