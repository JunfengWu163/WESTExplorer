﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Supertopics;
using JunfengWu.Tools;
using JunfengWu.Synonyms;
using JunfengWu.FastText;

namespace JunfengWu.Topics
{
    public class TopicPublicationFinder
    {
        public enum TopicType
        {
            ISB,
            CSO,
            Concept,
            ISBV2P,
            ISBV3
        }
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public TopicType topicType { get; private set; }
        public bool done { get; private set; }
        public string myFileName { get; private set; }
        public string myFileName2 { get; private set; }
        FastTextModel fastTextModel;

        public TopicPublicationFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, TopicType topicType, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.topicType = topicType;
            this.fastTextModel = fastTextModel;
            myFileName = GetFileName(k);
            myFileName2 = GetFileName2(k);
            done = MD5Check.Check(myFileName) && MD5Check.Check(myFileName2);
        }

        string GetFileName(int l)
        {
            string topicPath = dataLocation.GetSubfieldDirectory(concept.id, "Topics");
            switch (topicType)
            {
                case TopicType.ISB:
                    {
                        return Path.Combine(topicPath, $"ISB-publications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.CSO:
                    {
                        return Path.Combine(topicPath, $"CSO-publications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.Concept:
                    {
                        return Path.Combine(topicPath, $"Concept-publications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.ISBV2P:
                    {
                        return Path.Combine(topicPath, $"ISBV2P-publications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.ISBV3:
                    {
                        return Path.Combine(topicPath, $"ISBV3-publications-{fromYear}-{toYear}-{l}.txt");
                    }
            }
            return "";
        }

        string GetFileName2(int l)
        {
            string topicPath = dataLocation.GetSubfieldDirectory(concept.id, "Topics");
            switch (topicType)
            {
                case TopicType.ISB:
                    {
                        return Path.Combine(topicPath, $"ISB-futurePublications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.CSO:
                    {
                        return Path.Combine(topicPath, $"CSO-futurePublications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.Concept:
                    {
                        return Path.Combine(topicPath, $"Concept-futurePublications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.ISBV2P:
                    {
                        return Path.Combine(topicPath, $"ISBV2P-futurePublications-{fromYear}-{toYear}-{l}.txt");
                    }
                case TopicType.ISBV3:
                    {
                        return Path.Combine(topicPath, $"ISBV3-futurePublications-{fromYear}-{toYear}-{l}.txt");
                    }
            }
            return "";
        }

        bool TopicContainsWork(List<(int, int, float)> topic, Dictionary<int, int> supertopicFreqsOfWork, int l)
        {
            for (int ll = 0; ll < l; ll++)
            {
                if (ll >= topic.Count)
                    break;

                (int supertopic1, int supertopic2, float weight) = topic[ll];
                if (supertopicFreqsOfWork.ContainsKey(supertopic1) && supertopicFreqsOfWork.ContainsKey(supertopic2))
                {
                    return true;
                }
            }
            return false;
        }

        bool TopicContainsWork(List<(string, string, float)> topic, HashSet<string> supertopicsOfWork, int l)
        {
            for (int ll = 0; ll < l; ll++)
            {
                if (ll >= topic.Count)
                    break;

                (string supertopic1, string supertopic2, float weight) = topic[ll];
                if (supertopicsOfWork.Contains(supertopic1) && supertopicsOfWork.Contains(supertopic2))
                {
                    return true;
                }
            }
            return false;
        }

        public void FindPublications(IProgress<int> totalProgress, IProgress<int> stepProgress, bool future = false)
        {
            if (MD5Check.Check(future ? myFileName2: myFileName))
            {
                return;
            }

            totalProgress?.Report(0);
            List<string> supertopics = null;
            Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> supertopicFreqsByWorkByYear = null;
            List<List<(int, int, float)>> topics = null;
            switch (topicType)
            {
                case TopicType.ISB:
                    {
                        ISBSupertopicFinder supertopicFinder = new ISBSupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                        (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress, future);
                        ISBTopicFinder topicFinder = new ISBTopicFinder(dataLocation, concept, fromYear, toYear, k, fastTextModel, ISBTopicFinder.Version.OlderVersion);
                        topics = topicFinder.LoadTopics(supertopics, stepProgress);
                    }
                    break;
                case TopicType.CSO:
                    {
                        CSOSupertopicFinder supertopicFinder = new CSOSupertopicFinder(dataLocation, concept, fromYear, toYear, null, null);
                        (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress, future);
                        AUGURTopicFinder topicFinder = new AUGURTopicFinder(dataLocation, concept, fromYear, toYear, true, k);
                        topics = topicFinder.LoadTopics(supertopics, stepProgress);
                    }
                    break;
                case TopicType.Concept:
                    {
                        ConceptSupertopicFinder supertopicFinder = new ConceptSupertopicFinder(dataLocation, concept, fromYear, toYear);
                        (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress, future);
                        AUGURTopicFinder topicFinder = new AUGURTopicFinder(dataLocation, concept, fromYear, toYear, false, k);
                        topics = topicFinder.LoadTopics(supertopics, stepProgress);
                    }
                    break;
                case TopicType.ISBV2P:
                    {
                        ISBV3SupertopicFinder supertopicFinder = new ISBV3SupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                        (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress, future);
                        ISBTopicFinder topicFinder = new ISBTopicFinder(dataLocation, concept, fromYear, toYear, k, fastTextModel, ISBTopicFinder.Version.V2P);
                        topics = topicFinder.LoadTopics(supertopics, stepProgress);
                    }
                    break;
                case TopicType.ISBV3:
                    {
                        ISBV3SupertopicFinder supertopicFinder = new ISBV3SupertopicFinder(dataLocation, concept, fromYear, toYear, fastTextModel);
                        (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress, future);
                        ISBTopicFinder topicFinder = new ISBTopicFinder(dataLocation, concept, fromYear, toYear, k, fastTextModel, ISBTopicFinder.Version.V3);
                        topics = topicFinder.LoadTopics(supertopics, stepProgress);
                    }
                    break;
            }
            totalProgress?.Report(10);

            if (topics != null && supertopics != null && supertopicFreqsByWorkByYear != null)
            {
                int numDocs = 0;
                foreach (var kv1 in supertopicFreqsByWorkByYear)
                {
                    numDocs += kv1.Value.Count;
                }
                UInt64[] workIds = new UInt64[numDocs];
                UInt16[] workYears = new UInt16[numDocs];
                {
                    int currentIdx = 0;
                    foreach (var kv1 in supertopicFreqsByWorkByYear)
                    {
                        UInt16 year = kv1.Key;
                        kv1.Value.Keys.CopyTo(workIds, currentIdx);
                        for (int j = 0; j < kv1.Value.Count; j++)
                        {
                            workYears[currentIdx + j] = year;
                        }
                        currentIdx += kv1.Value.Count;
                    }
                }

                for (int l = 1; l <= k; l++)
                {
                    string fileName = future ? GetFileName2(l) : GetFileName(l);
                    if (!MD5Check.Check(fileName))
                    {
                        Dictionary<UInt16, List<UInt64>>[] topicPublications = new Dictionary<UInt16, List<UInt64>>[topics.Count];
                        for (int j = 0; j < topics.Count; j++)
                        {
                            topicPublications[j] = new Dictionary<ushort, List<ulong>>();
                        }

                        stepProgress?.Report(0);
                        for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                        {
                            int jStart = topics.Count * idxBatch / 100;
                            int jStop = topics.Count * (idxBatch + 1) / 100;
                            Parallel.For(jStart, jStop, j =>
                            {
                                var topic = topics[j];
                                for (int i = 0; i < workIds.Length; i++)
                                {
                                    UInt64 workId = workIds[i];
                                    UInt16 year = workYears[i];
                                    Dictionary<int, int> supertopicFreqsOfWork = supertopicFreqsByWorkByYear[year][workId];
                                    if (TopicContainsWork(topic, supertopicFreqsOfWork, l))
                                    {
                                        List<UInt64> publicationsOfYear;
                                        if (!topicPublications[j].TryGetValue(year, out publicationsOfYear))
                                        {
                                            publicationsOfYear = new List<ulong>();
                                            topicPublications[j][year] = publicationsOfYear;
                                        }
                                        publicationsOfYear.Add(workId);
                                    }
                                }
                            });
                            stepProgress?.Report(idxBatch + 1);
                        }
                        using (FileStream file = File.Create(fileName))
                        {
                            using (StreamWriter writer = new StreamWriter(file))
                            {
                                for (int j = 0; j < topics.Count; j++)
                                {
                                    writer.Write($"{j}");
                                    foreach (var kv in topicPublications[j])
                                    {
                                        UInt16 year = kv.Key;
                                        List<UInt64> publicationsOfYear = kv.Value;
                                        writer.Write($";{year}");
                                        foreach (UInt64 id in publicationsOfYear)
                                        {
                                            writer.Write($",{id}");
                                        }
                                    }
                                    writer.WriteLine();
                                }
                            }
                        }
                        MD5Check.SaveMD5Hash(fileName);
                    }
                    totalProgress?.Report(10 + 90 * l / k);
                }
            }
            totalProgress?.Report(100);
        }

        public List<Dictionary<UInt16, List<UInt64>>> LoadTopicPublications(int l, IProgress<int> progress, bool future = false)
        {
            string fileName = future ? GetFileName2(l) : GetFileName(l);
            List<Dictionary<UInt16, List<UInt64>>> topicPublications = new List<Dictionary<ushort, List<ulong>>>();
            using (FileStream file = File.OpenRead(fileName))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    progress?.Report(0);
                    int progressValue = 0;
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split(';');
                        Debug.Assert(parts.Length > 0);
                        Debug.Assert(Convert.ToUInt32(parts[0]) == topicPublications.Count);

                        Dictionary<UInt16, List<UInt64>> publicationsOfTopic = new Dictionary<ushort, List<ulong>>();
                        for (int i = 1; i < parts.Length; i++)
                        {
                            string[] properties = parts[i].Split(',');
                            Debug.Assert(properties.Length >= 2);

                            UInt16 year = Convert.ToUInt16(properties[0]);

                            List<UInt64> workIdsOfYear = new List<ulong>();
                            for (int j = 1; j < properties.Length; j++)
                            {
                                UInt64 workId = Convert.ToUInt64(properties[j]);
                                workIdsOfYear.Add(workId);
                            }

                            publicationsOfTopic.Add(year, workIdsOfYear);
                        }

                        topicPublications.Add(publicationsOfTopic);

                        int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                        if (newProgressValue > progressValue)
                        {
                            progressValue = newProgressValue;
                            progress?.Report(progressValue);
                        }
                        line = reader.ReadLine();
                    }
                }
            }
            return topicPublications;
        }
    }
}

