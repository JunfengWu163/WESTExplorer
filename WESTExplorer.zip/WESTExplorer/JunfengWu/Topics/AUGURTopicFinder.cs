﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Xml;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Supertopics;
using JunfengWu.Tools;
using MathNet.Numerics;

namespace JunfengWu.Topics
{
    public class AUGURTopicFinder : AbstractTopicFinder
    {
        public bool useCSO { get; private set; }
        
        public List<string> supertopics { get; private set; } = new List<string>();
        
        public AUGURTopicFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, bool useCSO, int k)
        {
            Init(dataLocation, concept, fromYear, toYear, k, useCSO ? "CSO" : "Concept");
            this.useCSO = useCSO;
        }

        struct Clique
        {
            public int id1;
            public int id2;
            public int id3;
            public double w;
        }

        void InsertNodeNeighbor(Dictionary<int, HashSet<int>> nodeNeighbors, int id1, int id2)
        {
            HashSet<int> neighborsOf1;
            if (!nodeNeighbors.TryGetValue(id1, out neighborsOf1))
            {
                neighborsOf1 = new HashSet<int>();
                nodeNeighbors.Add(id1, neighborsOf1);
            }
            neighborsOf1.Add(id2);
        }

        List<Clique> DetectCliques(double wThres, Dictionary<long, float> growingEdges, IProgress<int> progress)
        {
            Console.WriteLine("Creating Node Neighbors");
            progress?.Report(0);
            Dictionary<int, HashSet<int>> nodeNeighbors = new Dictionary<int, HashSet<int>>();
            foreach (long edgeId in growingEdges.Keys)
            {
                (int id1, int id2) = DecomposeEdge(edgeId);
                InsertNodeNeighbor(nodeNeighbors, id1, id2);
                InsertNodeNeighbor(nodeNeighbors, id2, id1);
            }
            progress?.Report(10);

            Console.WriteLine("Detecting Cliques");
            List<Clique> cliques = new List<Clique>();
            int numTopics = nodeNeighbors.Count;
            int[] topicIds = new int[numTopics];
            nodeNeighbors.Keys.CopyTo(topicIds, 0);
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int iStart = numTopics * idxBatch / 100;
                int iStop = numTopics * (idxBatch + 1) / 100;
                Parallel.For(iStart, iStop,
                () => { return new List<Clique>(); },
                (idxTopic, loopState, localCliques) =>
                {
                    int topicId1 = topicIds[idxTopic];
                    int[] neighbors1 = nodeNeighbors[topicId1].ToArray();
                    Array.Sort(neighbors1);
                    for (int i2 = 0; i2 < neighbors1.Length; i2++)
                    {
                        int topicId2 = neighbors1[i2];
                        if (topicId1 >= topicId2)
                            continue;
                        long edgeId12 = ComposeEdge(topicId1, topicId2);
                        float w12 = growingEdges[edgeId12];
                        for (int i3 = i2 + 1; i3 < neighbors1.Length; i3++)
                        {
                            int topicId3 = neighbors1[i3];
                            if (topicId1 >= topicId3)
                                continue;
                            if (!nodeNeighbors[topicId2].Contains(topicId3))
                                continue;
                            Debug.Assert(topicId2 < topicId3);
                            long edgeId13 = ComposeEdge(topicId1, topicId3);
                            long edgeId23 = ComposeEdge(topicId2, topicId3);
                            double w13 = growingEdges[edgeId13];
                            double w23 = growingEdges[edgeId23];
                            double myW = 3.0 / (1.0 / w12 + 1.0 / w13 + 1.0 / w23);
                            if (myW >= wThres)
                            {
                                Clique clique = new Clique();
                                clique.id1 = topicId1;
                                clique.id2 = topicId2;
                                clique.id3 = topicId3;
                                clique.w = myW;
                                localCliques.Add(clique);
                            }
                        }
                    }
                    return localCliques;
                },
                localCliques =>
                {
                    lock (cliques)
                    {
                        cliques.AddRange(localCliques);
                    }
                }
                );
                progress?.Report(idxBatch + 1);
            }

            return cliques;
        }

        int[][] FindCliqueNeighbors(List<Clique> cliques, IProgress<int> progress)
        {
            int numCliques = cliques.Count;
            Dictionary<long, List<int>> cliquesByEdge = new Dictionary<long, List<int>>();
            progress?.Report(0);
            for (int idxBatch = 0; idxBatch < 50; idxBatch++)
            {
                int iStart = numCliques * idxBatch / 50;
                int iStop = numCliques * (idxBatch + 1) / 50;
                Parallel.For(iStart, iStop,
                    () => new Dictionary<long, List<int>>(),
                    (i, loopState, localCliquesByEdge) =>
                    {
                        (long edgeId1, long edgeId2, long edgeId3) = ComposeCliqueEdges(cliques[i]);
                        UpdateCliquesByEdge(localCliquesByEdge, edgeId1, i);
                        UpdateCliquesByEdge(localCliquesByEdge, edgeId2, i);
                        UpdateCliquesByEdge(localCliquesByEdge, edgeId3, i);
                        return localCliquesByEdge;
                    },
                    localCliquesByEdge =>
                    {
                        lock (cliquesByEdge)
                        {
                            foreach (var kv in localCliquesByEdge)
                            {
                                List<int> oldCliqueList;
                                if (cliquesByEdge.TryGetValue(kv.Key, out oldCliqueList))
                                {
                                    oldCliqueList.AddRange(kv.Value);
                                }
                                else
                                {
                                    cliquesByEdge.Add(kv.Key, kv.Value);
                                }
                            }
                        }
                    }
                    );
            }

            int[][] neighbors = new int[cliques.Count][];
            for (int idxBatch = 0; idxBatch < 50; idxBatch++)
            {
                int iStart = numCliques * idxBatch / 50;
                int iStop = numCliques * (idxBatch + 1) / 50;
                Parallel.For(iStart, iStop, i =>
                {
                    List<int> myNeighborIds = new List<int>();
                    (long edgeId1, long edgeId2, long edgeId3) = ComposeCliqueEdges(cliques[i]);
                    foreach (int cliqueId in cliquesByEdge[edgeId1])
                    {
                        if (cliqueId != i)
                        {
                            myNeighborIds.Add(cliqueId);
                        }
                    }
                    foreach (int cliqueId in cliquesByEdge[edgeId2])
                    {
                        if (cliqueId != i)
                        {
                            myNeighborIds.Add(cliqueId);
                        }
                    }
                    foreach (int cliqueId in cliquesByEdge[edgeId3])
                    {
                        if (cliqueId != i)
                        {
                            myNeighborIds.Add(cliqueId);
                        }
                    }
                    neighbors[i] = myNeighborIds.ToArray();
                });
                progress?.Report(50 + idxBatch + 1);
            }
            return neighbors;
        }

        void UpdateCliquesByEdge(Dictionary<long, List<int>> cliquesByEdge, long edgeId, int cliqueId)
        {
            List<int> oldCliqueList;
            if (!cliquesByEdge.TryGetValue(edgeId, out oldCliqueList))
            {
                oldCliqueList = new List<int>();
                cliquesByEdge[edgeId] = oldCliqueList;
            }
            oldCliqueList.Add(cliqueId);
        }

        List<(long, double)[]> DescribeLocalMaximas(List<Clique> cliques, int[][] cliqueNeighborIds, IProgress<int> progress)
        {
            int numCliques = cliques.Count;
            List<(long, double)[]> descriptions = new List<(long, double)[]>();
            progress?.Report(0);
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int iStart = numCliques * idxBatch / 100;
                int iStop = numCliques * (idxBatch + 1) / 100;
                Parallel.For(iStart, iStop,
                    () => { return new List<(long, double)[]>(); },
                    (i, loopState, localDescriptions) =>
                    {
                        bool isLocalMaxima = true;
                        foreach (int j in cliqueNeighborIds[i])
                        {
                            if (cliques[i].w < cliques[j].w)
                            {
                                isLocalMaxima = false;
                                break;
                            }
                        }
                        if (isLocalMaxima)
                        {
                            (long, double)[] topKEdges = FindTopKPaceOfCollaborationEdgesInO2(i, cliques, cliqueNeighborIds);
                            localDescriptions.Add(topKEdges);
                        }
                        return localDescriptions;
                    },
                    localDescriptions =>
                    {
                        lock (descriptions)
                        {
                            descriptions.AddRange(localDescriptions);
                        }
                    }
                    );
                progress?.Report(idxBatch + 1);
            }
            return descriptions;
        }

        (long, double)[] FindTopKPaceOfCollaborationEdgesInO2(int idxClique, List<Clique> cliques, int[][] cliqueNeighborIds)
        {
            HashSet<int> o2cliqueIds = new HashSet<int>();
            o2cliqueIds.Add(idxClique);
            foreach (int o1neighborId in cliqueNeighborIds[idxClique])
            {
                o2cliqueIds.Add(o1neighborId);
                foreach (int o2neighborId in cliqueNeighborIds[o1neighborId])
                {
                    o2cliqueIds.Add(o2neighborId);
                }
            }

            HashSet<long> o2edgeIds = new HashSet<long>();
            foreach (int o2Id in o2cliqueIds)
            {
                (long edgeId1, long edgeId2, long edgeId3) = ComposeCliqueEdges(cliques[o2Id]);
                o2edgeIds.Add(edgeId1);
                o2edgeIds.Add(edgeId2);
                o2edgeIds.Add(edgeId3);
            }

            long[] edgeIds = new long[o2edgeIds.Count];
            o2edgeIds.CopyTo(edgeIds);
            Array.Sort(edgeIds, (x, y) => Math.Sign(GetEdgePaceOfCollaboration(y, fromYear, toYear) - GetEdgePaceOfCollaboration(x, fromYear, toYear)));

            int l = Math.Min(k, edgeIds.Length);
            (long, double)[] topKEdges = new (long, double)[l];
            for (int i = 0; i < l; i++)
            {
                topKEdges[i] = (edgeIds[i], GetEdgePaceOfCollaboration(edgeIds[i], fromYear, toYear));
            }

            return topKEdges;
        }

        (long, long, long) ComposeCliqueEdges(Clique clique)
        {
            long edgeId1 = ComposeEdge(clique.id1, clique.id2);
            long edgeId2 = ComposeEdge(clique.id1, clique.id3);
            long edgeId3 = ComposeEdge(clique.id2, clique.id3);
            return (edgeId1, edgeId2, edgeId3);
        }

        void OutputTopics(List<(long, double)[]> topics2)
        {
            List<List<(int, int, float)>> topics = new List<List<(int, int, float)>>();
            for (int i = 0; i < topics2.Count; i++)
            {
                (long, double)[] topic2 = topics2[i];
                List<(int, int, float)> topic = new List<(int, int, float)>();
                for (int j = 0; j < topic2.Length; j++)
                {
                    (int id1, int id2) = DecomposeEdge(topic2[j].Item1);
                    float score = Convert.ToSingle(topic2[j].Item2);
                    topic.Add((id1, id2, score));
                }
                topics.Add(topic);
            }
            SaveTopics(topics, supertopics);
        }

        public override void Find(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                Console.WriteLine($"{myFileName} is good.");
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Topics");

            totalProgress?.Report(0);
            Dictionary<UInt16, Dictionary<UInt64, Dictionary<int, int>>> supertopicFreqsByWorkByYear;
            if (useCSO)
            {
                CSOSupertopicFinder supertopicFinder = new CSOSupertopicFinder(dataLocation, concept, fromYear, toYear, null, null);
                (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress);
            }
            else
            {
                ConceptSupertopicFinder supertopicFinder = new ConceptSupertopicFinder(dataLocation, concept, fromYear, toYear);
                (supertopics, supertopicFreqsByWorkByYear) = supertopicFinder.LoadSupertopics(stepProgress);
            }
            totalProgress?.Report(10);

            UInt16[] years = new UInt16[supertopicFreqsByWorkByYear.Count];
            supertopicFreqsByWorkByYear.Keys.CopyTo(years, 0);
            InitWeights(years);
            Parallel.For(0, years.Length, i =>
            {
                UInt16 year = years[i];
                Dictionary<UInt64, Dictionary<int, int>> supertopicFreqsByWorkOfYear = supertopicFreqsByWorkByYear[years[i]];
                foreach (var kv1 in supertopicFreqsByWorkOfYear)
                {
                    UpdateWeights(kv1.Value, year);
                }
            });
            totalProgress?.Report(20);

            Dictionary<long, float> growingEdges;
            {
                int[] nodeIds = GetNodeIds();
                float[] pog = GetNodePacesOfGrowth(nodeIds, fromYear, toYear, stepProgress);
                totalProgress?.Report(30);

                long[] edgeIds = GetEdgeIds();
                float[] poc = GetEdgePacesOfCollaboration(edgeIds, fromYear, toYear, stepProgress);
                totalProgress?.Report(40);

                growingEdges = GetGrowingEdges(edgeIds, poc, nodeIds, pog, 0.01f, stepProgress);
                totalProgress?.Report(50);
            }
            GC.Collect();
            
            List<Clique> cliques = DetectCliques(0.01, growingEdges, stepProgress);
            totalProgress?.Report(60);

            int[][] cliqueNeighborIds = FindCliqueNeighbors(cliques, stepProgress);
            totalProgress?.Report(70);

            List<(long, double)[]> topics = DescribeLocalMaximas(cliques, cliqueNeighborIds, stepProgress);
            totalProgress?.Report(90);

            OutputTopics(topics);
            totalProgress?.Report(100);
        }
    }   
}

