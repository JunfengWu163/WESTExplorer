﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Tools;
using Mosaik.Core;
using Catalyst;
using Catalyst.Models;
using Version = Mosaik.Core.Version;

namespace JunfengWu.Terms
{
    public class Segmentizer
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public Pipeline nlp { get; private set; }
        Dictionary<UInt64, Document> workTitles = new Dictionary<ulong, Document>();
        const int batchSize = 10000;

        public Segmentizer(DataLocation dataLocation, ConceptEntity concept)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            English.Register();
            nlp = Pipeline.For(Language.English);
        }

        List<string[]> GetSegments(WorkEntity work)
        {
            // initialize results
            List<string[]> segments = new List<string[]>();

            // get tokens and parts of speech
            Document doc = workTitles[work.id];
            foreach (var sentence in doc)
            {
                List<Catalyst.IToken> tokens = new List<Catalyst.IToken>();
                foreach (var token in sentence)
                {
                    tokens.Add(token);
                }

                int numTokens = tokens.Count;

                // find segments of NN/JJ
                int idxStart = -1;
                int idxEnd = -1;
                for (int i = 0; i < numTokens; i++)
                {
                    if (tokens[i].POS == PartOfSpeech.NOUN || tokens[i].POS == PartOfSpeech.PROPN || tokens[i].POS == PartOfSpeech.ADJ)
                    {
                        idxEnd = i;
                        if (idxStart < 0)
                        {
                            idxStart = idxEnd;
                        }
                    }
                    else
                    {
                        if (idxStart > 0)
                        {
                            string[] segment = new string[idxEnd - idxStart + 1];
                            for (int idx = idxStart; idx <= idxEnd; idx++)
                            {
                                segment[idx - idxStart] = tokens[idx].Value;
                            }
                            segments.Add(segment);
                        }
                        idxStart = -1;
                        idxEnd = -1;
                    }
                }
                if (idxStart > 0)
                {
                    string[] segment = new string[idxEnd - idxStart + 1];
                    for (int idx = idxStart; idx <= idxEnd; idx++)
                    {
                        segment[idx - idxStart] = tokens[idx].Value;
                    }
                    segments.Add(segment);
                }
            }

            // return results
            return segments;
        }

        List<string[]> GetDocumentSegments(WorkEntity work)
        {
            Debug.Assert(work != null);

            List<string[]> documentSegments = new List<string[]>();
            documentSegments.AddRange(GetSegments(work));

            if (work.references == null)
            {
                return documentSegments;
            }
            foreach (UInt64 referenceId in work.references)
            {
                WorkEntity refWork = new WorkEntity(referenceId, dataLocation);
                if (refWork != null && refWork.id == referenceId)
                {
                    documentSegments.AddRange(GetSegments(refWork));
                }
            }
            return documentSegments;
        }

        void MergeDocumentSegments(Dictionary<UInt64, List<string[]>> localDocumentSegments, Dictionary<UInt64, List<string[]>> globalDocumentSegments)
        {
            lock (globalDocumentSegments)
            {
                foreach (var kv in localDocumentSegments)
                {
                    globalDocumentSegments.Add(kv.Key, kv.Value);
                }
            }
        }

        void CollectWorkTitles(List<WorkEntity> worksInBatch)
        {
            Parallel.ForEach<WorkEntity, Dictionary<UInt64, Document>>(worksInBatch,
                () => new Dictionary<ulong, Document>(),
                (work, loopState, localWorkTitles) =>
                {
                    if (!workTitles.ContainsKey(work.id) && !localWorkTitles.ContainsKey(work.id))
                    {
                        Document doc = new Document(work.title, Language.English);
                        localWorkTitles[work.id] = doc;
                    }
                    if (work.references != null)
                    {
                        foreach (UInt64 referenceId in work.references)
                        {
                            if (!workTitles.ContainsKey(referenceId) && !localWorkTitles.ContainsKey(referenceId))
                            {
                                WorkEntity refWork = new WorkEntity(referenceId, dataLocation);
                                if (refWork != null && refWork.id == referenceId)
                                {
                                    Document doc = new Document(refWork.title, Language.English);
                                    localWorkTitles[referenceId] = doc;
                                }
                            }
                        }
                    }
                    return localWorkTitles;
                },
                localWorkTitles =>
                {
                    lock (workTitles)
                    {
                        foreach (var kv in localWorkTitles)
                        {
                            workTitles[kv.Key] = kv.Value;
                        }
                    }
                }
            );
        }

        void ProcessWorkTitles()
        {
            List<Document> titlesToProcess = new List<Document>();
            foreach (var kv in workTitles)
            {
                if (kv.Value.TokensCount == 0)
                {
                    titlesToProcess.Add(kv.Value);
                }
            }
            Parallel.ForEach(titlesToProcess, doc =>
            {
                nlp.ProcessSingle(doc);
            });
        }

        void SegmentizeWorks(List<WorkEntity> worksInBatch, Dictionary<UInt64, List<string[]>> globalDocumentSegments)
        {
            CollectWorkTitles(worksInBatch);

            ProcessWorkTitles();

            Parallel.ForEach(
                worksInBatch,
                () =>
                {
                    Dictionary<UInt64, List<string[]>> localSegments = new Dictionary<UInt64, List<string[]>>();
                    return localSegments;
                },
                (work, loopState, localSegments) =>
                {
                    List<string[]> documentCandidatePhrases = GetDocumentSegments(work);
                    localSegments.Add(work.id, documentCandidatePhrases);
                    return localSegments;
                },
                localSegments =>
                {
                    MergeDocumentSegments(localSegments, globalDocumentSegments);
                });
        }

        string GetPhrase(string[] segmentWords)
        {
            string phrase = "";
            for (int i = 0; i < segmentWords.Length; i++)
            {
                if (phrase.Length > 0)
                {
                    phrase += " ";
                }
                phrase += segmentWords[i];
            }
            return phrase;
        }

        string GetCodeString(Int16[] codes)
        {
            string s = "";
            foreach (Int16 c in codes)
            {
                s += $"{c}";
            }
            return s;
        }

        void OutputDocumentSegments(Dictionary<UInt64, List<string[]>> documentSegments, StreamWriter writer)
        {
            foreach (var kv in documentSegments)
            {
                UInt64 workId = kv.Key;
                string line = $"{workId}";

                foreach (string[] segment in kv.Value)
                {
                    string phrase = GetPhrase(segment);
                    line += $",{phrase}";
                }
                writer.WriteLine(line);
            }
        }

        public void Segmentize(ushort year, IProgress<int> progress)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Segments");
            string segmentPath = dataLocation.GetSubfieldDirectory(concept.id, "Segments");

            string outputFileName = Path.Combine(segmentPath, $"{year}.txt");
            if (MD5Check.Check(outputFileName))
            {
                Console.WriteLine($"{outputFileName} is good.");
                return;
            }

            Dictionary<UInt64, List<string[]>> globalDocumentSegments = new Dictionary<UInt64, List<string[]>>();
            progress?.Report(0);
            for (int idxBucket = 0; idxBucket < 64; idxBucket++)
            {
                List<WorkEntity> worksOfYear = WorkEntity.LoadSubfieldBucket(idxBucket, dataLocation, concept.id, year);
                SegmentizeWorks(worksOfYear, globalDocumentSegments);
                int progressValue = 100 * (idxBucket + 1) / 64;
                progress?.Report(progressValue);
            }

            using (FileStream outputFile = File.Create(outputFileName))
            {
                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    OutputDocumentSegments(globalDocumentSegments, writer);
                }
            }

            MD5Check.SaveMD5Hash(outputFileName);
        }

        public void Segmentize(UInt16 fromYear, UInt16 toYear, IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            totalProgress?.Report(0);
            for (UInt16 year = fromYear; year <= toYear; year++)
            {
                Segmentize(year, stepProgress);
                totalProgress?.Report(100 * (year - fromYear + 1) / (toYear - fromYear + 1));
            }
        }
    }
}
