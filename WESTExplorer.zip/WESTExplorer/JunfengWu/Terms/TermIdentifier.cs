﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Annytab.Stemmer;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Tools;

namespace JunfengWu.Terms
{
    public class TermIdentifier
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }

        Dictionary<UInt64, int> DF256 = new Dictionary<ulong, int>();
        Dictionary<UInt64, int> DF384 = new Dictionary<ulong, int>();
        StringHash stringHash = new StringHash();
        public IStemmer stemmer { get; private set; } = new EnglishStemmer();
        const int batchSize = 10000;

        public TermIdentifier(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
        }

        public Dictionary<UInt64, Dictionary<string, (float, int)>> LoadTermsByDoc(UInt16 year)
        {
            Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc = new Dictionary<UInt64, Dictionary<string, (float, int)>>();
            string termPath = dataLocation.GetSubfieldDirectory(concept.id, "Terms");
            string termFileName = Path.Combine(termPath, $"{year}.txt");

            using (FileStream termFile = File.OpenRead(termFileName))
            {
                using (StreamReader reader = new StreamReader(termFile))
                {
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length > 0)
                        {
                            UInt64 workId = Convert.ToUInt64(parts[0]);
                            Dictionary<string, (float, int)> termsOfWork = new Dictionary<string, (float, int)>();
                            for (int idxPart = 1; idxPart < parts.Length; idxPart++)
                            {
                                string[] properties = parts[idxPart].Split(':');
                                if (properties.Length == 3)
                                {
                                    string term = properties[0];
                                    float tfidf = Convert.ToSingle(properties[1]);
                                    int freq = Convert.ToInt32(properties[2]);
                                    termsOfWork.Add(term, (tfidf, freq));
                                }
                            }
                            termsByDoc.Add(workId, termsOfWork);
                        }
                        line = reader.ReadLine();
                    }
                }
            }

            return termsByDoc;
        }

        public void SaveTermsByDoc(IProgress<int> totalProgress, IProgress<int> stepProgress, UInt16 y0, UInt16 y3)
        {
            string segmentPath = dataLocation.GetSubfieldDirectory(concept.id, "Segments");
            string termPath = dataLocation.GetSubfieldDirectory(concept.id, "Terms");

            totalProgress?.Report(0);
            for (UInt16 year = y0; year <= y3; year++)
            {
                string termFileName = Path.Combine(termPath, $"{year}.txt");
                if (MD5Check.Check(termFileName))
                {
                    System.Console.WriteLine($"{termFileName} is good.");
                    continue;
                }

                string segmentFileName = Path.Combine(segmentPath, $"{year}.txt");
                if (MD5Check.Check(segmentFileName))
                {
                    Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc = new Dictionary<ulong, Dictionary<string, (float, int)>>();

                    using (FileStream segmentFile = File.OpenRead(segmentFileName))
                    {
                        using (StreamReader reader = new StreamReader(segmentFile))
                        {
                            stepProgress?.Report(0);
                            List<string> batchOfLines = new List<string>();
                            string? line = reader.ReadLine();
                            while (line != null)
                            {
                                batchOfLines.Add(line);
                                if (batchOfLines.Count >= batchSize)
                                {
                                    ProcessTermBatch(batchOfLines, termsByDoc);
                                    batchOfLines.Clear();
                                }
                                stepProgress?.Report(Convert.ToInt32(100 * segmentFile.Position / segmentFile.Length));
                                line = reader.ReadLine();
                            }
                            if (batchOfLines.Count > 0)
                            {
                                ProcessTermBatch(batchOfLines, termsByDoc);
                            }
                            stepProgress?.Report(100);
                        }
                    }
                    OutputTermsByDoc(year, termsByDoc);
                }

                totalProgress?.Report(100 * (year - y0 + 1) / (y3 - y0 + 1));
            }

        }

        public void ComputeDF(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            string segmentPath = dataLocation.GetSubfieldDirectory(concept.id, "Segments");
            string termPath = dataLocation.GetSubfieldDirectory(concept.id, "Terms");
            string termFileName = Path.Combine(termPath, $"{toYear}.txt");
            if (MD5Check.Check(termFileName))
            {
                System.Console.WriteLine($"{termFileName} is good.");
                return;
            }

            totalProgress?.Report(0);
            for (UInt16 year = fromYear; year <= toYear; year++)
            {
                string segmentFileName = Path.Combine(segmentPath, $"{year}.txt");
                if (MD5Check.Check(segmentFileName))
                {
                    using (FileStream segmentFile = File.OpenRead(segmentFileName))
                    {
                        using (StreamReader reader = new StreamReader(segmentFile))
                        {
                            stepProgress?.Report(0);
                            List<string> batchOfLines = new List<string>();
                            string? line = reader.ReadLine();
                            while (line != null)
                            {
                                batchOfLines.Add(line);
                                if (batchOfLines.Count >= batchSize)
                                {
                                    ProcessDFBatch(batchOfLines);
                                    batchOfLines.Clear();
                                }
                                stepProgress?.Report(Convert.ToInt32(100 * segmentFile.Position / segmentFile.Length));
                                line = reader.ReadLine();
                            }
                            if (batchOfLines.Count > 0)
                            {
                                ProcessDFBatch(batchOfLines);
                            }
                            stepProgress.Report(100);
                        }
                    }
                }
                totalProgress?.Report(100 * (year - fromYear + 1) / (toYear - fromYear + 1));
            }
            
        }

        string[] StemWords(string[] words)
        {
            string[] stems = new string[words.Length];
            for (int i = 0; i < words.Length; i++)
            {
                stems[i] = stemmer.GetSteamWord(words[i].ToLower());
            }
            return stems;
        }

        void ProcessDFBatch(List<string> batchOfLines)
        {
            Parallel.ForEach<string, (Dictionary<UInt64, int>, Dictionary<UInt64, int>)>(batchOfLines,
                () =>
                {
                    Dictionary<UInt64, int> localDF256 = new Dictionary<ulong, int>();
                    Dictionary<UInt64, int> localDF384 = new Dictionary<ulong, int>();
                    return (localDF256, localDF384);
                },
                (line, loopState, localDFs) => {
                    string[] parts = line.Split(',');
                    if (parts.Length > 1)
                    {
                        HashSet<string> possibleTerms = new HashSet<string>();
                        for (int i = 1; i < parts.Length; i++)
                        {
                            string segment = parts[i];
                            string[] words = segment.Split(' ');
                            if (words.Length > 0)
                            {
                                string[] stems = StemWords(words);
                                for (int i1 = 0; i1 < stems.Length; i1++)
                                {
                                    for (int i2 = i1; i2 < stems.Length; i2++)
                                    {
                                        string s = "";
                                        for (int j = i1; j <= i2; j++)
                                        {
                                            if (s.Length > 0)
                                            {
                                                s += " " + stems[j];
                                            }
                                            else
                                            {
                                                s = stems[j];
                                            }
                                        }
                                        possibleTerms.Add(s);
                                    }
                                }
                            }
                        }
                        foreach (string s in possibleTerms)
                        {
                            UpdateDF(s, localDFs.Item1, true);
                            UpdateDF(s, localDFs.Item2, false);
                        }
                    }
                    return localDFs;
                },
                localDFs =>
                {
                    lock(DF256)
                    {
                        MergeDF(localDFs.Item1, DF256);
                    }
                    lock(DF384)
                    {
                        MergeDF(localDFs.Item2, DF384);
                    }
                }
                );
        }

        void UpdateDF(string s, Dictionary<UInt64, int> DF, bool use256)
        {
            UInt64 hash = use256 ? stringHash.Get256Code(s): stringHash.Get384Code(s);
            int oldCount;
            if (!DF.TryGetValue(hash, out oldCount))
            {
                oldCount = 0;
            }
            DF[hash] = oldCount + 1;
        }

        void MergeDF(Dictionary<UInt64, int> localDF, Dictionary<UInt64, int> globalDF)
        {
            foreach (var kv in localDF)
            {
                int oldFreq;
                if (globalDF.TryGetValue(kv.Key, out oldFreq))
                {
                    globalDF[kv.Key] = oldFreq + kv.Value;
                }
                else
                {
                    globalDF.Add(kv.Key, kv.Value);
                }
            }
        }

        int GetDF(string s)
        {
            int df256, df384;
            if (!DF256.TryGetValue(stringHash.Get256Code(s), out df256))
            {
                df256 = 0;
            }
            if (!DF384.TryGetValue(stringHash.Get384Code(s), out df384))
            {
                df384 = 0;
            }
            return Math.Min(df256, df384);
        }

        Dictionary<string, int> GetPossibleTermFreqs(List<string> segments)
        {
            Dictionary<string, int> possibleTermFreqs = new Dictionary<string, int>();
            foreach (string s in segments)
            {
                string[] words = s.Split(' ');
                if (words.Length > 0)
                {
                    string[] stems = StemWords(words);
                    for (int i1 = 0; i1 < stems.Length; i1++)
                    {
                        for (int i2 = i1; i2 < stems.Length; i2++)
                        {
                            string ss = "";
                            for (int j = i1; j <= i2; j++)
                            {
                                if (ss.Length > 0)
                                {
                                    ss += " " + stems[j];
                                }
                                else
                                {
                                    ss = stems[j];
                                }
                            }
                            int oldFreq;
                            if (possibleTermFreqs.TryGetValue(ss, out oldFreq))
                            {
                                possibleTermFreqs[ss] = oldFreq + 1;
                            }
                            else
                            {
                                possibleTermFreqs[ss] = 1;
                            }
                        }
                    }
                }
            }
            return possibleTermFreqs;
        }

        float GetTFIDF(string s, Dictionary<string, int> possibleTermFreqs)
        {
            int termFreq;
            if (!possibleTermFreqs.TryGetValue(s, out termFreq))
            {
                termFreq = 0;
            }
            int numDocs = Math.Max(DF256.Count, DF384.Count);
            int documentFreq = GetDF(s);
            if (termFreq <= 0 || documentFreq <= 0)
            {
                return 0.0f;
            }
            return termFreq * MathF.Log(Convert.ToSingle(numDocs) / Convert.ToSingle(documentFreq));
        }

        void OutputTermsByDoc(UInt16 year, Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Terms");
            string termPath = dataLocation.GetSubfieldDirectory(concept.id, "Terms");
            string termFileName = Path.Combine(termPath, $"{year}.txt");

            using (FileStream termFile = File.Create(termFileName))
            {
                using (StreamWriter writer = new StreamWriter(termFile))
                {
                    foreach (var kv1 in termsByDoc)
                    {
                        UInt64 workId = kv1.Key;
                        Dictionary<string, (float, int)> termsOfDoc = kv1.Value;
                        if (termsOfDoc.Count > 0)
                        {
                            writer.Write($"{workId}");
                            foreach (var kv2 in termsOfDoc)
                            {
                                string term = kv2.Key;
                                (float tfidf, int freq) = kv2.Value;
                                writer.Write($",{term}:{tfidf}:{freq}");
                            }
                            writer.WriteLine();
                        }
                    }
                }
            }
            MD5Check.SaveMD5Hash(termFileName);
        }

        void ProcessTermBatch(List<string> batchOfLines, Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc)
        {
            Parallel.ForEach<string, Dictionary<UInt64, Dictionary<string,(float,int)>>>(batchOfLines,
                () =>
                {
                    Dictionary<UInt64, Dictionary<string, (float, int)>> localTermsByDoc = new Dictionary<ulong, Dictionary<string, (float, int)>>();
                    return localTermsByDoc;
                },
                (line, loopState, localTermsByDoc) => {
                    string[] parts = line.Split(',');
                    if (parts.Length > 1)
                    {
                        UInt64 workId = Convert.ToUInt64(parts[0]);
                        Dictionary<string, (float, int)> termsOfDoc = new Dictionary<string, (float, int)>();

                        List<string> segments = new List<string>();
                        for (int i = 1; i < parts.Length; i++)
                        {
                            string segment = parts[i];
                            segments.Add(segment);
                        }
                        Dictionary<string, int> possibleTermFreqs = GetPossibleTermFreqs(segments);
                        foreach (string s in segments)
                        {
                            SplitSegment(s, possibleTermFreqs, termsOfDoc);
                        }
                        localTermsByDoc[workId] = FilterByTFIDF(termsOfDoc);
                    }
                    return localTermsByDoc;
                },
                localTermsByDoc =>
                {
                    lock (termsByDoc)
                    {
                        foreach (var kv in localTermsByDoc)
                        {
                            termsByDoc[kv.Key] = kv.Value;
                        }
                    }
                }
                );
        }

        Dictionary<string, (float, int)> FilterByTFIDF(Dictionary<string, (float, int)> terms)
        {
            Dictionary<string, (float, int)> result = new Dictionary<string, (float, int)>();
            double sumTFIDF = 0.0;
            double n = 0.0;
            foreach (var kv in terms)
            {
                sumTFIDF += kv.Value.Item1 * kv.Value.Item2;
                n += kv.Value.Item2;
            }
            double meanTFIDF = sumTFIDF / n;
            foreach (var kv in terms)
            {
                if (kv.Value.Item1 > meanTFIDF)
                {
                    result.Add(kv.Key, kv.Value);
                }
            }
            return result;
        }

        void SplitSegment(string s, Dictionary<string, int> possibleTermFreqs, Dictionary<string, (float, int)> terms)
        {
            string[] words = s.Split(' ');
            string[] stems = StemWords(words);
            SplitSegment(stems, possibleTermFreqs, terms);
        }

        void SplitSegment(string[] stems, Dictionary<string, int> possibleTermFreqs, Dictionary<string, (float, int)> terms)
        {
            if (stems.Length == 0)
            {
                return;
            }

            float largestTFIDF = 0;
            int bestI1 = 0, bestI2 = stems.Length - 1;
            for (int i1 = 0; i1 < stems.Length; i1++)
            {
                for (int i2 = i1; i2 < stems.Length; i2++)
                {
                    string ss = "";
                    for (int j = i1; j <= i2; j++)
                    {
                        if (ss.Length > 0)
                        {
                            ss += " " + stems[j];
                        }
                        else
                        {
                            ss = stems[j];
                        }
                    }
                    float ssTfidf = GetTFIDF(ss, possibleTermFreqs);
                    if (ssTfidf > largestTFIDF)
                    {
                        largestTFIDF = ssTfidf;
                        bestI1 = i1;
                        bestI2 = i2;
                    }
                }
            }

            string bestTerm = stems[bestI1];
            for (int j = bestI1 + 1; j <= bestI2; j++)
            {
                bestTerm += " " + stems[j];
            }

            (float, int) oldValue;
            if (terms.TryGetValue(bestTerm, out oldValue))
            {
                terms[bestTerm] = (oldValue.Item1, oldValue.Item2 + 1);
            }
            else
            {
                terms[bestTerm] = (largestTFIDF, 1);
            }

            if (bestI1 > 0)
            {
                string[] stems1 = new string[bestI1];
                for (int j = 0; j < bestI1; j++)
                {
                    stems1[j] = stems[j];
                }
                SplitSegment(stems1, possibleTermFreqs, terms);
            }

            if (bestI2 < stems.Length - 1)
            {
                string[] stems2 = new string[stems.Length - bestI2 - 1];
                for (int j = bestI2 + 1; j < stems.Length; j++)
                {
                    stems2[j - bestI2 - 1] = stems[j];
                }
                SplitSegment(stems2, possibleTermFreqs, terms);
            }
        }
    }
}

