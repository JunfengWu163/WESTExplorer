﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Terms;
using JunfengWu.Tools;
using JunfengWu.FastText;

namespace JunfengWu.Synonyms
{
    public class SynonymFinder
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        FastTextModel fastTextModel;

        public SynonymFinder(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.fastTextModel = fastTextModel;
        }

        // find <stem, (freq, vector)>
        Dictionary<string, (int, float[])> GetStemInfo(Dictionary<string, (float, int)> termsOfDoc)
        {
            int numDims = fastTextModel.numDims;
            Dictionary<string, (int, float[])> stemInfos = new Dictionary<string, (int, float[])>();
            foreach (var termFreq in termsOfDoc)
            {
                string stem = termFreq.Key;
                int freq = termFreq.Value.Item2;
                float[] stemVector = fastTextModel.GetFormVector(stem);
                stemInfos[stem] = (freq, stemVector);
            }
            return stemInfos;
        }

        // synonTerm=>(synonym freq, term radius)
        Dictionary<string, (int, float)> GetSynonymousTerms(Dictionary<string, (int, float[])> stemInfos, int knnK, float eps)
        {
            Dictionary<string, (int, float)> synonTerms = new Dictionary<string, (int, float)>();
            if (stemInfos.Count == 0)
                return synonTerms;

            // step 1, get stems, vectors and cardinalities from stemInfos
            string[] stems = new string[stemInfos.Count];
            stemInfos.Keys.CopyTo(stems, 0);
            float[][] vectors = new float[stems.Length][];
            int[] cardinalities = new int[stems.Length];
            for (int i = 0; i < stems.Length; i++)
            {
                var info = stemInfos[stems[i]];
                vectors[i] = info.Item2;
                cardinalities[i] = info.Item1;
            }

            // step 2, compute knn
            CosineKNN cosineKNN = new CosineKNN(vectors, null, knnK);

            // step 3, compute DPC
            DensityPeakClustering densityPeakClustering = new DensityPeakClustering(cosineKNN, cardinalities, knnK, eps, null, null, null, null);

            // step 4, get descriptors
            var discriptors = densityPeakClustering.GetDescriptorsForLargestClusters(100, cosineKNN, cardinalities);
            foreach (var discriptor in discriptors)
            {
                string synonTerm = stems[discriptor.Key];
                int termFreq = discriptor.Value.Item1;
                float termRadius = discriptor.Value.Item2;
                synonTerms.Add(synonTerm, (termFreq, termRadius));
            }
            return synonTerms;
        }

        Dictionary<string, (int, float)> ComputeSynonyms(Dictionary<string, (float, int)> termsOfDoc, int knnK, float eps)
        {
            Dictionary<string, (int, float[])> stemInfos = GetStemInfo(termsOfDoc);
            Dictionary<string, (int, float)> synonyms = GetSynonymousTerms(stemInfos, knnK, eps);
            return synonyms;
        }

        //Dictionary<string, (int, float)> GetMajorSynonyms(Dictionary<string, (int, float)> synonyms)
        //{
        //    Dictionary<string, (int, float)> majorSynonyms = new Dictionary<string, (int, float)>();
        //    if (synonyms.Count == 0)
        //        return majorSynonyms;

        //    float sumFreq = 0;
        //    foreach (var kv in synonyms)
        //    {
        //        sumFreq += kv.Value.Item1;
        //    }
        //    float meanFreq = sumFreq / synonyms.Count;
        //    foreach (var kv in synonyms)
        //    {
        //        if (kv.Value.Item1 >= meanFreq)
        //        {
        //            majorSynonyms.Add(kv.Key, kv.Value);
        //        }
        //    }
        //    return majorSynonyms;
        //}

        void OutputSynonyms(UInt64 workId, Dictionary<string, (int, float)> synonTerms, StreamWriter streamWriter)
        {
            if (synonTerms.Count == 0)
                return;
            string[] terms = new string[synonTerms.Count];
            synonTerms.Keys.CopyTo(terms, 0);
            Array.Sort(terms, (x, y) => MathF.Sign(synonTerms[y].Item1 - synonTerms[x].Item1));
            float sumFreq = 0;
            for (int i = 0; i < terms.Length; i++)
            {
                sumFreq += synonTerms[terms[i]].Item1;
            }
            float meanFreq = sumFreq / terms.Length;

            string line = $"{workId}";
            for (int i = 0; i < terms.Length; i++)
            {
                string term = terms[i];
                var info = synonTerms[term];
                if (info.Item1 < meanFreq)
                    break;
                line += $",{term}:{info.Item1}:{info.Item2}";
            }
            streamWriter.WriteLine(line);
        }

        Dictionary<UInt64, Dictionary<string, (int, float)>> ComputeSynonymsByDoc(
            Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc,
            int knnK, float eps, IProgress<int> progress)
        {
            Console.WriteLine($"Computing synonymous terms of works of {termsByDoc.Count}");
            progress.Report(0);
            var docTerms = termsByDoc.ToArray();
            Dictionary<string, (int, float)>[] docSynonyms = new Dictionary<string, (int, float)>[docTerms.Length];
            for (int idxBatch = 0; idxBatch < 100; idxBatch++)
            {
                int i0 = docTerms.Length * idxBatch / 100;
                int i1 = docTerms.Length * (idxBatch + 1) / 100;
                Parallel.For(i0, i1, i => {
                    docSynonyms[i] = ComputeSynonyms(docTerms[i].Value, knnK, eps);
                });
                progress?.Report(idxBatch + 1);
            }
            Dictionary<UInt64, Dictionary<string, (int, float)>> synonTermsByDoc = new Dictionary<ulong, Dictionary<string, (int, float)>>();
            for (int i = 0; i < docTerms.Length; i++)
            {
                synonTermsByDoc[docTerms[i].Key] = docSynonyms[i];
            }
            return synonTermsByDoc;
        }

        void SaveSynonymsByDoc(ushort year, IProgress<int> progress, int knnK, float eps)
        {
            dataLocation.CreateSubfieldDirectory(concept.id, "Synonyms");
            string synonymPath = dataLocation.GetSubfieldDirectory(concept.id, "Synonyms");
            string outputFileName = Path.Combine(synonymPath, $"{fromYear}-{toYear}-{year}.txt");
            if (MD5Check.Check(outputFileName))
            {
                Console.WriteLine($"{outputFileName} is good.");
                return;
            }

            TermIdentifier termIdentifier = new TermIdentifier(dataLocation, concept, fromYear, toYear);
            Dictionary<UInt64, Dictionary<string, (float, int)>> termsByDoc = termIdentifier.LoadTermsByDoc(year);
            Dictionary<UInt64, Dictionary<string, (int, float)>> synonTermsByDoc = ComputeSynonymsByDoc(termsByDoc, knnK, eps, progress);

            using (FileStream file = File.Create(outputFileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    foreach (var kv in synonTermsByDoc)
                    {
                        UInt64 workId = kv.Key;
                        Dictionary<string, (int, float)> synonymsOfWork = kv.Value;
                        OutputSynonyms(workId, synonymsOfWork, writer);
                    }
                }
            }
            MD5Check.SaveMD5Hash(outputFileName);
        }

        public void SaveSynonymsByDoc(IProgress<int> totalProgress, IProgress<int> stepProgress, UInt16 y0, UInt16 y3, int knnK = 10, float eps = 0.02f)
        {
            totalProgress?.Report(0);
            for (UInt16 year = y0; year <= y3; year++)
            {
                SaveSynonymsByDoc(year, stepProgress, knnK, eps);
                totalProgress?.Report(100 * (year - y0 + 1) / (y3 - y0 + 1));
            }
        }

        public Dictionary<UInt64, Dictionary<string, (int, float)>> LoadSynonymsByDoc(ushort year)
        {
            string synonymPath = dataLocation.GetSubfieldDirectory(concept.id, "Synonyms");
            string fileName = Path.Combine(synonymPath, $"{fromYear}-{toYear}-{year}.txt");
            Dictionary<UInt64, Dictionary<string, (int, float)>> synonymsByDoc = new Dictionary<ulong, Dictionary<string, (int, float)>>();
            using (FileStream file = File.OpenRead(fileName))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    string? line = reader.ReadLine();
                    while (line != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length > 0)
                        {
                            UInt64 workId = Convert.ToUInt64(parts[0]);
                            Dictionary<string, (int, float)> synonymsOfWork = new Dictionary<string, (int, float)>();
                            for (int i = 1; i < parts.Length; i++)
                            {
                                string[] properties = parts[i].Split(':');
                                if (properties.Length == 3)
                                {
                                    string term = properties[0];
                                    int freq = Convert.ToInt32(properties[1]);
                                    float radius = Convert.ToSingle(properties[2]);
                                    synonymsOfWork.Add(term, (freq, radius));
                                }
                            }
                            synonymsByDoc.Add(workId, synonymsOfWork);
                        }
                        line = reader.ReadLine();
                    }
                }
            }
            return synonymsByDoc;
        }
    }
}
