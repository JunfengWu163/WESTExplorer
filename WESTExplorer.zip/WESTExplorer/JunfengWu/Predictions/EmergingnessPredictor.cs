﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MathNet.Numerics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Topics;
using JunfengWu.Tools;
using JunfengWu.Synonyms;
using JunfengWu.Supertopics;
using JunfengWu.FastText;

namespace JunfengWu.Predictions
{
    public class EmergingnessPredictor
    {
        public enum TopicType
        {
            ISBV1,
            ISBV2,
            ISBV2_1,
            ISBV2_2,
            ISBV2_3,
            ISBV2_4,
            ISBV2_5,
            ISBV2_6,
            ISBV2_7,
            ISBV2_8,
            ISBV2_9,
            ISBV2_10,
            ISBV2_11,
            ISBV2_12,
            ISBV2_13,
            ISBV2_14,
            ISBV2_15,
            ISBV2_16,
            ISBV2_17,
            ISBV2_18,
            ISBV2_19,
            ISBV2_20,
            ISBV2_21,
            ISBV2_22,
            ISBV2_23,
            ISBV2P,
            ISBV3,
            CSO,
            Concept
        }

        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public TopicType topicType { get; private set; }
        public bool done { get; private set; }
        public string myFileName { get; private set; }
        FastTextModel fastTextModel;

        public EmergingnessPredictor(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, TopicType topicType, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.topicType = topicType;
            this.fastTextModel = fastTextModel;
            myFileName = GetFileName(k);
            done = MD5Check.Check(myFileName);
        }

        public static bool IsISBV2Variant(TopicType topicType)
        {
            switch (topicType)
            {
                case TopicType.ISBV2:
                case TopicType.ISBV2_1:
                case TopicType.ISBV2_2:
                case TopicType.ISBV2_3:
                case TopicType.ISBV2_4:
                case TopicType.ISBV2_5:
                case TopicType.ISBV2_6:
                case TopicType.ISBV2_7:
                case TopicType.ISBV2_8:
                case TopicType.ISBV2_9:
                case TopicType.ISBV2_10:
                case TopicType.ISBV2_11:
                case TopicType.ISBV2_12:
                case TopicType.ISBV2_13:
                case TopicType.ISBV2_14:
                case TopicType.ISBV2_15:
                case TopicType.ISBV2_16:
                case TopicType.ISBV2_17:
                case TopicType.ISBV2_18:
                case TopicType.ISBV2_19:
                case TopicType.ISBV2_20:
                case TopicType.ISBV2_21:
                case TopicType.ISBV2_22:
                case TopicType.ISBV2_23:
                    return true;
                default:
                    return false;
            }
        }

        public static string GetTopicTypeString(TopicType topicType)
        {
            switch (topicType)
            {
                case TopicType.ISBV1:
                    {
                        return "ISBV1";
                    }
                case TopicType.ISBV2:
                    {
                        return "ISBV2";
                    }
                case TopicType.ISBV2_1:
                    {
                        return "ISBV2_1";
                    }
                case TopicType.ISBV2_2:
                    {
                        return "ISBV2_2";
                    }
                case TopicType.ISBV2_3:
                    {
                        return "ISBV2_3";
                    }
                case TopicType.ISBV2_4:
                    {
                        return "ISBV2_4";
                    }
                case TopicType.ISBV2_5:
                    {
                        return "ISBV2_5";
                    }
                case TopicType.ISBV2_6:
                    {
                        return "ISBV2_6";
                    }
                case TopicType.ISBV2_7:
                    {
                        return "ISBV2_7";
                    }
                case TopicType.ISBV2_8:
                    {
                        return "ISBV2_8";
                    }
                case TopicType.ISBV2_9:
                    {
                        return "ISBV2_9";
                    }
                case TopicType.ISBV2_10:
                    {
                        return "ISBV2_10";
                    }
                case TopicType.ISBV2_11:
                    {
                        return "ISBV2_11";
                    }
                case TopicType.ISBV2_12:
                    {
                        return "ISBV2_12";
                    }
                case TopicType.ISBV2_13:
                    {
                        return "ISBV2_13";
                    }
                case TopicType.ISBV2_14:
                    {
                        return "ISBV2_14";
                    }
                case TopicType.ISBV2_15:
                    {
                        return "ISBV2_15";
                    }
                case TopicType.ISBV2_16:
                    {
                        return "ISBV2_16";
                    }
                case TopicType.ISBV2_17:
                    {
                        return "ISBV2_17";
                    }
                case TopicType.ISBV2_18:
                    {
                        return "ISBV2_18";
                    }
                case TopicType.ISBV2_19:
                    {
                        return "ISBV2_19";
                    }
                case TopicType.ISBV2_20:
                    {
                        return "ISBV2_20";
                    }
                case TopicType.ISBV2_21:
                    {
                        return "ISBV2_21";
                    }
                case TopicType.ISBV2_22:
                    {
                        return "ISBV2_22";
                    }
                case TopicType.ISBV2_23:
                    {
                        return "ISBV2_23";
                    }
                case TopicType.ISBV2P:
                    {
                        return "ISBV2P";
                    }
                case TopicType.ISBV3:
                    {
                        return "ISBV3";
                    }
                case TopicType.CSO:
                    {
                        return "CSO";
                    }
                case TopicType.Concept:
                    {
                        return "Concept";
                    }
                default:
                    {
                        return "Unknown";
                    }
            }
        }

        public static TopicPublicationFinder.TopicType GetPublicationTopicType(TopicType topicType)
        {
            TopicPublicationFinder.TopicType publicationTopicType;
            switch (topicType)
            {
                case TopicType.ISBV1:
                case TopicType.ISBV2:
                case TopicType.ISBV2_1:
                case TopicType.ISBV2_2:
                case TopicType.ISBV2_3:
                case TopicType.ISBV2_4:
                case TopicType.ISBV2_5:
                case TopicType.ISBV2_6:
                case TopicType.ISBV2_7:
                case TopicType.ISBV2_8:
                case TopicType.ISBV2_9:
                case TopicType.ISBV2_10:
                case TopicType.ISBV2_11:
                case TopicType.ISBV2_12:
                case TopicType.ISBV2_13:
                case TopicType.ISBV2_14:
                case TopicType.ISBV2_15:
                case TopicType.ISBV2_16:
                case TopicType.ISBV2_17:
                case TopicType.ISBV2_18:
                case TopicType.ISBV2_19:
                case TopicType.ISBV2_20:
                case TopicType.ISBV2_21:
                case TopicType.ISBV2_22:
                case TopicType.ISBV2_23:
                    {
                        publicationTopicType = TopicPublicationFinder.TopicType.ISB;
                    }
                    break;
                case TopicType.ISBV3:
                    {
                        publicationTopicType = TopicPublicationFinder.TopicType.ISBV3;
                    }
                    break;
                case TopicType.CSO:
                    {
                        publicationTopicType = TopicPublicationFinder.TopicType.CSO;
                    }
                    break;
                case TopicType.Concept:
                default:
                    {
                        publicationTopicType = TopicPublicationFinder.TopicType.Concept;
                    }
                    break;
            }
            return publicationTopicType;
        }

        string GetFileName(int l)
        {
            string predictionPath = dataLocation.GetSubfieldDirectory(concept.id, "Predictions");
            return Path.Combine(predictionPath, $"{GetTopicTypeString(topicType)}-{fromYear}-{toYear}-{l}.txt");
        }

        public void Predict(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Predictions");

            TopicPublicationFinder.TopicType publicationTopicType = GetPublicationTopicType(topicType);
            TopicPublicationFinder publicationFinder = new TopicPublicationFinder(dataLocation, concept, fromYear, toYear, k, publicationTopicType, fastTextModel);
            totalProgress.Report(0);
            for (int l = 1; l <= k; l++)
            {
                List<Dictionary<UInt16, List<UInt64>>> topicPublications = publicationFinder.LoadTopicPublications(l, stepProgress);
                double[] predictionScores = new double[topicPublications.Count];
                switch (topicType)
                {
                    case TopicType.ISBV1:
                    case TopicType.ISBV2:
                    case TopicType.ISBV2_1:
                    case TopicType.ISBV2_2:
                    case TopicType.ISBV2_3:
                    case TopicType.ISBV2_4:
                    case TopicType.ISBV2_5:
                    case TopicType.ISBV2_6:
                    case TopicType.ISBV2_7:
                    case TopicType.ISBV2_8:
                    case TopicType.ISBV2_9:
                    case TopicType.ISBV2_10:
                    case TopicType.ISBV2_11:
                    case TopicType.ISBV2_12:
                    case TopicType.ISBV2_13:
                    case TopicType.ISBV2_14:
                    case TopicType.ISBV2_15:
                    case TopicType.ISBV2_16:
                    case TopicType.ISBV2_17:
                    case TopicType.ISBV2_18:
                    case TopicType.ISBV2_19:
                    case TopicType.ISBV2_20:
                    case TopicType.ISBV2_21:
                    case TopicType.ISBV2_22:
                    case TopicType.ISBV2_23:
                    case TopicType.ISBV2P:
                    case TopicType.ISBV3:
                        {
                            for (int j = 0; j < predictionScores.Length; j++)
                            {
                                Dictionary<ushort, int> hitsOfYear = GetHitsOfYear(topicPublications[j]);
                                predictionScores[j] = ComputePredictionScore(hitsOfYear);
                            }
                        }
                        break;
                    case TopicType.CSO:
                    case TopicType.Concept:
                        {
                            AUGURTopicFinder topicFinder = new AUGURTopicFinder(dataLocation, concept, fromYear, toYear, topicType == TopicType.CSO, k);
                            List<List<(string, string, float)>> topics = topicFinder.LoadTopics(stepProgress);
                            Debug.Assert(topics.Count == predictionScores.Length);
                            for (int j = 0; j < predictionScores.Length; j++)
                            {
                                predictionScores[j] = topics[j][0].Item3;
                            }
                        }
                        break;
                }

                string fileName = GetFileName(l);
                using (FileStream file = File.Create(fileName))
                {
                    using (StreamWriter writer = new StreamWriter(file))
                    {
                        for (int j = 0; j < predictionScores.Length; j++)
                        {
                            writer.WriteLine($"{predictionScores[j]}");
                        }
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
                totalProgress.Report(100 * l / k);
            }
        }

        public double[] LoadPredictions()
        {
            string[] lines = File.ReadAllLines(myFileName);
            double[] predictions = new double[lines.Length];
            for (int j = 0; j < predictions.Length; j++)
            {
                predictions[j] = Convert.ToDouble(lines[j]);
            }
            return predictions;
        }
        
        Dictionary<ushort, int> GetHitsOfYear(Dictionary<ushort, List<UInt64>> topic)
        {
            Dictionary<ushort, int> hits = new Dictionary<ushort, int>();
            foreach (var kv in topic)
            {
                hits.Add(kv.Key, kv.Value.Count);
            }
            return hits;
        }

        double ComputeAdaptiveSLPPI(Dictionary<ushort, int> hitsOfYear, ushort fromYear, ushort toYear)
        {
            LeastSquareSLPPI slppi = new LeastSquareSLPPI(fromYear, toYear, hitsOfYear);
            switch (topicType)
            {
                case TopicType.ISBV1:
                    return slppi.EstimateSlope();
                case TopicType.ISBV2:
                case TopicType.ISBV2P:
                case TopicType.ISBV3:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.CosSim() * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_1:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.CosSim() * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_2:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.CosSim() * slppi.a1;
                    }
                case TopicType.ISBV2_3:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.CosSim() * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_4:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.CosSim() * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_5:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.CosSim() * slppi.a1;
                    }
                case TopicType.ISBV2_6:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.CosSim() * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_7:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.CosSim() * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_8:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.CosSim() * slppi.a1;
                    }
                case TopicType.ISBV2_9:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_10:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_11:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.peakRatio * slppi.a1;
                    }
                case TopicType.ISBV2_12:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_13:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_14:
                    {
                        slppi.Optimize();
                        return slppi.peakRecency * slppi.a1;
                    }
                case TopicType.ISBV2_15:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_16:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_17:
                    {
                        slppi.Optimize();
                        return slppi.peakRatio * slppi.a1;
                    }
                case TopicType.ISBV2_18:
                    {
                        slppi.Optimize();
                        return slppi.CosSim() * slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_19:
                    {
                        slppi.Optimize();
                        return slppi.CosSim() * slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_20:
                    {
                        slppi.Optimize();
                        return slppi.CosSim() * slppi.a1;
                    }
                case TopicType.ISBV2_21:
                    {
                        slppi.Optimize();
                        return slppi.OriginalSlope();
                    }
                case TopicType.ISBV2_22:
                    {
                        slppi.Optimize();
                        return slppi.EstimateSlope();
                    }
                case TopicType.ISBV2_23:
                    {
                        slppi.Optimize();
                        return slppi.a1;
                    }
                default:
                    return 0;
            }
        }

        double ComputeRareness(Dictionary<ushort, int> hitsOfYear, ushort fromYear)
        {
            double sumPastHits = 0;
            foreach (var kv in hitsOfYear)
            {
                if (kv.Key < fromYear)
                {
                    sumPastHits += kv.Value;
                }
            }
            return Math.Sqrt(1.0 / (1.0 + sumPastHits));
        }

        double ComputePredictionScore(Dictionary<ushort, int> hitsOfYear)
        {
            double slppi = ComputeAdaptiveSLPPI(hitsOfYear, fromYear, toYear);
            double rareness = ComputeRareness(hitsOfYear, fromYear);
            return rareness * slppi;
        }

        
    }
}
