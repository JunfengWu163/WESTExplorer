﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Xml;
using JunfengWu.OpenAlex;

namespace JunfengWu.Configuration
{
	public class DataLocation
	{
        Dictionary<string, string> locations = new Dictionary<string, string>();

		public DataLocation()
		{
            // find configuration file
            string[] dirs = new string[] { Environment.CurrentDirectory, AppContext.BaseDirectory };
            string dir = "";
            foreach (string dir1 in dirs) {
                string dir2 = dir1;
                while (!File.Exists(Path.Combine(dir2, "WESTExplorer.config.xml")))
                {
                    Console.WriteLine($"{dir2} does not contain WESTExplorer.config.xml");
                    DirectoryInfo parent = Directory.GetParent(dir2);
                    if (parent == null)
                    {
                        break;
                    }
                    dir2 = parent.FullName;
                }
                if (File.Exists(Path.Combine(dir2, "WESTExplorer.config.xml")))
                {
                    Console.WriteLine($"{dir2} contains WESTExplorer.config.xml");
                    dir = dir2;
                }   
            }

            if (dir == "")
            {
                Environment.Exit(-1);
            }

            XmlDocument configDoc = new XmlDocument();
            try
            {
                configDoc.Load(Path.Combine(dir, "WESTExplorer.config.xml"));
                XmlNode root = configDoc.FirstChild;
                if (root.HasChildNodes)
                {
                    for (int i = 0; i < root.ChildNodes.Count; i++)
                    {
                        XmlNode child = root.ChildNodes[i];
                        string name = child.Name;
                        string value = child.InnerText;
                        locations[name] = value;
                    }
                }
            }
            catch
            {
                System.Environment.Exit(-1);
            }
        }

        public string Get(string name)
        {
            string value;
            if (locations.TryGetValue(name, out value))
            {
                return value;
            }
            else
            {
                return "";
            }
        }

        public string GetSubfieldLocation(UInt64 conceptId)
        {
            ConceptEntity concept = new ConceptEntity(conceptId, this);
            return Path.Combine(Get("westDataPath"), concept.name);
        }

        public string GetSubfieldDirectory(UInt64 conceptId, string dirName)
        {
            return Path.Combine(GetSubfieldLocation(conceptId), dirName);
        }

        public void CreateSubfieldDirectory(UInt64 conceptId, string dirName)
        {
            string path1 = Get("westDataPath");
            if (!Directory.Exists(path1))
            {
                Directory.CreateDirectory(path1);
            }

            ConceptEntity concept = new ConceptEntity(conceptId, this);
            string path2 = Path.Combine(path1, concept.name);
            if (!Directory.Exists(path2))
            {
                Directory.CreateDirectory(path2);
            }

            string path3 = Path.Combine(path2, dirName);
            if (!Directory.Exists(path3))
            {
                Directory.CreateDirectory(path3);
            }
        }
	}
}

