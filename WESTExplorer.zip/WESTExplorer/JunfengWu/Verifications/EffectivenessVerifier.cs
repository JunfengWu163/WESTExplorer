﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MathNet.Numerics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Topics;
using JunfengWu.Predictions;
using JunfengWu.Tools;
using JunfengWu.Synonyms;
using JunfengWu.FastText;

namespace JunfengWu.Verifications
{
    public class EffectivenessVerifier
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public int m { get; private set; }
        public EmergingnessPredictor.TopicType topicType { get; private set; }
        public bool done { get; private set; }
        public string myFileName { get; private set; }
        FastTextModel fastTextModel;

        public EffectivenessVerifier(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, int m, EmergingnessPredictor.TopicType topicType, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.m = m;
            this.topicType = topicType;
            this.fastTextModel = fastTextModel;
            myFileName = GetFileName(k, m);
            done = MD5Check.Check(myFileName);
        }

        string GetFileName(int l, int n)
        {
            string verificationPath = dataLocation.GetSubfieldDirectory(concept.id, "Verifications");
            return Path.Combine(verificationPath, $"{EmergingnessPredictor.GetTopicTypeString(topicType)}-effectiveness-{fromYear}-{toYear}-{l}-{n}.txt");
        }

        int GetBestNomination(int l, int n)
        {
            EmergingnessPredictor emergingnessPredictor = new EmergingnessPredictor(dataLocation, concept, fromYear, toYear, l, topicType, fastTextModel);
            Debug.Assert(emergingnessPredictor.done);
            EmergingnessVerifier emergingnessVerifier = new EmergingnessVerifier(dataLocation, concept, fromYear, toYear, l, topicType, fastTextModel);
            Debug.Assert(emergingnessVerifier.done);

            double[] predictions = emergingnessPredictor.LoadPredictions();
            double[] verifications = emergingnessVerifier.LoadVerifications();

            if (predictions.Length == 0)
                return -1;

            Debug.Assert(predictions.Length == verifications.Length);
            int[] predRank = new int[predictions.Length];
            for (int i = 0; i < predictions.Length; i++)
            {
                predRank[i] = i;
            }
            Array.Sort(predRank, (x, y) => Math.Sign(predictions[y] - predictions[x]));

            double maxVerification = verifications[predRank[0]];
            int iBestTopic = predRank[0];
            for (int i = 1; i < predictions.Length && i < n; i++)
            {
                if (predictions[predRank[i]] <= 0)
                {
                    break;
                }
                if (verifications[predRank[i]] > maxVerification)
                {
                    maxVerification = verifications[predRank[i]];
                    iBestTopic = predRank[i];
                }
            }
            return iBestTopic;
        }

        string GetTopicDescription(int i, int l, IProgress<int> progress)
        {
            List<List<(string, string, float)>> topics;
            if (topicType == EmergingnessPredictor.TopicType.CSO || topicType == EmergingnessPredictor.TopicType.Concept)
            {
                bool useCSO = topicType == EmergingnessPredictor.TopicType.CSO;
                AUGURTopicFinder topicFinder = new AUGURTopicFinder(dataLocation, concept, fromYear, toYear, useCSO, k);
                topics = topicFinder.LoadTopics(progress);
            }
            else
            {
                ISBTopicFinder.Version version = topicType == EmergingnessPredictor.TopicType.ISBV3 ?
                    ISBTopicFinder.Version.V3 : topicType == EmergingnessPredictor.TopicType.ISBV2P ?
                    ISBTopicFinder.Version.V2P : ISBTopicFinder.Version.OlderVersion;
                bool v3 = topicType == EmergingnessPredictor.TopicType.ISBV3;
                ISBTopicFinder topicFinder = new ISBTopicFinder(dataLocation, concept, fromYear, toYear, k, fastTextModel, version);
                topics = topicFinder.LoadTopics(progress);
            }
            Debug.Assert(i >= 0 && i < topics.Count);
            List<(string, string, float)> topicI = topics[i];
            Debug.Assert(topicI.Count > 0);
            string description = topicI[0].Item1 + "&&" + topicI[0].Item2;
            if (topicI.Count > 1 && l > 1)
            {
                description = "(" + description + ")";
                for (int j = 1; j < topicI.Count && j < l; j++)
                {
                    description += "||(" + topicI[j].Item1 + "&&" + topicI[j].Item2 + ")";
                }
            }
            return description;
        }

        int[] GetHits(Dictionary<UInt16, List<UInt64>> pubs, Dictionary<UInt16, List<UInt64>> futurePubs)
        {
            int[] hits = new int[toYear - fromYear + 11];
            for (int i = 0; i < hits.Length; i++)
            {
                hits[i] = 0;
            }
            foreach (var kv in pubs)
            {
                if (kv.Key >= fromYear)
                {
                    hits[kv.Key - fromYear] = kv.Value.Count;
                }
            }
            foreach (var kv in futurePubs)
            {
                if (kv.Key > toYear && kv.Key <= toYear + 10)
                {
                    hits[kv.Key - fromYear] = kv.Value.Count;
                }
            }
            return hits;
        }

        public void Verify(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Verifications");

            TopicPublicationFinder.TopicType publicationTopicType = EmergingnessPredictor.GetPublicationTopicType(topicType);
            TopicPublicationFinder publicationFinder = new TopicPublicationFinder(dataLocation, concept, fromYear, toYear, k, publicationTopicType, fastTextModel);
            Progress<int> myStepProgress1 = new Progress<int>(value => { stepProgress.Report(value / 3); });
            Progress<int> myStepProgress2 = new Progress<int>(value => { stepProgress.Report(33 + value / 3); });
            Progress<int> myStepProgress3 = new Progress<int>(value => { stepProgress.Report(67 + value / 3); });
            totalProgress?.Report(0);
            for (int n = 1; n < m; n++)
            {
                int bestNomination = GetBestNomination(k, n);
                string description = bestNomination >= 0 ? GetTopicDescription(bestNomination, k, myStepProgress1) : "<not available>";
                List<Dictionary<UInt16, List<UInt64>>> topicPublications = publicationFinder.LoadTopicPublications(k, myStepProgress2);
                List<Dictionary<UInt16, List<UInt64>>> topicFuturePublications = publicationFinder.LoadTopicPublications(k, myStepProgress3, true);
                Debug.Assert(topicPublications.Count == topicFuturePublications.Count);
                int[] hits = bestNomination >= 0 ? GetHits(topicPublications[bestNomination], topicFuturePublications[bestNomination]) : new int[toYear - fromYear + 11];
                if (bestNomination < 0)
                {
                    for (int j = 0; j < hits.Length; j++)
                    {
                        hits[j] = 0;
                    }
                }

                string fileName = GetFileName(k, n);
                using (FileStream file = File.Create(fileName))
                {
                    using (StreamWriter writer = new StreamWriter(file))
                    {
                        writer.Write(description.Replace(',', ' '));
                        for (int i = 0; i < hits.Length; i++)
                        {
                            writer.Write($",{hits[i]}");
                        }
                        writer.WriteLine();
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
                totalProgress?.Report(50 * n / (m - 1));
            }
            for (int l = 1; l <= k; l++)
            {
                int bestNomination = GetBestNomination(l, m);
                string description = bestNomination >= 0 ? GetTopicDescription(bestNomination, l, myStepProgress1) : "<not available>";

                List<Dictionary<UInt16, List<UInt64>>> topicPublications = publicationFinder.LoadTopicPublications(l, myStepProgress2);
                List<Dictionary<UInt16, List<UInt64>>> topicFuturePublications = publicationFinder.LoadTopicPublications(l, myStepProgress3, true);
                Debug.Assert(topicPublications.Count == topicFuturePublications.Count);
                Debug.Assert(topicPublications.Count > bestNomination);
                int[] hits = bestNomination >= 0 ? GetHits(topicPublications[bestNomination], topicFuturePublications[bestNomination]) : new int[toYear - fromYear + 11];
                if (bestNomination < 0)
                {
                    for (int j = 0; j < hits.Length; j++)
                    {
                        hits[j] = 0;
                    }
                }

                string fileName = GetFileName(l, m);
                using (FileStream file = File.Create(fileName))
                {
                    using (StreamWriter writer = new StreamWriter(file))
                    {
                        writer.Write(description.Replace(',',' '));
                        for (int i = 0; i < hits.Length; i++)
                        {
                            writer.Write($",{hits[i]}");
                        }
                        writer.WriteLine();
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
                totalProgress?.Report(50 + 50 * l / k);
            }
        }

        public (string, int[]) LoadVerifications(int l, int n)
        {
            string fileName = GetFileName(l, n);
            string[] lines = File.ReadAllLines(fileName);
            Debug.Assert(lines.Length > 0);
            string[] parts = lines[0].Split(',');
            Debug.Assert(parts.Length == toYear - fromYear + 12);
            string description = parts[0];
            int[] hits = new int[toYear - fromYear + 11];
            for (int i = 0; i < hits.Length; i++)
            {
                hits[i] = Convert.ToInt32(parts[i + 1]);
            }
            return (description, hits);
        }
    }
}

