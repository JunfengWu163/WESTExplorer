﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MathNet.Numerics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Topics;
using JunfengWu.Predictions;
using JunfengWu.Tools;
using JunfengWu.FastText;

namespace JunfengWu.Verifications
{
    public class EmergingnessVerifier
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public EmergingnessPredictor.TopicType topicType { get; private set; }
        public bool done { get; private set; }
        public string myFileName { get; private set; }
        FastTextModel fastTextModel;

        public EmergingnessVerifier(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, EmergingnessPredictor.TopicType topicType, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.topicType = topicType;
            this.fastTextModel = fastTextModel;
            myFileName = GetFileName(k);
            done = MD5Check.Check(myFileName);
        }

        string GetFileName(int l)
        {
            string verificationPath = dataLocation.GetSubfieldDirectory(concept.id, "Verifications");
            return Path.Combine(verificationPath, $"{EmergingnessPredictor.GetTopicTypeString(topicType)}-emergingness-{fromYear}-{toYear}-{l}.txt");
        }

        public void Verify(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Verifications");

            TopicPublicationFinder.TopicType publicationTopicType = EmergingnessPredictor.GetPublicationTopicType(topicType);
            TopicPublicationFinder publicationFinder = new TopicPublicationFinder(dataLocation, concept, fromYear, toYear, k, publicationTopicType, fastTextModel);
            Progress<int> myStepProgress1 = new Progress<int>(value => { stepProgress?.Report(value / 2); });
            Progress<int> myStepProgress2 = new Progress<int>(value => { stepProgress?.Report(50 + value / 2); }); 
            totalProgress?.Report(0);
            for (int l = 1; l <= k; l++)
            {
                List<Dictionary<UInt16, List<UInt64>>> topicPublications = publicationFinder.LoadTopicPublications(l, myStepProgress1);
                List<Dictionary<UInt16, List<UInt64>>> topicFuturePublications = publicationFinder.LoadTopicPublications(l, myStepProgress2, true);
                Debug.Assert(topicPublications.Count == topicFuturePublications.Count);
                double[] verificationScores = new double[topicPublications.Count];
                for (int j = 0; j < verificationScores.Length; j++)
                {
                    Dictionary<ushort, int> hitsOfYear = GetHitsOfYear(topicPublications[j], topicFuturePublications[j]);
                    verificationScores[j] = ComputeVerificationScore(hitsOfYear);
                }

                string fileName = GetFileName(l);
                using (FileStream file = File.Create(fileName))
                {
                    using (StreamWriter writer = new StreamWriter(file))
                    {
                        for (int j = 0; j < verificationScores.Length; j++)
                        {
                            writer.WriteLine($"{verificationScores[j]}");
                        }
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
                totalProgress?.Report(100 * l / k);
            }
        }

        public double[] LoadVerifications()
        {
            string[] lines = File.ReadAllLines(myFileName);
            double[] verifications = new double[lines.Length];
            for (int j = 0; j < verifications.Length; j++)
            {
                verifications[j] = Convert.ToDouble(lines[j]);
            }
            return verifications;
        }

        Dictionary<ushort, int> GetHitsOfYear(Dictionary<ushort, List<UInt64>> topic, Dictionary<ushort, List<UInt64>> futureTopic)
        {
            Dictionary<ushort, int> hits = new Dictionary<ushort, int>();
            foreach (var kv in topic)
            {
                hits.Add(kv.Key, kv.Value.Count);
            }
            foreach (var kv in futureTopic)
            {
                hits.Add(kv.Key, kv.Value.Count);
            }
            return hits;
        }

        double ComputeSLP(Dictionary<ushort, int> hitsOfYear, ushort fromYear, ushort toYear)
        {
            int numYears = toYear - fromYear + 1;
            double[] hits = new double[numYears];
            double[] years = new double[numYears];
            for (int idxYear = 0; idxYear < numYears; idxYear++)
            {
                ushort year = Convert.ToUInt16(fromYear + idxYear);
                int hit;
                if (hitsOfYear.TryGetValue(year, out hit))
                {
                    hits[idxYear] = hit;
                }
                else
                {
                    hits[idxYear] = 0;
                }
                years[idxYear] = year;
            }
            (double a, double b) = WeightedLeastSquares.FitLine(years, hits, 5, 1.0);
            return b;
        }

        double GetSumPastHits(Dictionary<ushort, int> hitsOfYear, ushort fromYear)
        {
            double sumPastHits = 0;
            foreach (var kv in hitsOfYear)
            {
                if (kv.Key < fromYear)
                {
                    sumPastHits += kv.Value;
                }
            }
            return sumPastHits;
        }

        double ComputeRareness(Dictionary<ushort, int> hitsOfYear, ushort fromYear)
        {
            double sumPastHits = 0;
            foreach (var kv in hitsOfYear)
            {
                if (kv.Key < fromYear)
                {
                    sumPastHits += kv.Value;
                }
            }
            return Math.Sqrt(1.0 / (1.0 + sumPastHits));
        }

        double ComputeVerificationScore(Dictionary<ushort, int> hitsOfYear)
        {
            double slp = ComputeSLP(hitsOfYear, fromYear, Convert.ToUInt16(toYear + 10));
            double rareness = ComputeRareness(hitsOfYear, fromYear);
            return rareness * slp;
        }
        
    }
}
