﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MathNet.Numerics;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Topics;
using JunfengWu.Predictions;
using JunfengWu.Tools;
using JunfengWu.FastText;

namespace JunfengWu.Verifications
{
    public class TopicRiseDurationEvaluator
    {
        public DataLocation dataLocation { get; private set; }
        public ConceptEntity concept { get; private set; }
        public UInt16 fromYear { get; private set; }
        public UInt16 toYear { get; private set; }
        public int k { get; private set; }
        public EmergingnessPredictor.TopicType topicType { get; private set; }
        public bool done { get; private set; }
        public string myFileName { get; private set; }
        FastTextModel fastTextModel;

        public TopicRiseDurationEvaluator(DataLocation dataLocation, ConceptEntity concept, UInt16 fromYear, UInt16 toYear, int k, EmergingnessPredictor.TopicType topicType, FastTextModel fastTextModel)
        {
            this.dataLocation = dataLocation;
            this.concept = concept;
            this.fromYear = fromYear;
            this.toYear = toYear;
            this.k = k;
            this.topicType = topicType;
            this.fastTextModel = fastTextModel;
            myFileName = GetFileName(k);
            done = MD5Check.Check(myFileName);
        }

        string GetFileName(int l)
        {
            string verificationPath = dataLocation.GetSubfieldDirectory(concept.id, "Verifications");
            return Path.Combine(verificationPath, $"{EmergingnessPredictor.GetTopicTypeString(topicType)}-topicRiseDuration-{fromYear}-{toYear}-{l}.txt");
        }

        public void Verify(IProgress<int> totalProgress, IProgress<int> stepProgress)
        {
            if (done)
            {
                return;
            }

            dataLocation.CreateSubfieldDirectory(concept.id, "Verifications");

            TopicPublicationFinder.TopicType publicationTopicType = EmergingnessPredictor.GetPublicationTopicType(topicType);
            TopicPublicationFinder publicationFinder = new TopicPublicationFinder(dataLocation, concept, fromYear, toYear, k, publicationTopicType, fastTextModel);
            Progress<int> myStepProgress1 = new Progress<int>(value => { stepProgress?.Report(value / 2); });
            Progress<int> myStepProgress2 = new Progress<int>(value => { stepProgress?.Report(50 + value / 2); });
            totalProgress?.Report(0);
            for (int l = 1; l <= k; l++)
            {
                List<Dictionary<UInt16, List<UInt64>>> topicPublications = publicationFinder.LoadTopicPublications(l, myStepProgress1);
                List<Dictionary<UInt16, List<UInt64>>> topicFuturePublications = publicationFinder.LoadTopicPublications(l, myStepProgress2, true);
                Debug.Assert(topicPublications.Count == topicFuturePublications.Count);
                double[] verificationScores = new double[topicPublications.Count];
                for (int j = 0; j < verificationScores.Length; j++)
                {
                    double duration = GetRiseDuration(topicPublications[j], topicFuturePublications[j]);
                    verificationScores[j] = duration;
                }

                string fileName = GetFileName(l);
                using (FileStream file = File.Create(fileName))
                {
                    using (StreamWriter writer = new StreamWriter(file))
                    {
                        for (int j = 0; j < verificationScores.Length; j++)
                        {
                            writer.WriteLine($"{verificationScores[j]}");
                        }
                    }
                }
                MD5Check.SaveMD5Hash(fileName);
                totalProgress?.Report(100 * l / k);
            }
        }

        public double[] LoadVerifications()
        {
            string[] lines = File.ReadAllLines(myFileName);
            double[] verifications = new double[lines.Length];
            for (int j = 0; j < verifications.Length; j++)
            {
                verifications[j] = Convert.ToDouble(lines[j]);
            }
            return verifications;
        }

        double GetRiseDuration(Dictionary<ushort, List<UInt64>> topic, Dictionary<ushort, List<UInt64>> futureTopic)
        {
            int peak = 0;
            UInt16 yearOfPeak = fromYear;
            foreach (var kv in topic)
            {
                if (kv.Value.Count > peak)
                {
                    peak = kv.Value.Count;
                    yearOfPeak = kv.Key;
                }
            }
            foreach (var kv in futureTopic)
            {
                if (kv.Value.Count > peak)
                {
                    peak = kv.Value.Count;
                    yearOfPeak = kv.Key;
                }
            }
            return Convert.ToDouble(yearOfPeak) - Convert.ToDouble(fromYear);
        }
    }
}

