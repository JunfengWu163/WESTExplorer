﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JunfengWu.Configuration;

namespace JunfengWu.OpenAlex
{
    public class AuthorEntity: IndexedStorage
    {
        public UInt64 id { get; private set; }
        public string name { get; private set; }

        public AuthorEntity(UInt64 idNumber, DataLocation dataLocation)
        {
            string path = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(path, "author-sorted_index.wjf");
            Int64 authorPos = FindIndex(indexFileName, idNumber);
            if (authorPos >= 0)
            {
                string dataFileName = Path.Combine(path, "author-data.wjf");
                Deserialize(dataFileName, idNumber, authorPos);
            }
            else
            {
                id = 0;
            }
        }

        public AuthorEntity(string fileName, UInt64 idNumber, Int64 authorPos)
        {
            Deserialize(fileName, idNumber, authorPos);
        }

        Byte[] GetNameBytes()
        {
            return Encoding.UTF8.GetBytes(name);
        }

        void Deserialize(string fileName, UInt64 idNumber, Int64 authorPos)
        {
            using (FileStream dataFile = File.OpenRead(fileName))
            {
                dataFile.Seek(authorPos, SeekOrigin.Begin);
                using (BinaryReader dataReader = new BinaryReader(dataFile))
                {
                    id = dataReader.ReadUInt64();
                    Debug.Assert(idNumber == id);

                    UInt32 nameLength = dataReader.ReadUInt32();

                    Byte[] nameBytes = new Byte[nameLength];
                    dataReader.Read(nameBytes);
                    name = Encoding.UTF8.GetString(nameBytes);
                }
            }
        }

        public void Serialize(Int64 authorPos, BinaryWriter dataWriter, BinaryWriter indexWriter)
        {
            indexWriter.Write(id);
            indexWriter.Write(authorPos);

            Byte[] nameBytes = GetNameBytes();
            UInt32 nameLength = Convert.ToUInt32(nameBytes.Length);
            dataWriter.Write(id);
            dataWriter.Write(nameLength);
            dataWriter.Write(nameBytes);
        }

        public static void SortIndices(DataLocation dataLocation)
        {
            string outputPath = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(outputPath, $"author-index.wjf");
            string sortedIndexFileName = Path.Combine(outputPath, $"author-sorted_index.wjf");
            List<(UInt64, Int64)> indices = LoadIndices(indexFileName);
            indices.Sort((x, y) => Math.Sign(Convert.ToInt64(x.Item1) - Convert.ToInt64(y.Item1)));
            using (FileStream fileOut = File.Create(sortedIndexFileName))
            {
                using (BinaryWriter indexWriter = new BinaryWriter(fileOut))
                {
                    for (int i = 0; i < indices.Count; i++)
                    {
                        indexWriter.Write(indices[i].Item1);
                        indexWriter.Write(indices[i].Item2);
                    }
                }
            }
        }
    }
}
