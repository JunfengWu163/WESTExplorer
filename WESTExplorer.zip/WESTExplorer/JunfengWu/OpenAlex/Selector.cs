﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using JunfengWu.Configuration;

namespace JunfengWu.OpenAlex
{
    public class Selector
    {
        public DataLocation dataLocation { get; private set; }

        public List<ConceptEntity> concepts { get; private set; }

        public List<ConceptEntity> level0Concepts { get; private set; }
        public ConceptEntity selectedConcept { get; private set; } = null;

        public Selector(DataLocation dataLocation)
        {
            this.dataLocation = dataLocation;
            concepts = ConceptEntity.Load(dataLocation);
            concepts.Sort((x, y) => String.Compare(x.name, y.name));
            level0Concepts = ConceptEntity.Filter(concepts);
        }

        public List<ConceptEntity> GetNextLevelConcepts()
        {
            if (selectedConcept == null)
            {
                return level0Concepts;
            }
            else
            {
                return ConceptEntity.Filter(concepts, selectedConcept);
            }
        }

        public void Select(ConceptEntity concept)
        {
            selectedConcept = concept;
        }

        public void Confirm(IProgress<int> totalProgress = null, IProgress<int> bucketProgress = null)
        {
            
            Debug.Assert(selectedConcept.level == 1);
            totalProgress?.Report(0);
            for (int idxBucket = 0; idxBucket < 64; idxBucket++)
            {
                if (!WorkEntity.CheckSubfieldBucket(idxBucket, dataLocation, selectedConcept.id))
                {
                    List<WorkEntity> works = new List<WorkEntity>();
                    works = WorkEntity.LoadBucket(idxBucket, dataLocation, bucketProgress, selectedConcept.id);
                    WorkEntity.SaveBucket(works, idxBucket, dataLocation, selectedConcept.id);
                }
                
                int progressValue = 100 * (idxBucket + 1) / 64;
                totalProgress?.Report(progressValue);
            }
        }
    }
}

