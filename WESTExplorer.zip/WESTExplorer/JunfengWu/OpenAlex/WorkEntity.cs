﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Net;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JunfengWu.Configuration;
using JunfengWu.Tools;

namespace JunfengWu.OpenAlex
{
    public class WorkEntity: IndexedStorage
    {
        public UInt64 id { get; private set; }
        public UInt16 year { get; private set; }
        public UInt64 venueId { get; private set; }
        public string title { get; private set; }
        public List<(UInt64, double)> concepts { get; private set; } = new List<(UInt64, double)>();
        public List<UInt64> references { get; private set; } = new List<UInt64>();
        public List<(UInt64, UInt16)> authorships { get; private set; } = new List<(UInt64, UInt16)>();

        static string GetUpdateURL(UInt16 year, string email, string cursur)
        {
            return "https://api.openalex.org/works?mailto=" + email
                + "&filter=publication_year:" + Convert.ToString(year) + "&per-page=200&cursor=" + cursur;
        }

        public static async void GetUpdate(UInt16 year, string email)
        {
            HttpClient client = new HttpClient();
            string firstURL = GetUpdateURL(year, email, "*");
            try
            {
                var content = await client.GetStringAsync(firstURL);
            }
            catch
            {

            }
        }

        public static bool CheckSubfieldBucket(int idxBucket, DataLocation dataLocation, UInt64 conceptId)
        {
            string path = dataLocation.GetSubfieldDirectory(conceptId, "Works");
            string summaryFileName = Path.Combine(path, $"summary-data-{idxBucket}.txt");
            return MD5Check.Check(summaryFileName);
        }

        public static List<WorkEntity> LoadBucket(int idxBucket, DataLocation dataLocation, IProgress<int> progress, UInt64 conceptId = UInt64.MaxValue, UInt16 year = UInt16.MaxValue)
        {
            string path = dataLocation.Get("openAlexPath");
            List<WorkEntity> works = new List<WorkEntity>();
            string dataFileName = Path.Combine(path, $"work-data-{idxBucket}.wjf");
            using (FileStream file = File.OpenRead(dataFileName))
            {
                using (BinaryReader reader = new BinaryReader(file))
                {
                    int progressValue = 0;
                    progress?.Report(progressValue);
                    if (conceptId < UInt64.MaxValue)
                    {
                        if (year < UInt16.MaxValue)
                        {
                            while (file.Position < file.Length)
                            {
                                WorkEntity work = new WorkEntity(reader);
                                if (work.RelevantToConcept(conceptId) && work.year == year)
                                {
                                    works.Add(work);
                                }
                                int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                                if (newProgressValue > progressValue)
                                {
                                    progress?.Report(newProgressValue);
                                    progressValue = newProgressValue;
                                }
                            }
                        }
                        else
                        {
                            while (file.Position < file.Length)
                            {
                                WorkEntity work = new WorkEntity(reader);
                                if (work.RelevantToConcept(conceptId))
                                {
                                    works.Add(work);
                                }
                                int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                                if (newProgressValue > progressValue)
                                {
                                    progress?.Report(newProgressValue);
                                    progressValue = newProgressValue;
                                }
                            }
                        }
                    }
                    else if (year < UInt16.MaxValue)
                    {
                        while (file.Position < file.Length)
                        {
                            WorkEntity work = new WorkEntity(reader);
                            if (work.year == year)
                            {
                                works.Add(work);
                            }
                            int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                            if (newProgressValue > progressValue)
                            {
                                progress?.Report(newProgressValue);
                                progressValue = newProgressValue;
                            }
                        }
                    }
                    else
                    {
                        while (file.Position < file.Length)
                        {
                            works.Add(new WorkEntity(reader));
                            int newProgressValue = Convert.ToInt32(100 * file.Position / file.Length);
                            if (newProgressValue > progressValue)
                            {
                                progress?.Report(newProgressValue);
                                progressValue = newProgressValue;
                            }
                        }
                    }
                }
            }
            return works;
        }

        public static List<WorkEntity> LoadSubfieldBucket(int idxBucket, DataLocation dataLocation, UInt64 conceptId, UInt16 year)
        {
            List<WorkEntity> works = new List<WorkEntity>();

            string path = dataLocation.GetSubfieldDirectory(conceptId, "Works");
            if (!Directory.Exists(path))
            {
                return works;
            }

            string dataFileName = Path.Combine(path, $"{year}-data-{idxBucket}.wjf");
            if (!File.Exists(dataFileName))
            {
                return works;
            }

            using (FileStream file = File.OpenRead(dataFileName))
            {
                using (BinaryReader reader = new BinaryReader(file))
                {
                    while (file.Position < file.Length)
                    {
                        works.Add(new WorkEntity(reader));
                    }
                }
            }
            return works;
        }

        public static List<WorkEntity> FilterBucketByYear(List<WorkEntity> works, UInt16 year)
        {
            List<WorkEntity> filteredWorks = new List<WorkEntity>();
            foreach (WorkEntity work in works)
            {
                if (work.year == year)
                {
                    filteredWorks.Add(work);
                }
            }
            return filteredWorks;
        }

        public static void SaveBucket(List<WorkEntity> works, int idxBucket, DataLocation dataLocation, UInt64 conceptId)
        {
            dataLocation.CreateSubfieldDirectory(conceptId, "Works");
            string path = dataLocation.GetSubfieldDirectory(conceptId, "Works");

            string summaryFileName = Path.Combine(path, $"summary-data-{idxBucket}.txt");
            if (MD5Check.Check(summaryFileName))
            {
                return;
            }

            Dictionary<UInt16, List<WorkEntity>> worksByYear = new Dictionary<ushort, List<WorkEntity>>();
            foreach (WorkEntity work in works)
            {
                UInt16 year = work.year;
                List<WorkEntity> worksOfYear;
                if (!worksByYear.TryGetValue(year, out worksOfYear))
                {
                    worksOfYear = new List<WorkEntity>();
                    worksByYear.Add(year, worksOfYear);
                }
                worksOfYear?.Add(work);
            }

            foreach (var kv in worksByYear)
            {
                UInt16 year = kv.Key;
                List<WorkEntity> worksOfYear = kv.Value;
                if (year > 0 && worksOfYear.Count > 0)
                {
                    string dataFileName = Path.Combine(path, $"{year}-data-{idxBucket}.wjf");
                    string indexFileName = Path.Combine(path, $"{year}-index-{idxBucket}.wjf");
                    using (FileStream fileData = File.Create(dataFileName))
                    {
                        using (FileStream fileIndex = File.Create(indexFileName))
                        {
                            for (int i = 0; i < worksOfYear.Count; i++)
                            {
                                worksOfYear[i].Serialize(fileIndex, fileData);
                            }
                        }
                    }

                    SortIndices(indexFileName);
                }
            }

            using (FileStream file = File.Create(summaryFileName))
            {
                using (StreamWriter writer = new StreamWriter(file))
                {
                    foreach (var kv in worksByYear)
                    {
                        UInt16 year = kv.Key;
                        List<WorkEntity> worksOfYear = kv.Value;
                        if (year > 0 && worksOfYear.Count > 0)
                        {
                            string dataFileName = $"{year}-data-{idxBucket}.wjf";
                            string indexFileName = $"{year}-index-{idxBucket}.wjf";
                            writer.WriteLine(dataFileName);
                            writer.WriteLine(indexFileName);
                        }
                    }
                }
            }
            MD5Check.SaveMD5Hash(summaryFileName);
        }

        WorkEntity(BinaryReader dataReader)
        {
            Deserialize(dataReader);
        }

        public WorkEntity(UInt64 idNumber, DataLocation dataLocation)
        {
            UInt64 idxBucket = idNumber % 64;
            string path = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(path, $"work-sorted_index-{idxBucket}.wjf");
            Int64 workPos = FindIndex(indexFileName, idNumber);
            if (workPos >= 0)
            {
                string dataFileName = Path.Combine(path, $"work-data-{idxBucket}.wjf");
                Deserialize(dataFileName, idNumber, workPos);
            }
            else
            {
                id = 0;
                year = 0;
            }
        }

        void Deserialize(BinaryReader dataReader)
        {
            //dataWriter.Write(idNumber);
            id = dataReader.ReadUInt64();
            
            //dataWriter.Write(venueIdNumber);
            venueId = dataReader.ReadUInt64();

            //dataWriter.Write(publication_year);
            year = dataReader.ReadUInt16();

            //dataWriter.Write(titleLength);
            UInt16 titleLength = dataReader.ReadUInt16();

            //dataWriter.Write(numConcepts);
            UInt16 numConcepts = dataReader.ReadUInt16();

            //dataWriter.Write(numReferences);
            UInt16 numReferences = dataReader.ReadUInt16();

            //dataWriter.Write(numAuthorships);
            UInt16 numAuthorships = dataReader.ReadUInt16();

            //dataWriter.Write(titleBytes);
            Byte[] titleBytes = new Byte[titleLength];
            dataReader.Read(titleBytes);
            title = Encoding.UTF8.GetString(titleBytes);

            for (UInt16 idxConcept = 0; idxConcept < numConcepts; idxConcept++)
            {
                /*UInt64 conceptIdNumber = concepts[idxConcept].GetIdNumber();
                double score = concepts[idxConcept].score;
                dataWriter.Write(conceptIdNumber);
                dataWriter.Write(score);*/
                UInt64 conceptId = dataReader.ReadUInt64();
                double score = dataReader.ReadDouble();
                concepts.Add((conceptId, score));
            }
            for (UInt16 idxReference = 0; idxReference < numReferences; idxReference++)
            {
                /*UInt64 referenceIdNumber = GetIdNumber(referenced_works[idxReference]);
                dataWriter.Write(referenceIdNumber);*/
                UInt64 referenceId = dataReader.ReadUInt64();
                references.Add(referenceId);
            }
            for (UInt16 idxAuthorship = 0; idxAuthorship < numAuthorships; idxAuthorship++)
            {
                /*UInt64 authorIdNumber = authorships[idxAuthorship].author.GetIdNumber();
                UInt16 positionNumber = authorships[idxAuthorship].GetPositionNumber();
                dataWriter.Write(authorIdNumber);
                dataWriter.Write(positionNumber);
                authorships[idxAuthorship].author.UpdateAuthors(authors);*/
                UInt64 authorId = dataReader.ReadUInt64();
                UInt16 positionNumber = dataReader.ReadUInt16();
                authorships.Add((authorId, positionNumber));
            }
        }

        void Deserialize(string fileName, UInt64 idNumber, Int64 workPos)
        {
            using (FileStream dataFile = File.OpenRead(fileName))
            {
                dataFile.Seek(workPos, SeekOrigin.Begin);
                using (BinaryReader dataReader = new BinaryReader(dataFile))
                {
                    Deserialize(dataReader);
                    Debug.Assert(idNumber == id);
                }
            }
        }

        public WorkEntity(string fileName, UInt64 idNumber, Int64 workPos)
        {
            Deserialize(fileName, idNumber, workPos);
        }

        Byte[] GetTitleBytes()
        {
            return Encoding.UTF8.GetBytes(title);
        }

        bool RelevantToConcept(UInt64 conceptId)
        {
            if (concepts == null)
            {
                return false;
            }
            foreach ((UInt64 id, double relevance) in concepts)
            {
                if (id == conceptId)
                {
                    return true;
                }
            }
            return false;
        }

        public void Serialize(FileStream indexFile, FileStream dataFile)
        {
            Int64 workPos = dataFile.Position;
            Byte[] titleBytes = GetTitleBytes();
            UInt16 titleLength = Convert.ToUInt16(titleBytes.Length);
            UInt16 numConcepts = Convert.ToUInt16(concepts.Count);
            UInt16 numReferences = Convert.ToUInt16(references.Count);
            UInt16 numAuthorships = Convert.ToUInt16(authorships.Count);

            BinaryWriter indexWriter = new BinaryWriter(indexFile);
            indexWriter.Write(id);
            indexWriter.Write(workPos);

            BinaryWriter dataWriter = new BinaryWriter(dataFile);
            dataWriter.Write(id);
            dataWriter.Write(venueId);
            dataWriter.Write(year);
            dataWriter.Write(titleLength);
            dataWriter.Write(numConcepts);
            dataWriter.Write(numReferences);
            dataWriter.Write(numAuthorships);
            dataWriter.Write(titleBytes);
            for (UInt16 idxConcept = 0; idxConcept < numConcepts; idxConcept++)
            {
                (UInt64 conceptId, double score) = concepts[idxConcept];
                dataWriter.Write(conceptId);
                dataWriter.Write(score);
            }
            for (UInt16 idxReference = 0; idxReference < numReferences; idxReference++)
            {
                UInt64 referenceId = references[idxReference];
                dataWriter.Write(referenceId);
            }
            for (UInt16 idxAuthorship = 0; idxAuthorship < numAuthorships; idxAuthorship++)
            {
                (UInt64 authorId, UInt16 positionNumber) = authorships[idxAuthorship];
                dataWriter.Write(authorId);
                dataWriter.Write(positionNumber);
            }
        }

        static bool IsDataFileName(string fileName)
        {
            return (fileName.StartsWith("work-data-") && fileName.EndsWith(".wjf"));
        }

        static string GetIndexFileName(string dataFileName)
        {
            return dataFileName.Replace("data","index");
        }
        

        public static void SortIndices(string indexFileName)
        {
            string sortedIndexFileName = indexFileName.Replace("index", "sorted_index");
            List<(UInt64, Int64)> indices = LoadIndices(indexFileName);
            indices.Sort((x, y) => Math.Sign(Convert.ToInt64(x.Item1) - Convert.ToInt64(y.Item1)));
            using (FileStream fileOut = File.Create(sortedIndexFileName))
            {
                using (BinaryWriter indexWriter = new BinaryWriter(fileOut))
                {
                    for (int i = 0; i < indices.Count; i++)
                    {
                        indexWriter.Write(indices[i].Item1);
                        indexWriter.Write(indices[i].Item2);
                    }
                }
            }
        }

        public static void SortIndices(DataLocation dataLocation, UInt64 numBuckets)
        {
            string outputPath = dataLocation.Get("openAlexPath");
            for (UInt64 idxBucket = 0; idxBucket < numBuckets; idxBucket++)
            {
                Console.WriteLine($"sort indices of bucket {idxBucket}");
                string indexFileName = Path.Combine(outputPath, $"work-index-{idxBucket}.wjf");
                SortIndices(indexFileName);
            }
        }
    }
}
