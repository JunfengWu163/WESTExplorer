﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JunfengWu.Configuration;

namespace JunfengWu.OpenAlex
{
    public class ConceptEntity: IndexedStorage
    {
        public UInt64 id { get; private set; }
        public UInt16 level { get; private set; }
        public string name { get; private set; }
        public List<UInt64> ancestorIds { get; private set; } = new List<UInt64>();

        public static List<ConceptEntity> Load(DataLocation dataLocation)
        {
            string path = dataLocation.Get("openAlexPath");
            List<ConceptEntity> concepts = new List<ConceptEntity>();
            string dataFileName = Path.Combine(path, "concept-data.wjf");
            using (FileStream dataFile = File.OpenRead(dataFileName))
            {
                using (BinaryReader dataReader = new BinaryReader(dataFile))
                {
                    while (dataFile.Position < dataFile.Length)
                    {
                        concepts.Add(new ConceptEntity(dataReader));
                    }
                }
            }
            return concepts;
        }

        public static List<ConceptEntity> Filter(List<ConceptEntity> concepts, string parentName = "")
        {
            if (parentName == "")
            {
                List<ConceptEntity> filteredConcepts = new List<ConceptEntity>();
                foreach (ConceptEntity concept in concepts)
                {
                    if (concept.level == 0)
                    {
                        filteredConcepts.Add(concept);
                    }
                }
                return filteredConcepts;
            }
            else
            {
                foreach (ConceptEntity concept in concepts)
                {
                    if (concept.name == parentName)
                    {
                        return Filter(concepts, concept);
                    }
                }
                return new List<ConceptEntity>();
            }
        }

        public static List<ConceptEntity> Filter(List<ConceptEntity> concepts, ConceptEntity parent)
        {
            List<ConceptEntity> filteredConcepts = new List<ConceptEntity>();

            UInt64 parentId = parent.id;
            UInt16 parentLevel = parent.level;
            foreach (ConceptEntity concept in concepts)
            {
                if (concept.level == parentLevel + 1 && concept.SpawnedFrom(parentId))
                {
                    filteredConcepts.Add(concept);
                }
            }
            return filteredConcepts;
        }

        ConceptEntity(BinaryReader dataReader)
        {
            Deserialize(dataReader);
        }

        public ConceptEntity(UInt64 idNumber, DataLocation dataLocation)
        {
            string path = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(path, "concept-sorted_index.wjf");
            Int64 conceptPos = FindIndex(indexFileName, idNumber);
            if (conceptPos >= 0)
            {
                string dataFileName = Path.Combine(path, "concept-data.wjf");
                Deserialize(dataFileName, idNumber, conceptPos);
            }
            else
            {
                id = 0;
            }
        }

        public ConceptEntity(string fileName, UInt64 idNumber, Int64 conceptPos)
        {
            Deserialize(fileName, idNumber, conceptPos);
        }

        Byte[] GetNameBytes()
        {
            return Encoding.UTF8.GetBytes(name);
        }

        bool SpawnedFrom(UInt64 ancestorId)
        {
            if (ancestorIds == null)
            {
                return false;
            }
            foreach (UInt64 id in ancestorIds)
            {
                if (id == ancestorId)
                {
                    return true;
                }
            }
            return false;
        }

        void Deserialize(BinaryReader dataReader)
        {
            id = dataReader.ReadUInt64();

            level = dataReader.ReadUInt16();

            UInt16 nameLength = dataReader.ReadUInt16();
            UInt16 numAncestors = dataReader.ReadUInt16();

            Byte[] nameBytes = new Byte[nameLength];
            dataReader.Read(nameBytes);
            name = Encoding.UTF8.GetString(nameBytes);

            for (UInt16 idxAncestor = 0; idxAncestor < numAncestors; idxAncestor++)
            {
                UInt64 ancestorId = dataReader.ReadUInt64();
                ancestorIds.Add(ancestorId);
            }
        }

        void Deserialize(string fileName, UInt64 idNumber, Int64 conceptPos)
        {
            using (FileStream dataFile = File.OpenRead(fileName))
            {
                dataFile.Seek(conceptPos, SeekOrigin.Begin);
                using (BinaryReader dataReader = new BinaryReader(dataFile))
                {
                    Deserialize(dataReader);
                    Debug.Assert(idNumber == id);
                }
            }
        }

        public void Serialize(Int64 conceptPos, BinaryWriter dataWriter, BinaryWriter indexWriter)
        {
            indexWriter.Write(id);
            indexWriter.Write(conceptPos);

            Byte[] nameBytes = GetNameBytes();
            UInt16 nameLength = Convert.ToUInt16(nameBytes.Length);
            UInt16 numAncestors = Convert.ToUInt16(ancestorIds.Count);
            dataWriter.Write(id);
            dataWriter.Write(level);
            dataWriter.Write(nameLength);
            dataWriter.Write(numAncestors);
            dataWriter.Write(nameBytes);
            for (UInt16 idxAncestor = 0; idxAncestor < numAncestors; idxAncestor++)
            {
                dataWriter.Write(ancestorIds[idxAncestor]);
            }
        }

        public static void SortIndices(DataLocation dataLocation)
        {
            string outputPath = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(outputPath, $"concept-index.wjf");
            string sortedIndexFileName = Path.Combine(outputPath, $"concept-sorted_index.wjf");
            List<(UInt64, Int64)> indices = LoadIndices(indexFileName);
            indices.Sort((x, y) => Math.Sign(Convert.ToInt64(x.Item1) - Convert.ToInt64(y.Item1)));
            using (FileStream fileOut = File.Create(sortedIndexFileName))
            {
                using (BinaryWriter indexWriter = new BinaryWriter(fileOut))
                {
                    for (int i = 0; i < indices.Count; i++)
                    {
                        indexWriter.Write(indices[i].Item1);
                        indexWriter.Write(indices[i].Item2);
                    }
                }
            }
        }
    }
}
