﻿using System;
using System.IO;
using System.Collections.Generic;

namespace JunfengWu.OpenAlex
{
    public class IndexedStorage
    {
        public IndexedStorage()
        {
            
        }

        protected Int64 FindIndex(string indexFileName, UInt64 idNumber)
        {
            if (File.Exists(indexFileName))
            {
                using (FileStream indexFile = File.OpenRead(indexFileName))
                {
                    Int64 numIndices = indexFile.Length >> 4;
                    if (numIndices == 0)
                    {
                        return -1;
                    }

                    Int64 iStart = 0, iEnd = numIndices - 1;
                    using (BinaryReader reader = new BinaryReader(indexFile))
                    {
                        UInt64 indexStart = reader.ReadUInt64();
                        if (idNumber == indexStart)
                        {
                            return reader.ReadInt64();
                        }
                        else if (idNumber < indexStart)
                        {
                            return -1;
                        }

                        indexFile.Seek(iEnd << 4, SeekOrigin.Begin);
                        UInt64 indexEnd = reader.ReadUInt64();
                        if (idNumber == indexEnd)
                        {
                            return reader.ReadInt64();
                        }
                        else if (idNumber > indexEnd)
                        {
                            return -1;
                        }

                        while (iEnd - iStart >= 2)
                        {
                            Int64 iMiddle = (iStart + iEnd) >> 1;
                            indexFile.Seek(iMiddle << 4, SeekOrigin.Begin);
                            UInt64 indexMiddle = reader.ReadUInt64();
                            if (idNumber == indexMiddle)
                            {
                                return reader.ReadInt64();
                            }
                            else if (idNumber < indexMiddle)
                            {
                                iEnd = iMiddle;
                                indexEnd = indexMiddle;
                            }
                            else
                            {
                                iStart = iMiddle;
                                indexStart = indexMiddle;
                            }
                        }

                        // now iEnd - iStart < 2, but idNumber != indexStart && idNumber != indexEnd, thus idNumber is not found
                        return -1;
                    }
                }
            }
            return -1;
        }

        public static List<(UInt64, Int64)> LoadIndices(string path, UInt64 idxBucket)
        {
            string indexFileName = Path.Combine(path, $"work-index-{idxBucket}.wjf");
            return LoadIndices(indexFileName);
        }

        protected static List<(UInt64, Int64)> LoadIndices(string fileName)
        {
            List<(UInt64, Int64)> indices = new List<(UInt64, Int64)>();
            using (FileStream fs = File.OpenRead(fileName))
            {
                Int64 fileSize = fs.Length;
                Int64 numIndices = fileSize / 16;
                using (BinaryReader br = new BinaryReader(fs))
                {
                    for (Int64 i = 0; i < numIndices; i++)
                    {
                        UInt64 idNumber = br.ReadUInt64();
                        Int64 pos = br.ReadInt64();
                        indices.Add((idNumber, pos));
                    }
                }
            }
            return indices;
        }


    }
}

