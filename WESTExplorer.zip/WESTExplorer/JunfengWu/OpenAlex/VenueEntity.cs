﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using JunfengWu.Configuration;

namespace JunfengWu.OpenAlex
{
    public class VenueEntity: IndexedStorage
    {
        public UInt64 id { get; private set; }
        public string name { get; private set; }

        public VenueEntity(UInt64 idNumber, DataLocation dataLocation)
        {
            string path = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(path, "venue-sorted_index.wjf");
            Int64 venuePos = FindIndex(indexFileName, idNumber);
            if (venuePos >= 0)
            {
                string dataFileName = Path.Combine(path, "venue-data.wjf");
                Deserialize(dataFileName, idNumber, venuePos);
            }
            else
            {
                id = 0;
            }
        }

        public VenueEntity(string fileName, UInt64 idNumber, Int64 venuePos)
        {
            Deserialize(fileName, idNumber, venuePos);
        }

        Byte[] GetNameBytes()
        {
            return Encoding.UTF8.GetBytes(name);
        }

        void Deserialize(string fileName, UInt64 idNumber, Int64 venuePos)
        {
            using (FileStream dataFile = File.OpenRead(fileName))
            {
                dataFile.Seek(venuePos, SeekOrigin.Begin);
                using (BinaryReader dataReader = new BinaryReader(dataFile))
                {
                    id = dataReader.ReadUInt64();
                    Debug.Assert(idNumber == id);

                    UInt16 nameLength = dataReader.ReadUInt16();

                    Byte[] nameBytes = new Byte[nameLength];
                    dataReader.Read(nameBytes);
                    name = Encoding.UTF8.GetString(nameBytes);
                }
            }
        }

        public void Serialize(Int64 venuePos, BinaryWriter dataWriter, BinaryWriter indexWriter)
        {
            indexWriter.Write(id);
            indexWriter.Write(venuePos);

            Byte[] nameBytes = GetNameBytes();
            UInt16 nameLength = Convert.ToUInt16(nameBytes.Length);
            dataWriter.Write(id);
            dataWriter.Write(nameLength);
            dataWriter.Write(nameBytes);
        }

        public static void SortIndices(DataLocation dataLocation)
        {
            string outputPath = dataLocation.Get("openAlexPath");
            string indexFileName = Path.Combine(outputPath, $"venue-index.wjf");
            string sortedIndexFileName = Path.Combine(outputPath, $"venue-sorted_index.wjf");
            List<(UInt64, Int64)> indices = LoadIndices(indexFileName);
            indices.Sort((x, y) => Math.Sign(Convert.ToInt64(x.Item1) - Convert.ToInt64(y.Item1)));
            using (FileStream fileOut = File.Create(sortedIndexFileName))
            {
                using (BinaryWriter indexWriter = new BinaryWriter(fileOut))
                {
                    for (int i = 0; i < indices.Count; i++)
                    {
                        indexWriter.Write(indices[i].Item1);
                        indexWriter.Write(indices[i].Item2);
                    }
                }
            }
        }
    }
}
