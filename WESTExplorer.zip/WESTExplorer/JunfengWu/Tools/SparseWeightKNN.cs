﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace JunfengWu.Tools
{
    public class SparseWeightKNN
    {
        ConcurrentDictionary<uint, Dictionary<long, float>> normalizedWeightVectors = new ConcurrentDictionary<uint, Dictionary<long, float>>();
        ConcurrentDictionary<long, ConcurrentBag<uint>> SparseRows = new ConcurrentDictionary<long, ConcurrentBag<uint>>();
        public SparseWeightKNN(long[] rowIds)
        {
            foreach (long key in rowIds)
            {
                SparseRows[key] = new ConcurrentBag<uint>();
            }
        }
        public SparseWeightKNN(Dictionary<long, int> rowFreqs)
        {
            foreach (long key in rowFreqs.Keys)
            {
                SparseRows[key] = new ConcurrentBag<uint>();
            }
        }
        public SparseWeightKNN(HashSet<long> rows)
        {
            foreach (long key in rows)
            {
                SparseRows[key] = new ConcurrentBag<uint>();
            }
        }
        public void Add(uint id, Dictionary<long, float> weightVector)
        {
            Dictionary<long, float> normalizedWeightVector = new Dictionary<long, float>();
            float sumWeightSqrs = 0f;
            foreach (var kv in weightVector)
            {
                if (kv.Value == 0f)
                    continue;
                Debug.Assert(SparseRows.ContainsKey(kv.Key));
                sumWeightSqrs += kv.Value * kv.Value;
            }
            float r = MathF.Sqrt(sumWeightSqrs);
            float oneOVerR = 1.0f / r;
            foreach (var kv in weightVector)
            {
                normalizedWeightVector[kv.Key] = kv.Value * oneOVerR;
            }
            normalizedWeightVectors[id] = normalizedWeightVector;
            foreach (long rowID in normalizedWeightVector.Keys)
            {
                SparseRows[rowID].Add(id);
            }
        }

        static float ComputeSimilarity(Dictionary<long, float> u, Dictionary<long, float> v)
        {
            float result = 0f;
            if (u.Count < v.Count)
            {
                foreach (var kv in u)
                {
                    float vValue;
                    if (v.TryGetValue(kv.Key, out vValue))
                        result += kv.Value * vValue;
                }
            }
            else
            {
                foreach (var kv in v)
                {
                    float uValue;
                    if (u.TryGetValue(kv.Key, out uValue))
                        result += kv.Value * uValue;
                }
            }
            return result;
        }

        public List<Tuple<uint, float>> KNN(uint id, int k)
        {
            Dictionary<long, float> u = normalizedWeightVectors[id];
            long[] rowIDs = new long[u.Count];
            normalizedWeightVectors[id].Keys.CopyTo(rowIDs, 0);
            List<Tuple<uint, float>> knn = new List<Tuple<uint, float>>();
            float similarityThreshold = 0f;
            float partialSum = 0f;
            HashSet<uint> visited = new HashSet<uint>();
            visited.Add(id);
            var sortedRowIDs = rowIDs.OrderByDescending(t => u[t]);
            foreach (long rowID in sortedRowIDs)
            {
                ConcurrentBag<uint> row = SparseRows[rowID];
                foreach (uint neighborID in row)
                {
                    if (visited.Contains(neighborID))
                        continue;
                    visited.Add(neighborID);
                    Dictionary<long, float> v = normalizedWeightVectors[neighborID];
                    float similarity = ComputeSimilarity(u, v);
                    if (similarity <= similarityThreshold)
                        continue;
                    bool inserted = false;
                    for (int i = 0; i < knn.Count; i++)
                    {
                        if (similarity > knn[i].Item2)
                        {
                            knn.Insert(i, new Tuple<uint, float>(neighborID, similarity));
                            inserted = true;
                            break;
                        }
                    }
                    if (inserted)
                    {
                        if (knn.Count > k)
                        {
                            knn.RemoveAt(k);
                            similarityThreshold = knn[k - 1].Item2;
                        }
                    }
                    else if (knn.Count < k)
                    {
                        knn.Add(new Tuple<uint, float>(neighborID, similarity));
                        if (knn.Count == k)
                            similarityThreshold = similarity;
                    }
                }

                partialSum += u[rowID] * u[rowID];
                if (MathF.Sqrt(1.0f - partialSum) <= similarityThreshold)
                    break;
            }
            if (knn.Count < k)
            {
                HashSet<uint> included = new HashSet<uint>();
                foreach (var kv in knn)
                {
                    included.Add(kv.Item1);
                }
                foreach (uint key in normalizedWeightVectors.Keys)
                {
                    if (included.Contains(key))
                        continue;
                    knn.Add(new Tuple<uint, float>(key, 0.0f));
                    included.Add(key);
                    if (knn.Count >= k)
                        break;
                }
            }
            return knn;
        }

        public int GetNumVectors()
        {
            return normalizedWeightVectors.Count;
        }

        public uint[] GetVectorIDs()
        {
            uint[] ids = new uint[normalizedWeightVectors.Count];
            normalizedWeightVectors.Keys.CopyTo(ids, 0);
            return ids;
        }

        public float GetDistance(uint id1, uint id2)
        {
            Dictionary<long, float> u = normalizedWeightVectors[id1];
            Dictionary<long, float> v = normalizedWeightVectors[id2];
            return 1.0f - ComputeSimilarity(u, v);
        }

        HashSet<uint> GetUnion(Dictionary<long, HashSet<uint>> mySparseRows, HashSet<long> rowSelection)
        {
            HashSet<uint> union = new HashSet<uint>();
            long[] rows = new long[rowSelection.Count];
            rowSelection.CopyTo(rows, 0);
            Parallel.For<HashSet<uint>>(0, rows.Length,
                () => new HashSet<uint>(),
                (rowIndex, loopState, localUnion) =>
                {
                    localUnion.UnionWith(mySparseRows[rows[rowIndex]]);
                    return localUnion;
                },
                localUnion =>
                {
                    lock (union)
                    {
                        union.UnionWith(localUnion);
                    }
                });
            return union;
        }

        public List<Tuple<long, Tuple<int, float>>> Summarize(List<uint> ids)
        {
            HashSet<long> myBitermIDs = new HashSet<long>();
            foreach (uint id in ids)
            {
                Dictionary<long, float> myWeights = normalizedWeightVectors[id];
                foreach (long key in myWeights.Keys)
                {
                    myBitermIDs.Add(key);
                }
            }
            Dictionary<long, HashSet<uint>> mySparseRows = new Dictionary<long, HashSet<uint>>();
            foreach (long bitermID in myBitermIDs)
            {
                ConcurrentBag<uint> bag = SparseRows[bitermID];
                HashSet<uint> intersection = new HashSet<uint>(ids.Intersect(bag));
                if (intersection.Count < 2)
                    continue;
                mySparseRows.Add(bitermID, intersection);
            }

            HashSet<long> rowSelection = new HashSet<long>(mySparseRows.Keys);
            int n = GetUnion(mySparseRows, rowSelection).Count;

            long[] myBitermIDs2 = new long[mySparseRows.Count];
            Dictionary<long, float> mySumWeightProducts = new Dictionary<long, float>();
            mySparseRows.Keys.CopyTo(myBitermIDs2, 0);
            for (int i = 0; i < myBitermIDs2.Length; i++)
            {
                float mySum = 0.0f;
                long bitermID = myBitermIDs2[i];
                HashSet<uint> mySet = mySparseRows[bitermID];
                uint[] idsInMySet = new uint[mySet.Count];
                mySet.CopyTo(idsInMySet);
                for (int j1 = 0; j1 < idsInMySet.Length; j1++)
                {
                    uint id1 = idsInMySet[j1];
                    float w1 = normalizedWeightVectors[id1][bitermID];
                    for (int j2 = j1 + 1; j2 < idsInMySet.Length; j2++)
                    {
                        uint id2 = idsInMySet[j2];
                        float w2 = normalizedWeightVectors[id2][bitermID];
                        mySum += w1 * w2;
                    }
                }
                mySumWeightProducts[bitermID] = mySum;
            }
            Array.Sort(myBitermIDs2, (x, y) => MathF.Sign(mySumWeightProducts[x] - mySumWeightProducts[y]));
            for (int i = 0; i < myBitermIDs2.Length; i++)
            {
                rowSelection.Remove(myBitermIDs2[i]);
                if (GetUnion(mySparseRows, rowSelection).Count < n)
                    rowSelection.Add(myBitermIDs2[i]);
            }

            List<Tuple<long, Tuple<int, float>>> result = new List<Tuple<long, Tuple<int, float>>>();
            for (int i = myBitermIDs2.Length - 1; i >= 0; i--)
            {
                long bitermID = myBitermIDs2[i];
                if (rowSelection.Contains(bitermID))
                    result.Add(new Tuple<long, Tuple<int, float>>(bitermID, new Tuple<int, float>(mySparseRows[bitermID].Count, mySumWeightProducts[bitermID])));
            }
            return result;
        }
    }
}
