﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Text;
using Fastenshtein;

namespace JunfengWu.Tools
{
    public class MyCSO
    {
        List<string> terms = new List<string>();
        List<int> termVocabIDs = new List<int>();
        Dictionary<string, int> termIDs = new Dictionary<string, int>();
        Dictionary<int, int> termIDToTopicID = new Dictionary<int, int>();
        List<HashSet<int>> termIDsOfTopic = new List<HashSet<int>>();
        List<string> topicNames = new List<string>();
        List<HashSet<int>> directSuperTopicIDsofTopic = new List<HashSet<int>>();
        WordEmbeddingVectors wvs;
        List<HashSet<string>> termSynonyms = new List<HashSet<string>>();
        Dictionary<string, string> inexactMatches = new Dictionary<string, string>();

        int GetOrAddTermID(string term, ConcurrentDictionary<string, int> vocabulary)
        {
            string[] words = term.Split(' ');
            string text = "";
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length == 0)
                    continue;
                if (text.Length == 0)
                    text = words[i];
                else
                    text += "_" + words[i];
            }
            int termID;
            bool inTerms = termIDs.TryGetValue(text, out termID);
            if (inTerms)
                return termID;

            termID = terms.Count;
            HashSet<string> synonyms = new HashSet<string>();
            int vocabID;
            bool inVocab = vocabulary.TryGetValue(text, out vocabID);

            if (!inVocab)
            {
                Levenshtein levenshtein = new Levenshtein(text);
                double bestDist = 100000.0;
                string bestKey = "";
                vocabID = -1;
                foreach (KeyValuePair<string, int> kv in vocabulary)
                {
                    double dist = levenshtein.DistanceFrom(kv.Key);
                    if (dist < bestDist)
                    {
                        bestDist = dist;
                        bestKey = kv.Key;
                        vocabID = kv.Value;
                    }
                }
                Debug.Assert(vocabID >= 0);
                //Console.WriteLine("WARNING: inexact match of {0} to {1}", text, bestKey);
                inexactMatches[text] = bestKey;
                text = bestKey;
            }

            terms.Add(text);
            termVocabIDs.Add(vocabID);
            synonyms.Add(text);
            termSynonyms.Add(synonyms);
            termIDs[text] = termID;

            return termID;
        }

        public MyCSO(string csoDataPath, WordEmbeddingVectors wvs, int k, double eps, IProgress<int> progress)
        {
            string csoFileName = Path.Combine(csoDataPath, "cso.txt");
            string csoSynonymsFileName = Path.Combine(csoDataPath, "cso_synonyms.txt");

            this.wvs = wvs;
            ConcurrentDictionary<string, int> vocabulary = wvs.GetVocabulary();
            string[] lines = File.ReadAllLines(csoFileName);
            int numTopics = Convert.ToInt32(lines[0]);
            progress?.Report(0);
            int currProgress = 0;
            for (int i = 0; i < numTopics; i++)
            {
                termIDsOfTopic.Add(new HashSet<int>());
                directSuperTopicIDsofTopic.Add(new HashSet<int>());
            }
            for (int i = 0; i < numTopics; i++)
            {
                string[] terms = lines[i + 1].Split(',');
                string[] superTopics = lines[i + 1 + numTopics].Split(',');
                int topicID = Convert.ToInt32(terms[0]);
                int topicID2 = Convert.ToInt32(superTopics[0]);
                Debug.Assert(i == topicID);
                for (int j = 1; j < terms.Length; j++)
                {
                    int termID = GetOrAddTermID(terms[j], vocabulary);
                    termIDsOfTopic[i].Add(termID);
                    if (j == 1)
                        topicNames.Add(terms[j]);
                }
                for (int j = 1; j < superTopics.Length; j++)
                {
                    int superTopicID = Convert.ToInt32(superTopics[j]);
                    directSuperTopicIDsofTopic[topicID2].Add(superTopicID);
                }
                int newProgress = (i + 1) * 50 / numTopics;
                if (newProgress > currProgress)
                {
                    currProgress = newProgress;
                    progress?.Report(newProgress);
                }
            }

            WVSmallWorld wvSmallWorld = new WVSmallWorld(csoDataPath, wvs);

            for (int i = 0; i < terms.Count; i++)
            {
                string[] knnWords = wvSmallWorld.GetKNNWords(termVocabIDs[i], k, eps);
                for (int j = 0; j < knnWords.Length; j++)
                {
                    termSynonyms[i].Add(knnWords[j]);
                }
                int newProgress = 50 + (i + 1) * 50 / terms.Count;
                if (newProgress > currProgress)
                {
                    currProgress = newProgress;
                    progress?.Report(newProgress);
                }
            }

            for (int idxTopic = 0; idxTopic < numTopics; idxTopic++)
            {
                foreach (int termID in termIDsOfTopic[idxTopic])
                {
                    termIDToTopicID[termID] = idxTopic;
                }
            }
        }

        public List<int> GetTermVocabIDs()
        {
            return termVocabIDs;
        }

        public List<HashSet<string>> GetTermSynonyms()
        {
            return termSynonyms;
        }

        public int GetTopicID(int termID)
        {
            int topicID;
            if (termIDToTopicID.TryGetValue(termID, out topicID))
            {
                return topicID;
            }
            else
            {
                return -1;
            }
        }

        public Dictionary<string, int> GetTopicIDs()
        {
            Dictionary<string, int> topicIDs = new Dictionary<string, int>();
            for (int i = 0; i < topicNames.Count; i++)
            {
                topicIDs[topicNames[i]] = i;
            }
            return topicIDs;
        }

        public string GetTopicName(int topicID)
        {
            return topicNames[topicID];
        }
    }
}
