﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JunfengWu.Tools
{
    public class WeightedLeastSquares
    {
        public static (double, double) FitLine(double[] y)
        {
            int n = y.Length;
            double a = 0, ax = 0, ay = 0, axx = 0, axy = 0;
            for (int i = 0; i < n; i++)
            {
                a += 1;
                ax += i;
                ay += y[i];
                axx += i * i;
                axy += i * y[i];
            }
            double c2 = (ax * ay - a * axy) / (ax * ax - a * axx);
            double c1 = (ay - ax * c2) / a;
            return (c1, c2);
        }

        public static (double, double) FitLine(double[] x, double[] y, double[] w)
        {
            Debug.Assert(x.Length == y.Length);
            Debug.Assert(y.Length == w.Length);
            Debug.Assert(x.Length > 0);
            int n = x.Length;
            double a = 0, ax = 0, ay = 0, axx = 0, axy = 0;
            for (int i = 0; i < n; i++)
            {
                a += w[i];
                ax += w[i] * x[i];
                ay += w[i] * y[i];
                axx += w[i] * x[i] * x[i];
                axy += w[i] * x[i] * y[i];
            }
            double c2 = (ax * ay - a * axy) / (ax * ax - a * axx);
            double c1 = (ay - ax * c2) / a;
            return (c1, c2);
        }

        public static (double, double) FitLine(double[] x, double[] y, int decayStart, double decay)
        {
            double[] w = new double[x.Length];
            double currW = 1.0;
            for (int i = 0; i < x.Length; i++)
            {
                if (i >= decayStart)
                    currW *= decay;
                w[i] = currW;
            }
            return FitLine(x, y, w);
        }
    }
}
