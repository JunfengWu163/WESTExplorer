﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using HNSW.Net;

namespace JunfengWu.Tools
{
    public class WVSmallWorld
    {
        WordEmbeddingVectors wvs;
        List<float[]> wordVectors;
        SmallWorld<float[], float> graph;

        public WVSmallWorld(string csoDataPath, WordEmbeddingVectors wvs)
        {
            this.wvs = wvs;
            wordVectors = wvs.GetWordVectors();

            string fileName = Path.Combine(csoDataPath, "w2v.graph");
            FileStream fstreamGraph = new FileStream(fileName, FileMode.Open);
            graph = SmallWorld<float[], float>.DeserializeGraph(wordVectors, CosineDistance.SIMD, new Randomizer(), fstreamGraph);
            fstreamGraph.Close();
        }

        public List<int> GetKNN(int i, int k, double eps)
        {
            var bestK = graph.KNNSearch(wordVectors[i], k);
            List<int> result = new List<int>();
            for (int j = 0; j < bestK.Count; j++)
            {
                if (bestK[j].Distance < eps)
                {
                    result.Add(bestK[j].Id);
                }
            }
            return result;
        }

        public string[] GetKNNWords(int i, int k, double eps)
        {
            List<int> knnIDs = GetKNN(i, k, eps);
            string[] result = new string[knnIDs.Count];
            for (int j = 0; j < knnIDs.Count; j++)
            {
                result[j] = wvs.GetWord(knnIDs[j]);
            }
            return result;
        }
    }
}


