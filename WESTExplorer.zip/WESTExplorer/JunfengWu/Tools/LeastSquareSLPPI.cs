﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics.Optimization;

namespace JunfengWu.Tools
{
    public class LeastSquareSLPPI:IObjectiveFunction
    {
        public ushort targetFromYear { get; private set; }
        public ushort targetToYear { get; private set; }
        int[] ys;
        public double y0 { get; private set; } = 1.0;
        public double a0 { get; private set; } = 0.0;
        public double a1 { get; private set; } = 0.0;
        public double peakRatio { get; private set; }
        public double peakRecency { get; private set; }

        public double objective { get; private set; } = 0.0;

        Vector<double> point
        {
            get
            {
                DenseVector point = new DenseVector(3);
                point[0] = a0;
                point[1] = a1;
                point[2] = y0;
                return point;
            }
        }
        Vector<double> IObjectiveFunctionEvaluation.Point => point;

        double IObjectiveFunctionEvaluation.Value => objective;

        bool IObjectiveFunctionEvaluation.IsGradientSupported => true;

        Vector<double> IObjectiveFunctionEvaluation.Gradient
        {
            get
            {
                DenseVector gradient = new DenseVector(3);
                Vector<double> point = this.point;
                gradient[0] = Da0Objective(point);
                gradient[1] = Da1Objective(point);
                gradient[2] = Dy0Objective(point);
                return gradient;
            }
        }

        bool IObjectiveFunctionEvaluation.IsHessianSupported => false;

        Matrix<double> IObjectiveFunctionEvaluation.Hessian => throw new NotImplementedException();

        void Init(ushort targetFromYear, ushort targetToYear, int[] ys)
        {
            Debug.Assert(targetFromYear < targetToYear);
            int numYears = targetToYear - targetFromYear + 1;
            Debug.Assert(ys.Length == numYears);
            this.targetFromYear = targetFromYear;
            this.targetToYear = targetToYear;
            this.ys = new int[numYears];
            for (int i = 0; i < numYears; i++)
            {
                this.ys[i] = ys[i];
            }

            int largestY = 0;
            int iOfLargestY = 0;
            for (int i = 0; i < numYears; i++)
            {
                if (ys[i] >= largestY)
                {
                    largestY = ys[i];
                    iOfLargestY = i;
                }
            }


            if (largestY > 0)
                peakRatio = Convert.ToDouble(ys[numYears - 1]) / Convert.ToDouble(largestY);
            else
                peakRatio = 0.0;

            peakRecency = Convert.ToDouble(iOfLargestY) / Convert.ToDouble(numYears - 1);
            
            objective = Objective(point);
        }

        public LeastSquareSLPPI(ushort targetFromYear, ushort targetToYear, int[] ys)
        {
            Init(targetFromYear, targetToYear, ys);
        }

        public LeastSquareSLPPI(ushort targetFromYear, ushort targetToYear, Dictionary<ushort, int> topicHits)
        {
            int[] topicHits2 = new int[targetToYear - targetFromYear + 1];
            for (ushort year = targetFromYear; year <= targetToYear; year++)
            {
                int hit;
                if (topicHits.TryGetValue(year, out hit))
                {
                    topicHits2[year - targetFromYear] = hit;
                }
                else
                {
                    topicHits2[year - targetFromYear] = 0;
                }
            }
            Init(targetFromYear, targetToYear, topicHits2);
        }

        public double EstimateSlope()
        {
            double[] pis = GetPIs();
            return WeightedLeastSquares.FitLine(pis).Item2;
        }

        public double OriginalSlope()
        {
            double[] ys2 = new double[ys.Length];
            for (int i = 0; i < ys.Length; i++)
            {
                ys2[i] = ys[i];
            }
            return WeightedLeastSquares.FitLine(ys2).Item2;
        }

        public double[] GetPIs()
        {
            double[] pis = new double[ys.Length - 1];
            for (int i = 0; i < pis.Length; i++)
            {
                pis[i] = (ys[i + 1] - ys[i] + 0.001) / (ys[i] + 0.001);
            }
            return pis;
        }

        public double[] GetApproximatePIs(double[] pis)
        {
            (double a, double b) = WeightedLeastSquares.FitLine(pis);
            double[] approxPis = new double[pis.Length];
            for (int i = 0; i < pis.Length; i++)
            {
                approxPis[i] = a + i * b;
            }
            return approxPis;
        }

        void ScaleCurveForBestFit(double[] curve)
        {
            Debug.Assert(curve.Length == ys.Length);
            double sumOfCurve = 0.0, sumOfY = 0.0;
            for (int i = 0; i < ys.Length; i++)
            {
                sumOfCurve += curve[i];
                sumOfY += ys[i];
            }
            double scale;
            if (sumOfCurve != 0)
            {
                scale = sumOfY / sumOfCurve;
            }
            else
            {
                scale = 0.0;
            }
            for (int i = 0; i < ys.Length; i++)
            {
                curve[i] *= scale;
            }
        }

        public double[] EstimateCurveFit()
        {
            double[] pis = GetPIs();
            double[] approxPis = GetApproximatePIs(pis);
            double firstApproxPi = approxPis[0];
            double lastApproxPi = approxPis[approxPis.Length - 1];
            double[] approxCurve = new double[approxPis.Length + 1];
            if (firstApproxPi < lastApproxPi)
            {
                if (lastApproxPi > -1)
                {
                    approxCurve[approxCurve.Length - 1] = 1.0;
                    for (int i = pis.Length - 1; i >= 0; i--)
                    {
                        double approxPi = approxPis[i];

                        // (approxCurve[i + 1] - approxCurve[i]) / approxCurve[i] = approxPi
                        if (approxPi > -1)
                        {
                            approxCurve[i] = approxCurve[i + 1] / (1.0 + approxPi);
                        }
                        else
                        {
                            approxCurve[i] = 0.0;
                        }
                    }
                    ScaleCurveForBestFit(approxCurve);
                }
                else
                {
                    for (int i = 0; i < approxCurve.Length; i++)
                    {
                        approxCurve[i] = 0.0;
                    }
                }
            }
            else
            {
                if (firstApproxPi > -1)
                {
                    approxCurve[0] = 1.0;
                    for (int i = 0; i < pis.Length; i++)
                    {
                        double approxPi = approxPis[i];

                        // (approxCurve[i + 1] - approxCurve[i]) / approxCurve[i] = approxPi
                        if (approxPi > -1)
                        {
                            approxCurve[i + 1] = approxCurve[i] * (1.0 + approxPi);
                        }
                        else
                        {
                            approxCurve[i + 1] = 0;
                        }
                    }
                    ScaleCurveForBestFit(approxCurve);
                }
                else
                {
                    for (int i = 0; i < approxCurve.Length; i++)
                    {
                        approxCurve[i] = 0.0;
                    }
                }
            }
            return approxCurve;
        }

        double G(int i, Vector<double> point)
        {
            double value = 1.0;
            for (int j = 1; j <= i; j++)
            {
                value *= 1.0 + point[0] + (j - 1.0) * point[1];
            }
            return value;
        }

        double Da0G(int i, Vector<double> point)
        {
            double multiplier = 0.0;
            for (int j = 1; j <= i; j++)
            {
                multiplier += 1.0 / (1.0 + point[0] + (j - 1.0) * point[1]);
            }
            return multiplier * G(i, point);
        }

        double Da1G(int i, Vector<double> point)
        {
            double multiplier = 0.0;
            for (int j = 1; j <= i; j++)
            {
                multiplier += (j - 1.0) / (1.0 + point[0] + (j - 1.0) * point[1]);
            }
            return multiplier * G(i, point);
        }

        double Objective(Vector<double> point)
        {
            double value = 0.0;
            for (int i = 0; i < ys.Length; i++)
            {
                double g = G(i, point);
                double diffI = point[2] * g - ys[i];
                value += diffI * diffI;
            }
            return value;
        }

        double Dy0Objective(Vector<double> point)
        {
            double value = 0.0;
            for (int i = 0; i < ys.Length; i++)
            {
                double g = G(i, point);
                double diffI = point[2] * g - ys[i];
                value += diffI * g;
            }
            return value;
        }

        double Da0Objective(Vector<double> point)
        {
            double value = 0.0;
            for (int i = 0; i < ys.Length; i++)
            {
                double g = G(i, point);
                double diffI = point[2] * g - ys[i];
                value += diffI * point[2] * Da0G(i, point);
            }
            return value;
        }

        double Da1Objective(Vector<double> point)
        {
            double value = 0.0;
            for (int i = 0; i < ys.Length; i++)
            {
                double g = G(i, point);
                double diffI = point[2] * g - ys[i];
                value += diffI * point[2] * Da1G(i, point);
            }
            return value;
        }

        public void Optimize()
        {
            BfgsBMinimizer bfgsBMinimizer = new BfgsBMinimizer(1e-12, 1e-12, 1e-12);
            DenseVector lowerBounds = new DenseVector(3);
            lowerBounds[0] = -0.5;
            lowerBounds[1] = -0.5 / ys.Length;
            lowerBounds[2] = 0;
            DenseVector upperBounds = new DenseVector(3);
            upperBounds[0] = 1000;
            upperBounds[1] = 1000;
            upperBounds[2] = 1000;
            try
            {
                var result = bfgsBMinimizer.FindMinimum(this, lowerBounds, upperBounds, point);
                var minimizingPoint = result.MinimizingPoint;
                a0 = minimizingPoint[0];
                a1 = minimizingPoint[1];
                y0 = minimizingPoint[2];
                objective = Objective(minimizingPoint);
            }
            catch
            {

            }
        }

        public double[] GetApproximation()
        {
            double[] result = new double[ys.Length];
            Vector<double> point = this.point;
            for (int i = 0; i < ys.Length; i++)
            {
                result[i] = G(i, point) * y0;
            }
            return result;
        }

        public double CosSim()
        {
            double[] approx = GetApproximation();
            double r12 = 0, r11 = 0, r22 = 0;
            for (int i = 0; i < ys.Length; i++)
            {
                r12 += ys[i] * approx[i];
                r11 += ys[i] * ys[i];
                r22 += approx[i] * approx[i];
            }
            if (r11 > 0 && r22 > 0)
            {
                return r12 / Math.Sqrt(r11 * r22);
            }
            else
            {
                return 0.5;
            }
        }

        void IObjectiveFunction.EvaluateAt(Vector<double> point)
        {
            this.a0 = point[0];
            this.a1 = point[1];
            this.y0 = point[2];
            this.objective = Objective(point);
        }

        IObjectiveFunction IObjectiveFunction.Fork()
        {
            LeastSquareSLPPI another = new LeastSquareSLPPI(targetFromYear, targetToYear, ys);
            another.a0 = a0;
            another.a1 = a1;
            another.y0 = y0;
            another.objective = objective;
            return another;
        }

        IObjectiveFunction IObjectiveFunctionEvaluation.CreateNew()
        {
            LeastSquareSLPPI another = new LeastSquareSLPPI(targetFromYear, targetToYear, ys);
            return another;
        }
    }
}
