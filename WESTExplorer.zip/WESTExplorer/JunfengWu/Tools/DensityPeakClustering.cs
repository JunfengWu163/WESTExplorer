﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Linq;

namespace JunfengWu.Tools
{
    class DensityPeakClustering
    {
        public class DPCNode
        {
            protected int index;
            float density;
            float distToParent;
            DPCNode[] children;
            DPCNode parent;
            public int getIndex()
            {
                return index;
            }

            public float getDensity()
            {
                return density;
            }

            public float getDistToParent()
            {
                return distToParent;
            }

            public int getNumChildren()
            {
                if (children == null)
                {
                    return 0;
                }
                return children.Length;
            }

            public bool hasParent()
            {
                return parent != null;
            }

            public DPCNode getChild(int i)
            {
                return children[i];
            }

            public DPCNode getParent()
            {
                return parent;
            }

            public DPCNode(int index, float density, float distToParent)
            {
                this.index = index;
                this.density = density;
                this.distToParent = distToParent;
            }

            public DPCNode(int index, float density, float distToParent, DPCNode parent)
            {
                this.index = index;
                this.density = density;
                this.distToParent = distToParent;
                this.parent = parent;
                List<DPCNode> siblings = parent.children == null ? new List<DPCNode>() : new List<DPCNode>(parent.children);
                siblings.Add(this);
                parent.children = siblings.ToArray();
            }

        }

        int m;
        float[,] distMatrix;
        List<uint> swknnIDs;
        ConcurrentDictionary<uint, int> swknnIDtoIndex;
        protected int[] clusterIDs;
        List<Tuple<long, Tuple<int, float>>>[] summaries;
        protected float[] densities;
        protected List<DPCNode> forest;

        private void markClusterID(int[] clusterIDs, int clusterID, DPCNode node)
        {
            clusterIDs[node.getIndex()] = clusterID;
            int k = node.getNumChildren();
            for (int i = 0; i < k; i++)
            {
                markClusterID(clusterIDs, clusterID, node.getChild(i));
            }
        }

        private void RecordKnnId(HashSet<uint> myKnnId, DPCNode node)
        {
            myKnnId.Add(swknnIDs[node.getIndex()]);
            int k = node.getNumChildren();
            for (int i = 0; i < k; i++)
            {
                RecordKnnId(myKnnId, node.getChild(i));
            }
        }

        private void getDensities(float[] densities, DPCNode node)
        {
            densities[node.getIndex()] = node.getDensity();
            int k = node.getNumChildren();
            for (int i = 0; i < k; i++)
            {
                getDensities(densities, node.getChild(i));
            }
        }

        int GetTreeSize(DPCNode root)
        {
            if (root == null)
                return 0;
            int result = 1;
            int k = root.getNumChildren();
            for (int i = 0; i < k; i++)
            {
                result += GetTreeSize(root.getChild(i));
            }
            return result;
        }

        // Entropy-based Cluster Quality measure
        float ClusterQuality(List<DPCNode> roots)
        {
            int[] treeSizes = new int[roots.Count];
            int totalNonsingleSize = 0;
            for (int i = 0; i < roots.Count; i++)
            {
                treeSizes[i] = GetTreeSize(roots[i]);
                if (treeSizes[i] > 1)
                    totalNonsingleSize += treeSizes[i];
            }
            float result = 0.0f;
            for (int i = 0; i < roots.Count; i++)
            {
                if (treeSizes[i] > 1)
                {
                    float q = totalNonsingleSize / treeSizes[i];
                    result += q * MathF.Log(q);
                }
            }
            return result;
        }

        float ComputeDensity(CosineKNN cosineKNN, int[] cardinalities, int i, int k)
        {
            float actualK = cardinalities[i];
            float sumDSqr = 0.0f;
            for (int j = 0; j < k; j++)
            {
                // Item1 of neighbor is neighbor ID, Item2 is distance
                var neighbor = cosineKNN.knns[i, j];
                if (neighbor.Item2 == 1.0)
                    break;
                actualK += cardinalities[neighbor.Item1];
                sumDSqr += cardinalities[neighbor.Item1] * neighbor.Item2 * neighbor.Item2;

            }
            return MathF.Exp(-sumDSqr / actualK);
        }
        float ComputeDensity(float[,] distMatrix, int[] vectorIDs, int[] cardinalities, int i, int k)
        {
            if (m < k)
            {
                float actualK = cardinalities[i];
                float sumDSqr = 0.0f;
                for (int j = 0; j < m; j++)
                {
                    if (j == i)
                        continue;
                    actualK += cardinalities[j];
                    sumDSqr += cardinalities[j] * distMatrix[i, j] * distMatrix[i, j];
                }
                return MathF.Exp(-sumDSqr / actualK);
            }
            else
            {
                int[] neighbors = new int[m];
                for (int j = 0; j < m; j++)
                    neighbors[j] = j;
                var sortedNeighbors = neighbors.OrderBy(t => distMatrix[i, t]);
                int numNeighborsProcessed = 0;
                float actualK = cardinalities[i];
                float sumDSqr = 0.0f;
                foreach (int neighbor in sortedNeighbors)
                {
                    if (neighbor != i)
                    {
                        actualK += cardinalities[neighbor];
                        sumDSqr += cardinalities[neighbor] * distMatrix[i, neighbor] * distMatrix[i, neighbor];
                    }
                    numNeighborsProcessed++;
                    if (numNeighborsProcessed >= k)
                        break;
                }
                return MathF.Exp(-sumDSqr / actualK);
            }
        }

        float ComputeDensity(SparseWeightKNN swknn, uint id, int k)
        {
            var knn = swknn.KNN(id, k);
            float actualK = 1.0f;
            float sumDSqr = 0.0f;
            for (int j = 0; j < knn.Count; j++)
            {
                if (knn[j].Item1 == id)
                    continue;
                actualK++;
                float dist = 1.0f - knn[j].Item2;
                sumDSqr += dist * dist;
            }
            return MathF.Exp(-sumDSqr / actualK);
        }

        public DensityPeakClustering(Func<int, int, float> distFun, int[] vectorIDs, int[] cardinalities, int k, float eps)
        {
            m = vectorIDs.Length;
            if (m == 0)
                return;
            distMatrix = new float[m, m];
            for (int i = 0; i < m; i++)
            {
                distMatrix[i, i] = 0f;
                for (int j = i + 1; j < m; j++)
                {
                    float dist = distFun(vectorIDs[i], vectorIDs[j]);
                    distMatrix[i, j] = dist;
                    distMatrix[j, i] = dist;
                }
            }

            densities = new float[m];
            int[] indices = new int[m];
            float[] hdDists = new float[m];
            int[] hdNeighbors = new int[m];
            const float r = 1e30f;

            for (int i = 0; i < m; i++)
            {
                densities[i] = ComputeDensity(distMatrix, vectorIDs, cardinalities, i, k);
                indices[i] = i;
                hdDists[i] = r;
            }

            var sortedIndices = indices.OrderByDescending(t => densities[t]);
            int[] densityRanks = new int[m];
            int offset = 0;
            foreach (var index in sortedIndices)
            {
                densityRanks[offset++] = index;
            }

            hdNeighbors[densityRanks[0]] = densityRanks[0];
            for (int i = 1; i < m; i++)
            {
                int indexI = densityRanks[i];
                float minHDDist = distFun(vectorIDs[indexI], vectorIDs[densityRanks[0]]); ;
                int hdNeighbor = densityRanks[0];
                for (int j = 1; j < i; j++)
                {
                    int indexJ = densityRanks[j];
                    if (densities[indexJ] == densities[indexI])
                    {
                        break;
                    }
                    float dist = distMatrix[indexI, indexJ];
                    if (dist < minHDDist)
                    {
                        minHDDist = dist;
                        hdNeighbor = indexJ;
                    }
                }
                hdDists[indexI] = minHDDist;
                hdNeighbors[indexI] = hdNeighbor;
            }

            float bestQuality = -1f;
            forest = new List<DPCNode>();
            for (float threshold = eps; threshold < 1f; threshold++)
            {
                List<DPCNode> roots = new List<DPCNode>();
                Dictionary<int, DPCNode> indexToNode = new Dictionary<int, DPCNode>();
                int index0 = densityRanks[0];
                indexToNode[index0] = new DPCNode(index0, densities[index0], hdDists[index0]);
                roots.Add(indexToNode[index0]);
                for (int i = 1; i < m; i++)
                {
                    int indexI = densityRanks[i];
                    if (hdDists[indexI] <= threshold)
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI], indexToNode[hdNeighbors[indexI]]);
                        indexToNode[indexI] = node;
                    }
                    else
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI]);
                        roots.Add(node);
                        indexToNode[indexI] = node;
                    }
                }
                float quality = ClusterQuality(roots);
                if (quality > bestQuality)
                {
                    forest = roots;
                    bestQuality = quality;
                }
            }

            clusterIDs = new int[m];
            for (int clusterID = 0; clusterID < forest.Count; clusterID++)
            {
                markClusterID(clusterIDs, clusterID, forest[clusterID]);
            }
        }

        public DensityPeakClustering(SparseWeightKNN swknn, List<uint> paperIDs, ConcurrentDictionary<uint, int> paperIndices, int k, float eps, IProgress<int> progressDensity, IProgress<int> progressHDNeighbor, IProgress<int> progressTree)
        {
            swknnIDs = paperIDs;
            swknnIDtoIndex = paperIndices;
            m = swknnIDs.Count;
            if (m == 0)
                return;

            densities = new float[m];
            int[] indices = new int[m];
            float[] hdDists = new float[m];
            int[] hdNeighbors = new int[m];
            const float r = 1e30f;
            if (progressDensity != null)
            {
                for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                {
                    int i0 = idxBatch * m / 100;
                    int i1 = (idxBatch + 1) * m / 100;
                    Parallel.For(i0, i1, i =>
                    {
                        densities[i] = ComputeDensity(swknn, swknnIDs[i], k);
                        indices[i] = i;
                        hdDists[i] = r;
                    });
                    if (progressDensity != null)
                        progressDensity.Report(1 + idxBatch);
                }
            }
            else
            {
                Parallel.For(0, m, i =>
                {
                    densities[i] = ComputeDensity(swknn, swknnIDs[i], k);
                    swknnIDtoIndex[swknnIDs[i]] = i;
                    indices[i] = i;
                    hdDists[i] = r;
                });
            }

            var sortedIndices = indices.AsParallel().OrderByDescending(t => densities[t]);
            int[] densityRanks = new int[m];
            int offset = 0;
            foreach (var index in sortedIndices)
            {
                densityRanks[offset++] = index;
            }

            hdNeighbors[densityRanks[0]] = densityRanks[0];
            if (progressHDNeighbor != null)
            {
                for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                {
                    int i0 = 1 + idxBatch * (m - 1) / 100;
                    int i1 = 1 + (idxBatch + 1) * (m - 1) / 100;
                    Parallel.For(i0, i1, i =>
                    {
                        int indexI = densityRanks[i];
                        float minHDDist = swknn.GetDistance(swknnIDs[indexI], swknnIDs[densityRanks[0]]); ;
                        int hdNeighbor = densityRanks[0];
                        bool hdNeighborFound = false;
                        // search knn first
                        var knn = swknn.KNN(swknnIDs[indexI], k);
                        foreach (var neighbor in knn)
                        {
                            int indexJ = swknnIDtoIndex[neighbor.Item1];
                            float dist = 1.0f - neighbor.Item2;
                            if (densities[indexJ] > densities[indexI] && dist < minHDDist)
                            {
                                minHDDist = dist;
                                hdNeighbor = indexJ;
                                hdNeighborFound = true;
                            }
                        }
                        if (!hdNeighborFound)
                        {
                            for (int j = 1; j < i; j++)
                            {
                                int indexJ = densityRanks[j];
                                if (densities[indexJ] == densities[indexI])
                                {
                                    break;
                                }
                                float dist = swknn.GetDistance(swknnIDs[indexI], swknnIDs[indexJ]);
                                if (dist < minHDDist)
                                {
                                    minHDDist = dist;
                                    hdNeighbor = indexJ;
                                }
                            }
                        }
                        hdDists[indexI] = minHDDist;
                        hdNeighbors[indexI] = hdNeighbor;
                    });
                    progressHDNeighbor.Report(1 + idxBatch);
                }
            }
            else
            {
                Parallel.For(1, m, i =>
                {
                    int indexI = densityRanks[i];
                    float minHDDist = swknn.GetDistance(swknnIDs[indexI], swknnIDs[densityRanks[0]]); ;
                    int hdNeighbor = densityRanks[0];
                    bool hdNeighborFound = false;
                    // search knn first
                    var knn = swknn.KNN(swknnIDs[indexI], k);
                    foreach (var neighbor in knn)
                    {
                        int indexJ = swknnIDtoIndex[neighbor.Item1];
                        float dist = 1.0f - neighbor.Item2;
                        if (densities[indexJ] > densities[indexI] && dist < minHDDist)
                        {
                            minHDDist = dist;
                            hdNeighbor = indexJ;
                            hdNeighborFound = true;
                        }
                    }
                    if (!hdNeighborFound)
                    {
                        for (int j = 1; j < i; j++)
                        {
                            int indexJ = densityRanks[j];
                            if (densities[indexJ] == densities[indexI])
                            {
                                break;
                            }
                            float dist = swknn.GetDistance(swknnIDs[indexI], swknnIDs[indexJ]);
                            if (dist < minHDDist)
                            {
                                minHDDist = dist;
                                hdNeighbor = indexJ;
                            }
                        }
                    }
                    hdDists[indexI] = minHDDist;
                    hdNeighbors[indexI] = hdNeighbor;
                });
            }

            float bestQuality = -1f;
            forest = new List<DPCNode>();
            for (float threshold = eps; threshold < 1f; threshold += eps)
            {
                List<DPCNode> roots = new List<DPCNode>();
                Dictionary<int, DPCNode> indexToNode = new Dictionary<int, DPCNode>();
                int index0 = densityRanks[0];
                indexToNode[index0] = new DPCNode(index0, densities[index0], hdDists[index0]);
                roots.Add(indexToNode[index0]);
                for (int i = 1; i < m; i++)
                {
                    int indexI = densityRanks[i];
                    if (hdDists[indexI] <= threshold)
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI], indexToNode[hdNeighbors[indexI]]);
                        indexToNode[indexI] = node;
                    }
                    else
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI]);
                        roots.Add(node);
                        indexToNode[indexI] = node;
                    }
                }
                float quality = ClusterQuality(roots);
                if (quality > bestQuality)
                {
                    forest = roots;
                    bestQuality = quality;
                }
                if (progressTree != null)
                {
                    int treeProgress = (int)MathF.Round(MathF.Min(threshold + eps, 1f) * 100);
                    progressTree.Report(treeProgress);
                }
            }

            clusterIDs = new int[m];
            summaries = new List<Tuple<long, Tuple<int, float>>>[forest.Count];
            Parallel.For(0, forest.Count, clusterID =>
            {
                markClusterID(clusterIDs, clusterID, forest[clusterID]);
                summaries[clusterID] = Summarize(swknn, clusterID);
            });
        }

        public DensityPeakClustering(CosineKNN cosKnn, int[] cardinalities, int k, float eps, IProgress<int> progressKNN, IProgress<int> progressDensity, IProgress<int> progressHDNeighbor, IProgress<int> progressTree)
        {
            m = cosKnn.GetNumData();
            if (m == 0)
                return;

            densities = new float[m];
            int[] indices = new int[m];
            float[] hdDists = new float[m];
            int[] hdNeighbors = new int[m];
            const float r = 1e30f;
            if (progressDensity != null)
            {
                for (int idxBatch = 0; idxBatch < 100; idxBatch++)
                {
                    int i0 = idxBatch * m / 100;
                    int i1 = (idxBatch + 1) * m / 100;
                    Parallel.For(i0, i1, i =>
                    {
                        densities[i] = ComputeDensity(cosKnn, cardinalities, i, k);
                        indices[i] = i;
                        hdDists[i] = r;
                    });
                    if (progressDensity != null)
                        progressDensity.Report(1 + idxBatch);
                }
            }
            else
            {
                Parallel.For(0, m, i =>
                {
                    densities[i] = ComputeDensity(cosKnn, cardinalities, i, k);
                    indices[i] = i;
                    hdDists[i] = r;
                });
            }

            var sortedIndices = indices.AsParallel().OrderByDescending(t => densities[t]);
            int[] densityRanks = new int[m];
            int offset = 0;
            foreach (var index in sortedIndices)
            {
                densityRanks[offset++] = index;
            }

            // find hdNeighbors
            hdNeighbors[densityRanks[0]] = densityRanks[0];
            int numBatches = Math.Min(1 + (m - 1) / 4, 100);
            for (int idxBatch = 0; idxBatch < numBatches; idxBatch++)
            {
                int i0 = 1 + idxBatch * (m - 1) / 100;
                int i1 = 1 + (idxBatch + 1) * (m - 1) / 100;
                Parallel.For(i0, i1, i =>
                {
                    int indexI = densityRanks[i];
                    float minHDDist = (float)cosKnn.ComputeDistance((uint)indexI, (uint)densityRanks[0]);
                    int hdNeighbor = densityRanks[0];
                    bool hdNeighborFound = false;
                    // search knn first
                    for (int idxNeighbor = 0; idxNeighbor < k; idxNeighbor++)
                    {
                        var neighbor = cosKnn.knns[indexI, idxNeighbor];
                        if (neighbor.Item1 == uint.MaxValue)
                            break;
                        if (densities[neighbor.Item1] > densities[indexI] && neighbor.Item2 < minHDDist)
                        {
                            minHDDist = neighbor.Item2;
                            hdNeighbor = (int)neighbor.Item1;
                            hdNeighborFound = true;
                        }
                    }
                    if (!hdNeighborFound)
                    {
                        for (int j = 1; j < i; j++)
                        {
                            int indexJ = densityRanks[j];
                            if (densities[indexJ] == densities[indexI])
                            {
                                break;
                            }
                            float dist = (float)cosKnn.ComputeDistance((uint)indexI, (uint)indexJ);
                            if (dist < minHDDist)
                            {
                                minHDDist = dist;
                                hdNeighbor = indexJ;
                            }
                        }
                    }
                    hdDists[indexI] = minHDDist;
                    hdNeighbors[indexI] = hdNeighbor;
                });
                progressHDNeighbor?.Report((1 + idxBatch) * 100 / numBatches);
            }

            // find best quality clusters
            float bestQuality = -1f;
            forest = new List<DPCNode>();
            for (float threshold = eps; threshold < 1f; threshold += eps)
            {
                List<DPCNode> roots = new List<DPCNode>();
                Dictionary<int, DPCNode> indexToNode = new Dictionary<int, DPCNode>();
                int index0 = densityRanks[0];
                indexToNode[index0] = new DPCNode(index0, densities[index0], hdDists[index0]);
                roots.Add(indexToNode[index0]);
                for (int i = 1; i < m; i++)
                {
                    int indexI = densityRanks[i];
                    if (hdDists[indexI] <= threshold)
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI], indexToNode[hdNeighbors[indexI]]);
                        indexToNode[indexI] = node;
                    }
                    else
                    {
                        DPCNode node = new DPCNode(indexI, densities[indexI], hdDists[indexI]);
                        roots.Add(node);
                        indexToNode[indexI] = node;
                    }
                }
                float quality = ClusterQuality(roots);
                if (quality > bestQuality)
                {
                    forest = roots;
                    bestQuality = quality;
                }
                if (progressTree != null)
                {
                    int treeProgress = (int)MathF.Round(MathF.Min(threshold + eps, 1f) * 50);
                    progressTree.Report(treeProgress);
                }
            }

            clusterIDs = new int[m];
            List<int> processedClusterIDs = new List<int>();
            Parallel.For(0, forest.Count, clusterID =>
            {
                markClusterID(clusterIDs, clusterID, forest[clusterID]);
                lock(processedClusterIDs)
                {
                    processedClusterIDs.Add(clusterID);
                    int treeProgress = 50 + 50 * processedClusterIDs.Count / forest.Count;
                    progressTree?.Report(treeProgress);
                }
            });
        }

        public int GetClusterID(int i)
        {
            return clusterIDs[i];
        }

        public float GetDensity(int i)
        {
            return densities[i];
        }

        public DPCNode GetClusterTree(int clusterID)
        {
            return forest[clusterID];
        }

        public int GetNumClusters()
        {
            if (m == 0)
                return 0;
            return forest.Count;
        }

        public int GetNumData()
        {
            if (m == 0)
                return 0;
            return clusterIDs.Length;
        }

        public int GetSWKNNClusterID(uint id)
        {
            return clusterIDs[swknnIDtoIndex[id]];
        }

        public ConcurrentDictionary<int, Tuple<int, float>> GetDescriptorsForLargestClusters(int numDescriptors, CosineKNN knn, int[] cardinalities)
        {
            if (m == 0)
            {
                return new ConcurrentDictionary<int, Tuple<int, float>>();
            }
            int[] clusterSize = new int[GetNumClusters()];
            int[] clusterRank = new int[GetNumClusters()];
            for (int i = 0; i < clusterSize.Length; i++)
            {
                clusterSize[i] = 0;
                clusterRank[i] = i;
            }
            for (int i = 0; i < clusterIDs.Length; i++)
            {
                clusterSize[clusterIDs[i]] += cardinalities[i];
            }
            Array.Sort(clusterRank, (x, y) =>
            {
                if (clusterSize[x] > clusterSize[y])
                    return -1;
                else if (clusterSize[x] == clusterSize[y])
                    return 0;
                else
                    return 1;
            });

            ConcurrentDictionary<int, Tuple<int, float>> descriptors = new ConcurrentDictionary<int, Tuple<int, float>>();
            int myNumDescriptor = Math.Min(numDescriptors, GetNumClusters());
            if (distMatrix != null)
            {
                for (int iDesc = 0; iDesc < myNumDescriptor; iDesc++)
                {
                    int index = forest[clusterRank[iDesc]].getIndex();
                    Dictionary<float, int> dictDistIns = new Dictionary<float, int>();
                    Dictionary<float, int> dictDistOuts = new Dictionary<float, int>();
                    for (int i = 0; i < m; i++)
                    {
                        float dist = (float)knn.ComputeDistance((uint)i, (uint)index);
                        if (GetClusterID(i) == clusterRank[iDesc])
                        {
                            if (dictDistIns.ContainsKey(dist))
                            {
                                dictDistIns[dist] += cardinalities[i];
                            }
                            else
                            {
                                dictDistIns[dist] = cardinalities[i];
                            }
                        }
                        else
                        {
                            if (dictDistOuts.ContainsKey(dist))
                            {
                                dictDistOuts[dist] += cardinalities[i];
                            }
                            else
                            {
                                dictDistOuts[dist] = cardinalities[i];
                            }
                        }
                    }
                    List<float> distIns = new List<float>();
                    List<float> distOuts = new List<float>();
                    foreach (float dist in dictDistIns.Keys)
                    {
                        distIns.Add(dist);
                    }
                    foreach (float dist in dictDistOuts.Keys)
                    {
                        distOuts.Add(dist);
                    }

                    distIns.Sort();
                    distOuts.Sort();
                    if (distOuts.Count == 0)
                    {
                        int sumCard = 0;
                        for (int j = 0; j < distIns.Count; j++)
                            sumCard += dictDistIns[distIns[j]];
                        Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                        descriptors[index] = new Tuple<int, float>(sumCard, distIns[distIns.Count - 1] + 0.000001f);
                    }
                    else if (distIns[distIns.Count - 1] < distOuts[0])
                    {
                        int sumCard = 0;
                        for (int j = 0; j < distIns.Count; j++)
                            sumCard += dictDistIns[distIns[j]];
                        Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                        float thres = 0.5f * (distIns[distIns.Count - 1] + distOuts[0]);
                        if (thres > distIns[distIns.Count - 1] + 0.000001f)
                            thres = distIns[distIns.Count - 1] + 0.000001f;
                        descriptors[index] = new Tuple<int, float>(sumCard, thres);
                    }
                    else
                    {
                        float currentDistThreshold = distIns[distIns.Count - 1];
                        float descriptorDist = currentDistThreshold;
                        // when we use dist < threshold as a condition to judge whether a pixel is in this cluster,
                        // the number of errors happen on both sides: for the in side, those equal the last element are errors;
                        // for the out side, the number of errors equals to the number of elements < threshold in distSqrOuts
                        int currentInErrorCount = 0;
                        int currentInErrors = 0;
                        float nextDistThreshold = currentDistThreshold;
                        for (int k = distIns.Count - 1; k >= 0; k--)
                        {
                            if (distIns[k] < currentDistThreshold)
                            {
                                nextDistThreshold = distIns[k];
                                break;
                            }
                            currentInErrorCount += dictDistIns[distIns[k]];
                            currentInErrors++;
                        }
                        int currentOutErrorCount = 0;
                        int currentOutErrors = 0;
                        for (int k = 0; k < distOuts.Count; k++)
                        {
                            if (distOuts[k] >= currentDistThreshold)
                                break;
                            currentOutErrorCount += dictDistOuts[distOuts[k]];
                            currentOutErrors++;
                        }

                        while (nextDistThreshold > 0.0 && currentInErrors < distIns.Count)
                        {
                            float previousDistThreshold = currentDistThreshold;
                            currentDistThreshold = nextDistThreshold;
                            int previousErrorCount = currentInErrorCount + currentOutErrorCount;

                            for (int k = distIns.Count - currentInErrors - 1; k >= 0; k--)
                            {
                                if (distIns[k] < currentDistThreshold)
                                {
                                    nextDistThreshold = distIns[k];
                                    break;
                                }
                                currentInErrorCount += dictDistIns[distIns[k]];
                                currentInErrors++;
                            }

                            for (int k = currentOutErrors - 1; k >= 0; k--)
                            {
                                if (distOuts[k] < currentDistThreshold)
                                    break;
                                currentOutErrorCount -= dictDistOuts[distOuts[k]];
                                currentOutErrors--;
                            }

                            if (currentInErrorCount + currentOutErrorCount > previousErrorCount)
                            {
                                descriptorDist = previousDistThreshold;
                                break;
                            }
                        }

                        if (currentInErrors < distIns.Count)
                        {
                            int sumCard = 0;
                            for (int j = 0; j < distIns.Count; j++)
                            {
                                if (distIns[j] < descriptorDist)
                                {
                                    sumCard += dictDistIns[distIns[j]];
                                }
                                else
                                {
                                    break;
                                }
                            }
                            Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                            descriptors[index] = new Tuple<int, float>(sumCard, descriptorDist);
                        }
                    }
                }
            }
            else
            {
                Parallel.For(0, myNumDescriptor, iDesc =>
                {
                    int index = forest[clusterRank[iDesc]].getIndex();
                    Dictionary<float, int> dictDistIns = new Dictionary<float, int>();
                    Dictionary<float, int> dictDistOuts = new Dictionary<float, int>();
                    for (int i = 0; i < m; i++)
                    {
                        float dist = (float)knn.ComputeDistance((uint)i, (uint)index);
                        if (GetClusterID(i) == clusterRank[iDesc])
                        {
                            if (dictDistIns.ContainsKey(dist))
                            {
                                dictDistIns[dist] += cardinalities[i];
                            }
                            else
                            {
                                dictDistIns[dist] = cardinalities[i];
                            }
                        }
                        else
                        {
                            if (dictDistOuts.ContainsKey(dist))
                            {
                                dictDistOuts[dist] += cardinalities[i];
                            }
                            else
                            {
                                dictDistOuts[dist] = cardinalities[i];
                            }
                        }
                    }
                    List<float> distIns = new List<float>();
                    List<float> distOuts = new List<float>();
                    foreach (float dist in dictDistIns.Keys)
                    {
                        distIns.Add(dist);
                    }
                    foreach (float dist in dictDistOuts.Keys)
                    {
                        distOuts.Add(dist);
                    }

                    distIns.Sort();
                    distOuts.Sort();
                    if (distOuts.Count == 0)
                    {
                        int sumCard = 0;
                        for (int j = 0; j < distIns.Count; j++)
                            sumCard += dictDistIns[distIns[j]];
                        Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                        descriptors[index] = new Tuple<int, float>(sumCard, distIns[distIns.Count - 1] + 0.000001f);
                    }
                    else if (distIns[distIns.Count - 1] < distOuts[0])
                    {
                        int sumCard = 0;
                        for (int j = 0; j < distIns.Count; j++)
                            sumCard += dictDistIns[distIns[j]];
                        Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                        float thres = 0.5f * (distIns[distIns.Count - 1] + distOuts[0]);
                        if (thres > distIns[distIns.Count - 1] + 0.000001f)
                            thres = distIns[distIns.Count - 1] + 0.000001f;
                        descriptors[index] = new Tuple<int, float>(sumCard, thres);
                    }
                    else
                    {
                        float currentDistThreshold = distIns[distIns.Count - 1];
                        float descriptorDist = currentDistThreshold;
                        // when we use dist < threshold as a condition to judge whether a pixel is in this cluster,
                        // the number of errors happen on both sides: for the in side, those equal the last element are errors;
                        // for the out side, the number of errors equals to the number of elements < threshold in distSqrOuts
                        int currentInErrorCount = 0;
                        int currentInErrors = 0;
                        float nextDistThreshold = currentDistThreshold;
                        for (int k = distIns.Count - 1; k >= 0; k--)
                        {
                            if (distIns[k] < currentDistThreshold)
                            {
                                nextDistThreshold = distIns[k];
                                break;
                            }
                            currentInErrorCount += dictDistIns[distIns[k]];
                            currentInErrors++;
                        }
                        int currentOutErrorCount = 0;
                        int currentOutErrors = 0;
                        for (int k = 0; k < distOuts.Count; k++)
                        {
                            if (distOuts[k] >= currentDistThreshold)
                                break;
                            currentOutErrorCount += dictDistOuts[distOuts[k]];
                            currentOutErrors++;
                        }

                        while (nextDistThreshold > 0.0 && currentInErrors < distIns.Count)
                        {
                            float previousDistThreshold = currentDistThreshold;
                            currentDistThreshold = nextDistThreshold;
                            int previousErrorCount = currentInErrorCount + currentOutErrorCount;

                            for (int k = distIns.Count - currentInErrors - 1; k >= 0; k--)
                            {
                                if (distIns[k] < currentDistThreshold)
                                {
                                    nextDistThreshold = distIns[k];
                                    break;
                                }
                                currentInErrorCount += dictDistIns[distIns[k]];
                                currentInErrors++;
                            }

                            for (int k = currentOutErrors - 1; k >= 0; k--)
                            {
                                if (distOuts[k] < currentDistThreshold)
                                    break;
                                currentOutErrorCount -= dictDistOuts[distOuts[k]];
                                currentOutErrors--;
                            }

                            if (currentInErrorCount + currentOutErrorCount > previousErrorCount)
                            {
                                descriptorDist = previousDistThreshold;
                                break;
                            }
                        }

                        if (currentInErrors < distIns.Count)
                        {
                            int sumCard = 0;
                            for (int j = 0; j < distIns.Count; j++)
                            {
                                if (distIns[j] < descriptorDist)
                                {
                                    sumCard += dictDistIns[distIns[j]];
                                }
                                else
                                {
                                    break;
                                }
                            }
                            Debug.Assert(sumCard <= clusterSize[clusterRank[iDesc]]);
                            descriptors[index] = new Tuple<int, float>(sumCard, descriptorDist);
                        }
                    }
                });
            }


            return descriptors;
        }

        List<Tuple<long, Tuple<int, float>>> Summarize(SparseWeightKNN swknn, int clusterID)
        {
            DPCNode tree = forest[clusterID];
            HashSet<uint> myKnnIds = new HashSet<uint>();
            RecordKnnId(myKnnIds, tree);
            return swknn.Summarize(myKnnIds.ToList());
        }

        public List<Tuple<long, Tuple<int, float>>> GetSummary(int clusterID)
        {
            return summaries[clusterID];
        }
    }
}
