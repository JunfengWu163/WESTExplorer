﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JunfengWu.Tools
{
    public class EuclideanKNN : AbstractKNN
    {
        float[,] data;
        public (uint, float)[,] knns { get; private set; }
        public int k { get; private set; }

        public EuclideanKNN(float[,] data, IProgress<(int, string)> progress, int k = 5, int numSubCoversPerLevel = 16, int maxNumPointsPerLeaf = 256) : base()
        {
            this.data = data;
            this.k = k;
            int numData = data.GetLength(0);
            int numDims = data.GetLength(1);
            if (progress != null)
            {
                Init(progress, numSubCoversPerLevel, maxNumPointsPerLeaf);
            }
            else
            {
                Init(numSubCoversPerLevel, maxNumPointsPerLeaf);
            }
            knns = new (uint, float)[numData, k];
            Parallel.For(0, numData, i =>
            {
                var knnsI = KNNSearch((uint)i, 0.95, k, false);
                for (int j = 0; j < k; j++)
                {
                    if (j < knnsI.Length)
                    {
                        uint neighborJ = knnsI[j];
                        float distJ = (float)ComputeDistance((uint)i, neighborJ);
                        knns[i, j] = (neighborJ, distJ);
                    }
                    else
                    {
                        knns[i, j] = (uint.MaxValue, float.MaxValue);
                    }

                }
            });
        }

        public override double ComputeDistance(uint i1, uint i2)
        {
            int numDims = data.GetLength(1);
            double dist = 0.0;
            for (int i = 0; i < numDims; i++)
            {
                double dimDiffPrev = data[i1, i] - data[i2, i];
                dist += dimDiffPrev * dimDiffPrev;
            }
            dist = Math.Sqrt(dist);
            return dist;
        }

        double ComputeDistance(uint i1, float[] centerPos)
        {
            int numDims = data.GetLength(1);
            double dist = 0.0;
            for (int i = 0; i < numDims; i++)
            {
                double dimDiffPrev = data[i1, i] - centerPos[i];
                dist += dimDiffPrev * dimDiffPrev;
            }
            dist = Math.Sqrt(dist);
            return dist;
        }

        public override uint FindCenter(uint[] keys, bool parallel)
        {
            // compute center position
            int numDims = data.GetLength(1);
            float[] centerPos = new float[numDims];
            for (int idxDim = 0; idxDim < numDims; idxDim++)
            {
                centerPos[idxDim] = 0.0f;
            }
            if (parallel)
            {
                ConcurrentBag<float[]> localSums = new ConcurrentBag<float[]>();
                Parallel.ForEach(keys,
                        () =>
                        {
                            float[] localValues = new float[numDims];
                            for (int idxDim = 0; idxDim < numDims; idxDim++)
                            {
                                localValues[idxDim] = 0.0f;
                            }
                            return localValues;
                        },
                        (item, loopState, localResult) =>
                        {
                            for (int i = 0; i < numDims; i++)
                            {
                                localResult[i] += data[item, i];
                            }
                            return localResult;
                        },
                        localResult =>
                        {
                            localSums.Add(localResult);
                        }
                        );
                foreach (var localSum in localSums)
                {
                    for (int i = 0; i < numDims; i++)
                    {
                        centerPos[i] += localSum[i];
                    }
                }
            }
            else
            {
                foreach (uint item in keys)
                {
                    for (int i = 0; i < numDims; i++)
                    {
                        centerPos[i] += data[item, i];
                    }
                }
            }
            float w = 1.0f / data.GetLength(0);
            for (int i = 0; i < numDims; i++)
            {
                centerPos[i] *= w;
            }

            // find and return center
            if (parallel)
            {
                uint center = keys[0];
                (uint, double) centerInfo = (center, ComputeDistance(center, centerPos));
                ConcurrentBag<(uint, double)> localCenterInfos = new ConcurrentBag<(uint, double)>();
                Parallel.ForEach(keys,
                        () => centerInfo,
                        (item, loopState, localResult) =>
                        {
                            double dist = ComputeDistance(item, centerPos);
                            if (dist < localResult.Item2)
                            {
                                return (item, dist);
                            }
                            else
                            {
                                return localResult;
                            }
                        },
                        localResult =>
                        {
                            localCenterInfos.Add(localResult);
                        }
                        );
                double distCenter = centerInfo.Item2;
                foreach (var localCenterInfo in localCenterInfos)
                {
                    if (localCenterInfo.Item2 < distCenter)
                    {
                        distCenter = localCenterInfo.Item2;
                        center = localCenterInfo.Item1;
                    }
                }
                return center;
            }
            else
            {
                uint center = keys[0];
                double distCenter = ComputeDistance(center, centerPos);
                foreach (uint item in keys)
                {
                    double dist = ComputeDistance(item, centerPos);
                    if (dist < distCenter)
                    {
                        distCenter = dist;
                        center = item;
                    }
                }
                return center;
            }
        }

        public override int GetNumData()
        {
            return data.GetLength(0);
        }
    }
}


