﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace JunfengWu.Tools
{
    public abstract class AbstractKNN
    {
        // These three abstract methods must be implemented in inheritance class
        public abstract uint FindCenter(uint[] keys, bool parallel);
        public abstract double ComputeDistance(uint i1, uint i2);
        public abstract int GetNumData();

        internal class CoverSet
        {
            const int maxLevel = 10;
            public int level;
            public Dictionary<uint, int> mapping { get; private set; } = new Dictionary<uint, int>();
            public List<uint> subcenters { get; private set; } = new List<uint>();
            public List<CoverSet> subCoverSets { get; private set; } = new List<CoverSet>();
            public List<(int, int, double, double)> subCoverInfos { get; private set; } = new List<(int, int, double, double)>();
            public int numSubPartitions { get; private set; }
            public int maxNumPointsPerLeaf { get; private set; }

            bool SubcentersContain(uint idx)
            {
                foreach (uint idx2 in subcenters)
                {
                    if (idx2 == idx)
                    {
                        return true;
                    }
                }
                return false;
            }

            void FindSubCenters(AbstractKNN knn, int numSubPartitions, bool parallel)
            {
                Random rand = new Random(Guid.NewGuid().GetHashCode());
                uint[] keys = new uint[mapping.Count];
                mapping.Keys.CopyTo(keys, 0);
                int[] nearestSubcenter = new int[keys.Length];

                // use kmeans to find subcenters
                // step 1: initialize subcenters
                for (int j = 0; j < numSubPartitions; j++)
                {
                    int i1 = keys.Length * j / numSubPartitions;
                    int i2 = keys.Length * (j + 1) / numSubPartitions;
                    uint[] subkeys = new uint[i2 - i1];
                    for (int i = i1; i < i2; i++)
                    {
                        subkeys[i - i1] = keys[i];
                    }
                    subcenters.Add(knn.FindCenter(subkeys, parallel));
                }

                // step 2: repeatedly adjust subcenters by kmeans algorithm
                for (int round = 0; round <= 10; round++)
                {
                    HashSet<uint> currSubCenters = new HashSet<uint>(subcenters);
                    void FindNearestSubcenter(int i)
                    {
                        int nearest = 0;
                        double nearestDist = knn.ComputeDistance(keys[i], subcenters[0]);
                        for (int j = 0; j < numSubPartitions; j++)
                        {
                            double dist = knn.ComputeDistance(keys[i], subcenters[j]);
                            if (dist < nearestDist)
                            {
                                nearestDist = dist;
                                nearest = j;
                            }
                        }
                        nearestSubcenter[i] = nearest;
                    }

                    if (parallel)
                    {
                        Parallel.For(0, keys.Length, i =>
                        {
                            FindNearestSubcenter(i);
                        });
                    }
                    else
                    {
                        for (int i = 0; i < keys.Length; i++)
                        {
                            FindNearestSubcenter(i);
                        }
                    }

                    List<uint>[] dividedKeys = new List<uint>[numSubPartitions];
                    for (int j = 0; j < numSubPartitions; j++)
                    {
                        dividedKeys[j] = new List<uint>();
                    }
                    for (int i = 0; i < keys.Length; i++)
                    {
                        dividedKeys[nearestSubcenter[i]].Add(keys[i]);
                    }
                    if (round < 10)
                    {
                        for (int j = 0; j < numSubPartitions; j++)
                        {
                            if (dividedKeys[j].Count > 0)
                                subcenters[j] = knn.FindCenter(dividedKeys[j].ToArray(), parallel);
                            else
                                subcenters[j] = keys[rand.Next(keys.Length)];
                        }
                    }
                    else
                    {
                        for (int j = 0; j < numSubPartitions; j++)
                        {
                            if (dividedKeys[j].Count >= 9 * keys.Length / 10)
                            {
                                subcenters.Clear();
                            }
                                
                        }
                    }
                }
            }

            void Fill(AbstractKNN knn, ConcurrentBag<CoverSet> smallCoverSets)
            {
                if (subcenters.Count > 0)
                    return;

                FindSubCenters(knn, numSubPartitions, false);
                if (subcenters.Count == 0)
                    return;

                int numKeys = mapping.Count;
                for (int i = 0; i < numKeys; i++)
                    subCoverInfos.Add((-1, -1, 0.0, 0.0));

                HashSet<uint>[] subPartitionItems = new HashSet<uint>[numSubPartitions];
                for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                {
                    subPartitionItems[idxSubPartition] = new HashSet<uint>();
                }
                foreach (uint item in mapping.Keys)
                {
                    double distFromNearest = 0.0;
                    int nearest = -1;
                    double distFromSecondNearest = 0.0;
                    int secondNearest = -1;
                    for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                    {
                        double dist = knn.ComputeDistance(subcenters[idxSubPartition], item);
                        if (nearest < 0 || dist < distFromNearest)
                        {
                            secondNearest = nearest;
                            distFromSecondNearest = distFromNearest;
                            nearest = idxSubPartition;
                            distFromNearest = dist;
                        }
                        else if (secondNearest < 0 || dist < distFromSecondNearest)
                        {
                            secondNearest = idxSubPartition;
                            distFromSecondNearest = dist;
                        }
                    }
                    if (nearest >= 0)
                        subPartitionItems[nearest].Add(item);
                    if (secondNearest >= 0)
                        subPartitionItems[secondNearest].Add(item);
                    subCoverInfos[mapping[item]] = (nearest, secondNearest, distFromNearest, distFromSecondNearest);
                }

                for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                {
                    subCoverSets.Add(new CoverSet(level + 1, subPartitionItems[idxSubPartition], numSubPartitions, maxNumPointsPerLeaf, smallCoverSets));
                }
            }

            // constructor for fine scale cover sets
            public CoverSet(int level, HashSet<uint> items, int numSubPartitions, int maxNumPointsPerLeaf, ConcurrentBag<CoverSet> smallCoverSets)
            {
                this.level = level;
                //Console.WriteLine($"cover set level = {level}, num items = {items.Count}");
                this.numSubPartitions = numSubPartitions;
                this.maxNumPointsPerLeaf = maxNumPointsPerLeaf;
                foreach (var item in items)
                {
                    int itemID = mapping.Count;
                    mapping.Add(item, itemID);
                }
                if (items.Count > maxNumPointsPerLeaf && level < maxLevel)
                {
                    smallCoverSets.Add(this);
                }
            }

            // constructor for coarse scale cover sets without progress report
            public CoverSet(int level, AbstractKNN knn, HashSet<uint> items, int numSubPartitions, int maxNumPointsPerLeaf, ConcurrentBag<CoverSet> smallCoverSets)
            {
                this.level = level;
                this.numSubPartitions = numSubPartitions;
                this.maxNumPointsPerLeaf = maxNumPointsPerLeaf;
                Init(knn, items, smallCoverSets, new Progress<(int, string)>());
            }

            // constructor for coarse scale cover sets with progress report
            public CoverSet(int level, AbstractKNN knn, HashSet<uint> items, int numSubPartitions, int maxNumPointsPerLeaf, ConcurrentBag<CoverSet> smallCoverSets, IProgress<(int, string)> progress)
            {
                this.level = level;
                this.numSubPartitions = numSubPartitions;
                this.maxNumPointsPerLeaf = maxNumPointsPerLeaf;
                Init(knn, items, smallCoverSets, progress);
            }

            void Init(AbstractKNN knn, HashSet<uint> items, ConcurrentBag<CoverSet> smallCoverSets, IProgress<(int, string)> progress)
            {
                foreach (var item in items)
                {
                    int itemID = mapping.Count;
                    mapping.Add(item, itemID);
                }
                if (items.Count <= maxNumPointsPerLeaf || level >= maxLevel)
                {
                    return;
                }
                else if (level > 1)
                {
                    smallCoverSets.Add(this);
                }
                else
                {
                    if (knn.GetNumData() == items.Count)
                        progress.Report((0, "Fast KNN:"));
                    FindSubCenters(knn, numSubPartitions, true);
                    if (subcenters.Count == 0)
                        return;

                    int numKeys = mapping.Count;
                    for (int i = 0; i < numKeys; i++)
                        subCoverInfos.Add((-1, -1, 0.0, 0.0));

                    HashSet<uint>[] subPartitionItems = new HashSet<uint>[numSubPartitions];
                    for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                    {
                        subPartitionItems[idxSubPartition] = new HashSet<uint>();
                    }
                    Parallel.ForEach(items,
                        () =>
                        {
                            HashSet<uint>[] localSubPartitionItems = new HashSet<uint>[numSubPartitions];
                            for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                            {
                                localSubPartitionItems[idxSubPartition] = new HashSet<uint>();
                            }
                            return localSubPartitionItems;
                        },
                        (item, loopState, localSubPartitionItems) =>
                        {
                            double distFromNearest = 0.0;
                            int nearest = -1;
                            double distFromSecondNearest = 0.0;
                            int secondNearest = -1;
                            for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                            {
                                double dist = knn.ComputeDistance(subcenters[idxSubPartition], item);
                                if (nearest < 0 || dist < distFromNearest)
                                {
                                    secondNearest = nearest;
                                    distFromSecondNearest = distFromNearest;
                                    nearest = idxSubPartition;
                                    distFromNearest = dist;
                                }
                                else if (secondNearest < 0 || dist < distFromSecondNearest)
                                {
                                    secondNearest = idxSubPartition;
                                    distFromSecondNearest = dist;
                                }
                            }
                            if (nearest >= 0)
                                localSubPartitionItems[nearest].Add(item);
                            if (secondNearest >= 0)
                                localSubPartitionItems[secondNearest].Add(item);
                            subCoverInfos[mapping[item]] = (nearest, secondNearest, distFromNearest, distFromSecondNearest);
                            return localSubPartitionItems;
                        },
                        localSubPartitionItems =>
                        {
                            lock (subPartitionItems)
                            {
                                for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                                {
                                    subPartitionItems[idxSubPartition].UnionWith(localSubPartitionItems[idxSubPartition]);
                                }
                            }
                        }
                        );
                    if (knn.GetNumData() == items.Count)
                        progress.Report((100 / (numSubPartitions + 2), "Fast KNN:"));
                    for (int idxSubPartition = 0; idxSubPartition < numSubPartitions; idxSubPartition++)
                    {
                        subCoverSets.Add(new CoverSet(level + 1, knn, subPartitionItems[idxSubPartition], numSubPartitions, maxNumPointsPerLeaf, smallCoverSets));
                        if (knn.GetNumData() == items.Count)
                            progress.Report((100 * (2 + idxSubPartition) / (numSubPartitions + 2), "Fast KNN:"));
                    }
                    if (knn.GetNumData() == items.Count)
                    {
                        ConcurrentBag<CoverSet> currSmallCoverSets = smallCoverSets;
                        while (currSmallCoverSets.Count > 0)
                        {
                            ConcurrentBag<CoverSet> newSmallCoverSets = new ConcurrentBag<CoverSet>();
                            Parallel.ForEach(currSmallCoverSets, (coverSet) =>
                            {
                                coverSet.Fill(knn, newSmallCoverSets);
                            });
                            currSmallCoverSets = newSmallCoverSets;
                        }
                        progress.Report((100, "Fast KNN:"));
                    }
                }
            }

            public void GetNeighbors(uint item, double bidirectionThreshold, HashSet<uint> neighbors)
            {
                int itemID;
                if (mapping.TryGetValue(item, out itemID))
                {
                    if (subCoverInfos.Count == 0)
                    {
                        foreach (var neighbor in mapping.Keys)
                        {
                            neighbors.Add(neighbor);
                        }
                    }
                    else
                    {
                        if (subCoverInfos[itemID].Item1 >= 0)
                        {
                            subCoverSets?[subCoverInfos[itemID].Item1].GetNeighbors(item, bidirectionThreshold, neighbors);
                            if (subCoverInfos[itemID].Item2 >= 0 && subCoverInfos[itemID].Item4 >= bidirectionThreshold * subCoverInfos[itemID].Item3)
                            {
                                subCoverSets?[subCoverInfos[itemID].Item2].GetNeighbors(item, bidirectionThreshold, neighbors);
                            }
                        }
                    }
                }
            }

            public uint[] KNNSearch(HashSet<uint> neighbors, AbstractKNN knn, uint item, int k, bool parallel)
            {
                uint[] neighborIDs = new uint[neighbors.Count];
                neighbors.CopyTo(neighborIDs, 0);
                int[] neighborRanks = new int[neighbors.Count];
                double[] distanceFromNeighbors = new double[neighbors.Count];
                if (parallel)
                {
                    Parallel.For(0, neighborIDs.Length, (i) =>
                    {
                        uint neighbor = neighborIDs[i];
                        double dist = knn.ComputeDistance(item, neighbor);
                        distanceFromNeighbors[i] = dist;
                        neighborRanks[i] = i;
                    });
                }
                else
                {
                    for (int i = 0; i < neighborIDs.Length; i++)
                    {
                        uint neighbor = neighborIDs[i];
                        double dist = knn.ComputeDistance(item, neighbor);
                        distanceFromNeighbors[i] = dist;
                        neighborRanks[i] = i;
                    }
                }

                Array.Sort(neighborRanks, (x, y) => { return Math.Sign(distanceFromNeighbors[x] - distanceFromNeighbors[y]); });
                if (neighborRanks.Length > k)
                {
                    uint[] result = new uint[k];
                    for (int i = 0; i < result.Length; i++)
                    {
                        result[i] = neighborIDs[neighborRanks[i]];
                    }
                    return result;
                }
                else
                {
                    uint[] result = new uint[neighborRanks.Length];
                    for (int i = 0; i < result.Length; i++)
                    {
                        result[i] = neighborIDs[neighborRanks[i]];
                    }
                    return result;
                }
            }

            public uint[] KNNSearch(AbstractKNN knn, uint item, double bidirectionThreshold, int k, bool parallel)
            {
                HashSet<uint> neighbors = new HashSet<uint>();
                GetNeighbors(item, bidirectionThreshold, neighbors);
                return KNNSearch(neighbors, knn, item, k, parallel);
            }
        }

        private CoverSet coverSet;

        public AbstractKNN()
        {

        }

        public void Init(IProgress<(int, string)> progress, int numSubCoversPerLevel = 16, int maxNumPointsPerLeaf = 256)
        {
            HashSet<uint> items = new HashSet<uint>();
            int numData = GetNumData();
            for (int i = 0; i < numData; i++)
            {
                items.Add((uint)i);
            }
            ConcurrentBag<CoverSet> smallCoverSets = new ConcurrentBag<CoverSet>();
            coverSet = new CoverSet(0, this, items, numSubCoversPerLevel, maxNumPointsPerLeaf, smallCoverSets, progress);
        }

        public void Init(int numSubCoversPerLevel = 16, int maxNumPointsPerLeaf = 256)
        {
            HashSet<uint> items = new HashSet<uint>();
            int numData = GetNumData();
            for (int i = 0; i < numData; i++)
            {
                items.Add((uint)i);
            }
            ConcurrentBag<CoverSet> smallCoverSets = new ConcurrentBag<CoverSet>();
            coverSet = new CoverSet(0, this, items, numSubCoversPerLevel, maxNumPointsPerLeaf, smallCoverSets);
        }

        public uint[] KNNSearch(uint i, double bidirThres, int k, bool parallel)
        {
            return coverSet.KNNSearch(this, i, bidirThres, k, parallel);
        }

        public uint[] KNNSearch(HashSet<uint> neighbors, uint i, int k, bool parallel)
        {
            return coverSet.KNNSearch(neighbors, this, i, k, parallel);
        }

        public void GetNeighbors(uint i, double bidirectionThreshold, HashSet<uint> neighbors)
        {
            coverSet.GetNeighbors(i, bidirectionThreshold, neighbors);
        }
    }
}
