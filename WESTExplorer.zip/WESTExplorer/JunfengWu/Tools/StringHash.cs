﻿using System;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace JunfengWu.Tools
{
    public class StringHash
    {
        Dictionary<int, SHA256> sha256s = new Dictionary<int, SHA256>();
        Dictionary<int, SHA384> sha384s = new Dictionary<int, SHA384>();
        Dictionary<int, SHA512> sha512s = new Dictionary<int, SHA512>();
        
        public StringHash()
        {

        }

        UInt64 GetCode(byte[] hash)
        {
            UInt64 value = 0;
            for (int i1 = 0; i1 < hash.Length; i1 += 8)
            {
                UInt64 value1 = 0;
                for (int i2 = 0; i2 < 8 && i1 + i2 < hash.Length; i2++)
                {
                    value1 = (value1 << 8) | hash[i1 + i2];
                }
                value = value ^ value1;
            }
            return value;
        }

        public UInt64 Get256Code(string s)
        {
            int threadId = Thread.CurrentThread.ManagedThreadId;
            SHA256 sha;
            if (!sha256s.TryGetValue(threadId, out sha))
            {
                sha = SHA256.Create();
                lock(sha256s)
                {
                    sha256s.Add(threadId, sha);
                }
            }
            return GetCode(sha.ComputeHash(Encoding.Unicode.GetBytes(s)));
        }

        public UInt64 Get384Code(string s)
        {
            int threadId = Thread.CurrentThread.ManagedThreadId;
            SHA384 sha;
            if (!sha384s.TryGetValue(threadId, out sha))
            {
                sha = SHA384.Create();
                lock (sha384s)
                {
                    sha384s.TryAdd(threadId, sha);
                }
            }
            return GetCode(sha.ComputeHash(Encoding.Unicode.GetBytes(s)));
        }

        public UInt64 Get512Code(string s)
        {
            int threadId = Thread.CurrentThread.ManagedThreadId;
            SHA512 sha;
            if (!sha512s.TryGetValue(threadId, out sha))
            {
                sha = SHA512.Create();
                lock (sha512s)
                {
                    sha512s.Add(threadId, sha);
                }
            }
            return GetCode(sha.ComputeHash(Encoding.Unicode.GetBytes(s)));
        }
    }
}

