﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Factorization;
using Annytab.Stemmer;

namespace JunfengWu.Tools
{
    public class WordEmbeddingVectors
    {
        public class TermMatch
        {
            public int termID { get; }
            public int start { get; }
            public int end { get; }
            public string source { get; }
            public string target { get; }
            public double similariy { get; }

            public TermMatch(int termID, int start, int end, string source, string target, double similarity)
            {
                this.termID = termID;
                this.start = start;
                this.end = end;
                this.source = source;
                this.target = target;
                similariy = similarity;
            }
        }

        public class PartConnection
        {
            int partID;
            string word;
            ConcurrentDictionary<int, PartConnection> connections = new ConcurrentDictionary<int, PartConnection>();
            public PartConnection(int partID, string word, PartConnection parent)
            {
                this.partID = partID;
                this.word = word;
                if (parent != null)
                {
                    parent.connections[partID] = this;
                }
            }

            public void Match(int[] partIDs, int offset, List<string> result)
            {
                if (partIDs[offset] != partID)
                    return;
                if (word.Length > 0)
                    result.Add(word);
                if (offset + 1 < partIDs.Length)
                {
                    PartConnection next;
                    if (connections.TryGetValue(partIDs[offset + 1], out next))
                    {
                        next.Match(partIDs, offset + 1, result);
                    }
                }
            }

            public void SetWord(string word)
            {
                this.word = word;
            }

            public void Update(List<int> partIDsOfTerm, int offset, string term)
            {
                if (offset >= partIDsOfTerm.Count)
                {
                    word = term;
                    return;
                }
                PartConnection next;
                if (connections.TryGetValue(partIDsOfTerm[offset], out next))
                {
                    next.Update(partIDsOfTerm, offset + 1, term);
                }
                else if (offset + 1 == partIDsOfTerm.Count)
                {
                    connections[partIDsOfTerm[offset]] = new PartConnection(partIDsOfTerm[offset], term, this);
                }
                else
                {
                    next = new PartConnection(partIDsOfTerm[offset], "", this);
                    connections[partIDsOfTerm[offset]] = next;
                    next.Update(partIDsOfTerm, offset + 1, term);
                }
            }

            public static void UpdateConnections(ConcurrentDictionary<int, PartConnection> connections, string term, List<int> partIDsOfTerm)
            {
                PartConnection connection;
                if (connections.TryGetValue(partIDsOfTerm[0], out connection))
                {
                    connection.Update(partIDsOfTerm, 1, term);
                }
                else
                {
                    if (1 == partIDsOfTerm.Count)
                    {
                        connection = new PartConnection(partIDsOfTerm[0], term, null);
                    }
                    else
                    {
                        connection = new PartConnection(partIDsOfTerm[0], "", null);
                        connection.Update(partIDsOfTerm, 1, term);
                    }
                    connections[partIDsOfTerm[0]] = connection;
                }
            }
        }

        List<string> vocaburary = new List<string>();
        ConcurrentDictionary<string, int> wordIDs = new ConcurrentDictionary<string, int>();
        List<float[]> wordVectors = new List<float[]>();
        List<string> parts = new List<string>();
        ConcurrentDictionary<string, int> partIDs = new ConcurrentDictionary<string, int>();
        ConcurrentDictionary<int, PartConnection> connections = new ConcurrentDictionary<int, PartConnection>();
        HashSet<char> punctuations = new HashSet<char>();
        EnglishStemmer stemmer = new EnglishStemmer();

        public class Matcher
        {
            WordEmbeddingVectors wvs;
            ConcurrentDictionary<int, PartConnection> connections = new ConcurrentDictionary<int, PartConnection>();
            List<string> terms = new List<string>();
            ConcurrentDictionary<string, HashSet<int>> synonymTermIDs = new ConcurrentDictionary<string, HashSet<int>>();
            List<ConcurrentDictionary<string, double>> termSynonymSimilarities = new List<ConcurrentDictionary<string, double>>();

            void UpdateSynonymTermIDs(string syn, int termID)
            {
                HashSet<int> termIDs;
                if (synonymTermIDs.TryGetValue(syn, out termIDs))
                {
                    termIDs.Add(termID);
                }
                else
                {
                    termIDs = new HashSet<int>();
                    termIDs.Add(termID);
                    synonymTermIDs[syn] = termIDs;
                }
            }

            public Matcher(WordEmbeddingVectors wvs, IProgress<int> progress)
            {
                this.wvs = wvs;
                connections = wvs.connections;
                terms = wvs.vocaburary;
                int numTerms = terms.Count;
                progress?.Report(0);
                int currProgress = 0;
                for (int idxTerm = 0; idxTerm < numTerms; idxTerm++)
                {
                    ConcurrentDictionary<string, double> similarities = new ConcurrentDictionary<string, double>();

                    similarities[terms[idxTerm]] = 1.0;
                    termSynonymSimilarities.Add(similarities);
                    UpdateSynonymTermIDs(terms[idxTerm], idxTerm);

                    int newProgress = (idxTerm + 1) * 100 / numTerms;
                    if (newProgress > currProgress)
                    {
                        currProgress = newProgress;
                        progress?.Report(newProgress);
                    }
                }
            }

            public Matcher(WordEmbeddingVectors wvs, List<int> termVocabIDs, List<HashSet<string>> termSynonyms, IProgress<int> progress)
            {
                this.wvs = wvs;
                int numTerms = termVocabIDs.Count;
                Debug.Assert(termSynonyms.Count == numTerms);
                int n = wvs.wordVectors[0].Length;
                progress?.Report(0);
                int currProgress = 0;
                for (int idxTerm = 0; idxTerm < numTerms; idxTerm++)
                {
                    ConcurrentDictionary<string, double> similarities = new ConcurrentDictionary<string, double>();

                    int vocabID = termVocabIDs[idxTerm];
                    string term = wvs.GetWord(vocabID);
                    float[] vecTerm = wvs.wordVectors[vocabID];
                    List<int> partIDsOfTerm = wvs.GetPartIDsOfWord(vocabID);
                    PartConnection.UpdateConnections(connections, term, partIDsOfTerm);
                    similarities[term] = 1.0;
                    terms.Add(term);
                    UpdateSynonymTermIDs(term, idxTerm);

                    HashSet<string> synonyms = termSynonyms[idxTerm];
                    foreach (string syn in synonyms)
                    {
                        int wordID;
                        if (!wvs.wordIDs.TryGetValue(syn, out wordID))
                            continue;
                        float[] vecSyn = wvs.wordVectors[wordID];
                        double sim = wvs.ComputeSimilarity(vecTerm, vecSyn);
                        List<int> partIDsOfSyn = wvs.GetPartIDsOfWord(wordID);
                        PartConnection.UpdateConnections(connections, syn, partIDsOfSyn);
                        similarities[syn] = sim;
                        UpdateSynonymTermIDs(syn, idxTerm);
                    }

                    termSynonymSimilarities.Add(similarities);

                    int newProgress = (idxTerm + 1) * 100 / numTerms;
                    if (newProgress > currProgress)
                    {
                        currProgress = newProgress;
                        progress?.Report(newProgress);
                    }
                }
            }

            public List<TermMatch> Match(string s, out List<string> parts)
            {
                List<TermMatch> result = new List<TermMatch>();
                int[] partIDs = wvs.GetPartIDs(s, out parts);
                for (int i = 0; i < partIDs.Length; i++)
                {
                    PartConnection connection;
                    if (connections.TryGetValue(partIDs[i], out connection))
                    {
                        List<string> matchedSyns = new List<string>();
                        connection.Match(partIDs, i, matchedSyns);
                        if (matchedSyns.Count > 0)
                        {
                            for (int j = 0; j < matchedSyns.Count; j++)
                            {
                                string syn = matchedSyns[j];
                                string[] partsOfSyn = syn.Split('_');
                                int start = i;
                                int end = start + partsOfSyn.Length;

                                HashSet<int> termIDs;
                                if (synonymTermIDs.TryGetValue(syn, out termIDs))
                                {
                                    foreach (int termID in termIDs)
                                    {
                                        string term = terms[termID];
                                        double sim = termSynonymSimilarities[termID][syn];
                                        TermMatch item = new TermMatch(termID, start, end, syn, term, sim);
                                        result.Add(item);
                                    }
                                }
                            }
                        }
                    }
                }
                return result;
            }

            public float[][] GetVectors(int[] ids)
            {
                float[][] result = new float[ids.Length][];
                for (int i = 0; i < ids.Length; i++)
                {
                    result[i] = wvs.wordVectors[ids[i]];
                }
                return result;
            }

            public float[] GetVector(int id)
            {
                return wvs.wordVectors[id];
            }

            public string GetWord(int id)
            {
                return wvs.GetWord(id);
            }

            public bool IsOverlap(int id1, int id2)
            {
                if (id1 == id2)
                    return true;

                string word1 = wvs.GetWord(id1);
                string word2 = wvs.GetWord(id2);
                string[] fields1 = word1.Split('_');
                string[] fields2 = word2.Split('_');
                for (int i = 0; i < fields1.Length; i++)
                {
                    fields1[i] = wvs.stemmer.GetSteamWord(fields1[i]);
                }
                for (int i = 0; i < fields2.Length; i++)
                {
                    fields2[i] = wvs.stemmer.GetSteamWord(fields2[i]);
                }
                int n1 = fields1.Length;
                int n2 = fields2.Length;
                if (n1 > n2)
                {
                    for (int i = 0; i < n1 - n2 + 1; i++)
                    {
                        bool matched = true;
                        for (int j = 0; j < n2; j++)
                        {
                            if (fields1[i + j] != fields2[j])
                            {
                                matched = false;
                                break;
                            }
                        }
                        if (matched)
                            return true;
                    }
                    return false;
                }
                else
                {
                    for (int i = 0; i < n2 - n1 + 1; i++)
                    {
                        bool matched = true;
                        for (int j = 0; j < n1; j++)
                        {
                            if (fields2[i + j] != fields1[j])
                            {
                                matched = false;
                                break;
                            }
                        }
                        if (matched)
                            return true;
                    }
                    return false;
                }
            }
        }

        void InitPuntuations()
        {
            punctuations.Add('\'');
            punctuations.Add('"');
            punctuations.Add('`');
            punctuations.Add('‘');
            punctuations.Add('’');
            punctuations.Add('“');
            punctuations.Add('”');
            punctuations.Add(',');
            punctuations.Add('.');
            punctuations.Add(':');
            punctuations.Add(';');
            punctuations.Add('?');
            punctuations.Add('{');
            punctuations.Add('}');
            punctuations.Add('[');
            punctuations.Add(']');
            punctuations.Add('(');
            punctuations.Add(')');
            punctuations.Add('@');
            punctuations.Add('#');
            punctuations.Add('$');
            punctuations.Add('%');
            punctuations.Add('^');
            punctuations.Add('&');
            punctuations.Add('*');
            punctuations.Add('。');
            punctuations.Add('，');
            punctuations.Add('、');
            punctuations.Add('？');
            punctuations.Add('：');
            punctuations.Add('/');
            punctuations.Add('\\');
        }

        void UpdateParts(string word)
        {
            string[] partsOfWord = word.Split("_");
            List<int> partIDsOfWord = new List<int>();
            string term = "";
            for (int idxPart = 0; idxPart < partsOfWord.Length; idxPart++)
            {
                if (partsOfWord[idxPart].Length == 0)
                    continue;
                int partID;
                if (!partIDs.TryGetValue(partsOfWord[idxPart], out partID))
                {
                    partID = parts.Count;
                    partIDs[partsOfWord[idxPart]] = partID;
                    parts.Add(partsOfWord[idxPart]);
                }
                partIDsOfWord.Add(partID);
                term += "_" + partsOfWord[idxPart];
            }
            if (term == "")
                return;
            term = term.Substring(1);

            PartConnection.UpdateConnections(connections, term, partIDsOfWord);
        }

        public WordEmbeddingVectors(string csoDataPath, IProgress<int> progress)
        {
            string fileName1 = Path.Combine(csoDataPath, "w2v.vectors");
            string fileName2 = Path.Combine(csoDataPath, "w2v.vocab.txt");

            int currProgress = 0;
            progress?.Report(currProgress);
            FileStream fstreamVectors = new FileStream(fileName1, FileMode.Open);
            BinaryReader binaryReader = new BinaryReader(fstreamVectors);
            int m = binaryReader.ReadInt32();
            int n = binaryReader.ReadInt32();
            float[][] temp = new float[m][];
            for (int i = 0; i < m; i++)
            {
                float[] temp2 = new float[n];
                temp[i] = temp2;
                for (int j = 0; j < n; j++)
                {
                    temp2[j] = binaryReader.ReadSingle();
                }
                int newProgress = (i + 1) * 70 / m;
                if (newProgress > currProgress)
                {
                    currProgress = newProgress;
                    progress?.Report(newProgress);
                }
            }
            fstreamVectors.Close();

            InitPuntuations();
            string[] lines = File.ReadAllLines(fileName2);
            Debug.Assert(lines.Length == temp.Length);
            const int vectorSize = 128;
            Debug.Assert(vectorSize == temp[0].Length);
            for (int idxLine = 0; idxLine < lines.Length; idxLine++)
            {
                wordIDs[lines[idxLine]] = vocaburary.Count;
                vocaburary.Add(lines[idxLine]);
                UpdateParts(lines[idxLine]);
                float[] vector = temp[idxLine];
                wordVectors.Add(vector);

                int newProgress = 70 + (idxLine + 1) * 30 / lines.Length;
                if (newProgress > currProgress)
                {
                    currProgress = newProgress;
                    progress?.Report(newProgress);
                }
            }
        }

        public List<float[]> GetWordVectors()
        {
            return wordVectors;
        }

        List<int> GetPartIDsOfWord(int vocabID)
        {
            List<int> result = new List<int>();
            string[] partsOfWord = vocaburary[vocabID].Split("_");
            for (int idxPart = 0; idxPart < partsOfWord.Length; idxPart++)
            {
                if (partsOfWord[idxPart].Length == 0)
                    continue;
                int partID = partIDs[partsOfWord[idxPart]];
                result.Add(partID);
            }
            return result;
        }

        double ComputeSimilarity(float[] vecTerm, float[] vecSyn)
        {
            int n = wordVectors[0].Length;
            double r1 = 0.0;
            double r2 = 0.0;
            double x = 0.0;
            for (int i = 0; i < n; i++)
            {
                r1 += vecTerm[i] * vecTerm[i];
                r2 += vecSyn[i] * vecSyn[i];
                x += vecTerm[i] * vecSyn[i];
            }
            return x / Math.Sqrt(r1 * r2);
        }

        public int[] GetPartIDs(string s, out List<string> parts)
        {
            parts = new List<string>();

            // step 1: split by space
            string[] ss1 = s.Split(' ');

            // step 2: split by puntuations
            for (int i = 0; i < ss1.Length; i++)
            {
                string ss1i = ss1[i].ToLower();
                if (ss1i.Length == 0)
                    continue;

                int j0 = 0;
                int j1 = ss1i.Length;
                while (punctuations.Contains(ss1i[j0]))
                {
                    parts.Add(ss1i[j0].ToString());
                    j0++;
                    if (j0 >= j1)
                        break;
                }
                if (j0 < j1)
                {
                    while (punctuations.Contains(ss1i[j1 - 1]))
                    {
                        j1--;
                        if (j1 <= j0)
                            break;
                    }
                    if (j0 < j1)
                    {
                        parts.Add(ss1i.Substring(j0, j1 - j0));
                        for (int j = j1; j < ss1i.Length; j++)
                        {
                            parts.Add(ss1i[j1].ToString());
                        }
                    }
                }
            }

            // step 3: convert temp to part IDs
            int[] partIDs = new int[parts.Count];
            for (int i = 0; i < partIDs.Length; i++)
            {
                if (this.partIDs.ContainsKey(parts[i]))
                {
                    partIDs[i] = this.partIDs[parts[i]];
                }
                else
                {
                    partIDs[i] = -1;
                }
            }

            return partIDs;
        }

        public int GetNumWords()
        {
            return vocaburary.Count;
        }

        public float[][] GetVectors(List<List<int>> termVocabIDs, out Dictionary<int, int> termExtendedVocabIDs)
        {
            int numExtended = vocaburary.Count;
            termExtendedVocabIDs = new Dictionary<int, int>();
            // for multi-word phrases
            for (int i = 0; i < termVocabIDs.Count; i++)
            {
                if (termVocabIDs[i].Count > 1)
                {
                    termExtendedVocabIDs[i] = numExtended;
                    numExtended++;
                }
                else
                {
                    Debug.Assert(termVocabIDs[i].Count == 1);
                    termExtendedVocabIDs[i] = termVocabIDs[i][0];
                }
            }
            float[][] result = new float[numExtended][];
            for (int i = 0; i < vocaburary.Count; i++)
            {
                result[i] = wordVectors[i];
            }
            for (int i = 0; i < termVocabIDs.Count; i++)
            {
                if (termVocabIDs[i].Count > 1)
                {
                    int id = termExtendedVocabIDs[i];
                    int n = result[0].Length;
                    float[] vec = new float[n];
                    for (int j = 0; j < n; j++)
                    {
                        vec[j] = 0.0f;
                    }
                    for (int k = 0; k < termVocabIDs[i].Count; k++)
                    {
                        float[] vecf = wordVectors[termVocabIDs[i][k]];
                        for (int j = 0; j < n; j++)
                        {
                            vec[j] += vecf[j];
                        }
                    }
                    result[id] = vec;
                }
            }
            return result;
        }

        public double[][] GetNormalizedVectors(List<List<int>> termVocabIDs, out Dictionary<int, int> termExtendedVocabIDs)
        {
            int numExtended = vocaburary.Count;
            termExtendedVocabIDs = new Dictionary<int, int>();
            for (int i = 0; i < termVocabIDs.Count; i++)
            {
                if (termVocabIDs[i].Count > 1)
                {
                    termExtendedVocabIDs[i] = numExtended;
                    numExtended++;
                }
                else
                {
                    Debug.Assert(termVocabIDs[i].Count == 1);
                    termExtendedVocabIDs[i] = termVocabIDs[i][0];
                }
            }
            double[][] result = new double[numExtended][];
            for (int i = 0; i < vocaburary.Count; i++)
            {
                float[] vecf = wordVectors[i];
                int n = vecf.Length;
                double[] vec = new double[n];
                double r = 0.0;
                for (int j = 0; j < n; j++)
                {
                    r += vecf[j] * vecf[j];
                }
                r = Math.Sqrt(r);
                if (r > 0.0)
                {
                    double w = 1.0 / r;
                    for (int j = 0; j < n; j++)
                    {
                        vec[j] = vecf[j] * w;
                    }
                }

                result[i] = vec;
            }
            for (int i = 0; i < termVocabIDs.Count; i++)
            {
                if (termVocabIDs[i].Count > 1)
                {
                    int id = termExtendedVocabIDs[i];
                    int n = result[0].Length;
                    double[] vec = new double[n];
                    for (int j = 0; j < n; j++)
                    {
                        vec[j] = 0.0;
                    }
                    for (int k = 0; k < termVocabIDs[i].Count; k++)
                    {
                        float[] vecf = wordVectors[termVocabIDs[i][k]];
                        for (int j = 0; j < n; j++)
                        {
                            vec[j] += vecf[j];
                        }
                    }
                    double r = 0.0;
                    for (int j = 0; j < n; j++)
                    {
                        r += vec[j] * vec[j];
                    }
                    r = Math.Sqrt(r);
                    if (r > 0.0)
                    {
                        double w = 1.0 / r;
                        for (int j = 0; j < n; j++)
                        {
                            vec[j] = vec[j] * w;
                        }
                    }
                    result[id] = vec;
                }
            }
            return result;
        }

        public ConcurrentDictionary<string, int> GetVocabulary()
        {
            return wordIDs;
        }

        public string GetWord(int i)
        {
            return vocaburary[i];
        }
    }
}
