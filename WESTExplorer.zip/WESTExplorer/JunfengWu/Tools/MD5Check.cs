﻿using System;
using System.Security.Cryptography;

namespace JunfengWu.Tools
{
    public class MD5Check
    {
        static string GetMD5Hash(string dataFileName)
        {
            using (MD5 md5 = MD5.Create())
            {
                using (FileStream dataStream = File.OpenRead(dataFileName))
                {
                    return BitConverter.ToString(md5.ComputeHash(dataStream));
                }
            }
        }

        public static void SaveMD5Hash(string dataFileName)
        {
            string md5FileName = dataFileName + ".md5";
            using (FileStream md5Stream = File.Create(md5FileName))
            {
                using (StreamWriter writer = new StreamWriter(md5Stream))
                {
                    string hash = GetMD5Hash(dataFileName);
                    writer.WriteLine(hash);
                }
            }
        }

        public static bool Check(string dataFileName)
        {
            if (!File.Exists(dataFileName))
            {
                return false;
            }
            string md5FileName = dataFileName + ".md5";
            if (!File.Exists(md5FileName))
            {
                return false;
            }
            string[] md5Strings = File.ReadAllLines(md5FileName);
            if (md5Strings.Length != 1)
            {
                return false;
            }
            string hash = GetMD5Hash(dataFileName);
            if (hash != md5Strings[0])
            {
                return false;
            }
            return true;
        }
    }
}

