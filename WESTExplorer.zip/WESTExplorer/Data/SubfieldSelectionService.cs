﻿using System;
using JunfengWu.Configuration;
using JunfengWu.OpenAlex;
using JunfengWu.Terms;
using JunfengWu.Synonyms;
using JunfengWu.Supertopics;
using JunfengWu.Topics;
using JunfengWu.Predictions;
using JunfengWu.Verifications;
using JunfengWu.Queries;
using JunfengWu.FastText;
using WESTExplorer.Pages;
namespace WESTExplorer.Data
{
    public class SubfieldSelectionService
    {
        Selector selector = new Selector(new DataLocation());
        WESTExplorer.Pages.Index _IndexPage = null;
        FastTextModel fastTextModel = null;

        public double TotalProgress
        {
            get => IndexPage.totalProgress;
            set
            {
                IndexPage.totalProgress = value;
                IndexPage.Refresh();
            }
        }
        public double StepProgress
        {
            get => IndexPage.stepProgress;
            set
            {
                IndexPage.stepProgress = value;
                IndexPage.Refresh();
            }
        }

        public double Level2BucketProgressPercent => StepProgress * 100;


        public WESTExplorer.Pages.Index IndexPage;
        public List<ConceptEntity> Level0 { get; set; } = new List<ConceptEntity>();
        public List<ConceptEntity> Level1 { get; set; } = new List<ConceptEntity>();
        public List<ConceptEntity> Level2 { get; set; } = new List<ConceptEntity>();

        public string Level0ConceptName;
        public string Level1ConceptName;
        public string Level2ConceptName;
        
        UInt64 _Level0id = 0;
        public UInt64 Level0id {
            get => _Level0id;
            set {
                for (int i = 0; i < Level0.Count; i++)
                {
                    if (Level0[i].id == value)
                    {
                        selector.Select(Level0[i]);
                        _Level0id = value;
                        Level0ConceptName = Level0[i].name;

                        _Level1id = 0;
                        _Level2id = 0;
                        Level1 = selector.GetNextLevelConcepts();
                        break;
                    }
                }
            }
        }

        UInt64 _Level1id = 0;
        public UInt64 Level1id
        {
            get => _Level1id;
            set
            {
                for (int i = 0; i < Level1.Count; i++)
                {
                    if (Level1[i].id == value)
                    {
                        selector.Select(Level1[i]);
                        _Level1id = value;
                        Level1ConceptName = Level1[i].name;

                        _Level2id = 0;
                        Level2 = selector.GetNextLevelConcepts();
                        break;
                    }
                }
            }
        }

        UInt64 _Level2id = 0;
        public UInt64 Level2id
        {
            get => _Level2id;
            set
            {
                for (int i = 0; i < Level2.Count; i++)
                {
                    if (Level2[i].id == value)
                    {
                        selector.Select(Level2[i]);
                        _Level2id = value;
                        Level2ConceptName = Level2[i].name;

                        break;
                    }
                }
            }
        }

        public SubfieldSelectionService()
        {
            Level0 = selector.level0Concepts;
        }

        public void Confirm()
        {
            Progress<int> totalProgress = new Progress<int>(value => {
                TotalProgress = value;
            });
            Progress<int> stepProgress = new Progress<int>(value => {
                StepProgress = value;
            });
            UInt16 y0 = Convert.ToUInt16(IndexPage.y1 - 10);
            UInt16 y1 = IndexPage.y1;
            UInt16 y2 = IndexPage.y2;
            UInt16 y3 = Convert.ToUInt16(IndexPage.y2 + 10);
            bool useISB = IndexPage.UseISBV1 || IndexPage.UseISBV2 || IndexPage.UseISBV2P || IndexPage.UseISBV3;
            bool useCSO = IndexPage.UseCsoAugur;
            bool useConcept = IndexPage.UseCsoAugur;
            bool useAUGUR = useCSO || useConcept;
            int k = IndexPage.k;
            int m = IndexPage.m;
            Task task = new Task(() => {
                IndexPage.NextStage("Extract data.");
                selector.Confirm(totalProgress, stepProgress);
                if (fastTextModel == null)
                {
                    IndexPage.NextStage("Load fasttext.");
                    fastTextModel = new FastTextModel(selector.dataLocation, totalProgress, stepProgress);
                }
                if (useISB)
                {
                    IndexPage.NextStage("Segmentization.");
                    Segmentizer segmentizer = new Segmentizer(selector.dataLocation, selector.selectedConcept);
                    segmentizer.Segmentize(y0, y3, totalProgress, stepProgress);
                    IndexPage.NextStage("Compute DF.");
                    TermIdentifier termIdentifier = new TermIdentifier(selector.dataLocation, selector.selectedConcept, y1, y2);
                    termIdentifier.ComputeDF(totalProgress, stepProgress);
                    IndexPage.NextStage("Identify terms.");
                    termIdentifier.SaveTermsByDoc(totalProgress, stepProgress, y0, y3);
                    IndexPage.NextStage("Find synonyms.");
                    SynonymFinder synonymFinder = new SynonymFinder(selector.dataLocation, selector.selectedConcept, y1, y2, fastTextModel);
                    synonymFinder.SaveSynonymsByDoc(totalProgress, stepProgress, y0, y3);
                    IndexPage.NextStage("Find ISB supertopics.");
                    ISBSupertopicFinder isbSupertopicFinder = new ISBSupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, fastTextModel);
                    isbSupertopicFinder.Find(totalProgress, stepProgress);
                }
                GC.Collect();

                if (IndexPage.UseISBV3)
                {
                    IndexPage.NextStage("Create CSO supertopic finder.");
                    CSOSupertopicFinder csoSupertopicFinder = new CSOSupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, totalProgress, stepProgress);
                    IndexPage.NextStage("Find CSO supertopics.");
                    csoSupertopicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find concept supertopics.");
                    ConceptSupertopicFinder conceptSupertopicFinder = new ConceptSupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2);
                    conceptSupertopicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find ISB V3 supertopics");
                    ISBV3SupertopicFinder isbV3SupertopicFinder = new ISBV3SupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, fastTextModel);
                    isbV3SupertopicFinder.Find(totalProgress, stepProgress);
                }
                GC.Collect();

                if (useISB)
                {
                    IndexPage.NextStage("Find ISB topics.");
                    ISBTopicFinder isbTopicFinder = new ISBTopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, fastTextModel, ISBTopicFinder.Version.OlderVersion);
                    isbTopicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find ISB publictions.");
                    TopicPublicationFinder publicationFinder = new TopicPublicationFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, TopicPublicationFinder.TopicType.ISB, fastTextModel);
                    publicationFinder.FindPublications(totalProgress, stepProgress);
                    IndexPage.NextStage("Find future ISB publictions.");
                    publicationFinder.FindPublications(totalProgress, stepProgress, true);
                }
                if (IndexPage.UseISBV2P)
                {
                    IndexPage.NextStage("Find ISB V2 Plus topics.");
                    ISBTopicFinder isbTopicFinder = new ISBTopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, fastTextModel, ISBTopicFinder.Version.V2P);
                    isbTopicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find ISB V2 Plus publictions.");
                    TopicPublicationFinder publicationFinder = new TopicPublicationFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, TopicPublicationFinder.TopicType.ISBV2P, fastTextModel);
                    publicationFinder.FindPublications(totalProgress, stepProgress);
                    IndexPage.NextStage("Find future ISB V2 Plus publictions.");
                    publicationFinder.FindPublications(totalProgress, stepProgress, true);
                }
                if (IndexPage.UseISBV3)
                {
                    IndexPage.NextStage("Find ISB V3 topics.");
                    ISBTopicFinder isbTopicFinder = new ISBTopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, fastTextModel, ISBTopicFinder.Version.V3);
                    isbTopicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find ISB V3 publictions.");
                    TopicPublicationFinder publicationFinder = new TopicPublicationFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, TopicPublicationFinder.TopicType.ISBV3, fastTextModel);
                    publicationFinder.FindPublications(totalProgress, stepProgress);
                    IndexPage.NextStage("Find future ISB V3 publictions.");
                    publicationFinder.FindPublications(totalProgress, stepProgress, true);
                }
                GC.Collect();

                if (useCSO)
                {
                    if (!IndexPage.UseISBV3)
                    {
                        IndexPage.NextStage("Create CSO supertopic finder.");
                        CSOSupertopicFinder csoSupertopicFinder = new CSOSupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, totalProgress, stepProgress);
                        IndexPage.NextStage("Find CSO supertopics.");
                        csoSupertopicFinder.Find(totalProgress, stepProgress);
                    }
                    IndexPage.NextStage("Find CSO topics.");
                    AUGURTopicFinder topicFinder = new AUGURTopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, true, k);
                    topicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find CSO publictions.");
                    TopicPublicationFinder publicationFinder = new TopicPublicationFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, TopicPublicationFinder.TopicType.CSO, fastTextModel);
                    publicationFinder.FindPublications(totalProgress, stepProgress);
                    IndexPage.NextStage("Find future CSO publictions.");
                    publicationFinder.FindPublications(totalProgress, stepProgress, true);
                }
                GC.Collect();
                if (useConcept)
                {
                    if (!IndexPage.UseISBV3)
                    {
                        IndexPage.NextStage("Find concept supertopics.");
                        ConceptSupertopicFinder conceptSupertopicFinder = new ConceptSupertopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2);
                        conceptSupertopicFinder.Find(totalProgress, stepProgress);
                    }
                    IndexPage.NextStage("Find concept topics.");
                    AUGURTopicFinder topicFinder = new AUGURTopicFinder(selector.dataLocation, selector.selectedConcept, y1, y2, false, k);
                    topicFinder.Find(totalProgress, stepProgress);
                    IndexPage.NextStage("Find concept publictions.");
                    TopicPublicationFinder publicationFinder = new TopicPublicationFinder(selector.dataLocation, selector.selectedConcept, y1, y2, k, TopicPublicationFinder.TopicType.Concept, fastTextModel);
                    publicationFinder.FindPublications(totalProgress, stepProgress);
                    IndexPage.NextStage("Find future concept publictions.");
                    publicationFinder.FindPublications(totalProgress, stepProgress, true);
                }
                GC.Collect();
                List<EmergingnessPredictor.TopicType> methods = new List<EmergingnessPredictor.TopicType>();
                if (IndexPage.UseISBV1)
                {
                    methods.Add(EmergingnessPredictor.TopicType.ISBV1);
                }
                if (IndexPage.UseISBV2)
                {
                    methods.Add(EmergingnessPredictor.TopicType.ISBV2);
                }
                if (IndexPage.UseISBV2P)
                {
                    methods.Add(EmergingnessPredictor.TopicType.ISBV2P);
                }
                if (IndexPage.UseISBV3)
                {
                    methods.Add(EmergingnessPredictor.TopicType.ISBV3);
                }
                if (IndexPage.UseCsoAugur)
                {
                    methods.Add(EmergingnessPredictor.TopicType.CSO);
                }
                if (IndexPage.UseConceptAugur)
                {
                    methods.Add(EmergingnessPredictor.TopicType.Concept);
                }
                {
                    foreach (EmergingnessPredictor.TopicType method in methods)
                    {
                        IndexPage.NextStage($"Predict {EmergingnessPredictor.GetTopicTypeString(method)} topic emergingness.");
                        EmergingnessPredictor emergingnessPredictor = new EmergingnessPredictor(selector.dataLocation, selector.selectedConcept, y1, y2, k, method, fastTextModel);
                        emergingnessPredictor.Predict(totalProgress, stepProgress);
                        IndexPage.NextStage($"Verify {EmergingnessPredictor.GetTopicTypeString(method)} topic emergingness.");
                        EmergingnessVerifier emergingnessVerifier = new EmergingnessVerifier(selector.dataLocation, selector.selectedConcept, y1, y2, k, method, fastTextModel);
                        emergingnessVerifier.Verify(totalProgress, stepProgress);
                        IndexPage.NextStage($"Evaluate {EmergingnessPredictor.GetTopicTypeString(method)} topic growth ratio.");
                        TopicGrowthRatioEvaluator topicGrowthRatioEvaluator = new TopicGrowthRatioEvaluator(selector.dataLocation, selector.selectedConcept, y1, y2, k, method, fastTextModel);
                        topicGrowthRatioEvaluator.Verify(totalProgress, stepProgress);
                        IndexPage.NextStage($"Evaluate {EmergingnessPredictor.GetTopicTypeString(method)} topic rise duration.");
                        TopicRiseDurationEvaluator topicRiseDurationEvaluator = new TopicRiseDurationEvaluator(selector.dataLocation, selector.selectedConcept, y1, y2, k, method, fastTextModel);
                        topicRiseDurationEvaluator.Verify(totalProgress, stepProgress);
                        IndexPage.NextStage($"Verify {EmergingnessPredictor.GetTopicTypeString(method)} topic effectiveness.");
                        EffectivenessVerifier effectivenessVerifier = new EffectivenessVerifier(selector.dataLocation, selector.selectedConcept, y1, y2, k, m, method, fastTextModel);
                        effectivenessVerifier.Verify(totalProgress, stepProgress);
                    }
                    IndexPage.NextStage("Comparing the results of these methods.");
                    MethodComparison methodComparison = new MethodComparison(selector.dataLocation, selector.selectedConcept, y1, y2, k, m, methods, fastTextModel);
                    methodComparison.Compare(totalProgress, stepProgress);
                }
                GC.Collect();
                IndexPage.Reset();
            });
            task.Start();
        }
    }
}

